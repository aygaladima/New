"""A new, static Circuit composition for the Forge Pass 1,100 review.

This is deliberately a different artwork from the original six-arm family
representative. Four heavy stepped assemblies surround four large circular
junctions; uneven, strictly orthogonal forks leave generous open quadrants.
Only plain JSON-compatible geometry is returned.
"""

from __future__ import annotations

import math


SEED = 110099001


def build():
    scene = {
        "name": "Circuit",
        "description": (
            "A four-arm stepped Circuit composition with four prominent circular "
            "junctions and one broken outer framing ring. Heavy cyan trunks, "
            "asymmetric cobalt right-angle forks and silver fine traces form a "
            "spacious architectural cross. Unlike the earlier six-arm Circuit "
            "representative, this artwork has four primary assemblies, larger "
            "junction nodes, unequal branch hierarchies and only one halo."
        ),
        "seed": SEED,
        "structural_subtype": "Fourfold stepped junctions",
        "paths": [],
        "tips": [],
        "rings": [],
        "nodes": [],
        "facets": [],
    }

    def point(p, angle, hand=1):
        x, y = float(p[0]), float(p[1]) * hand
        theta = math.radians(angle)
        return [round(x * math.cos(theta) - y * math.sin(theta), 5),
                round(x * math.sin(theta) + y * math.cos(theta), 5)]

    def path(points, width, color, group, angle, hand, taper=.76):
        scene["paths"].append({
            "points": [point(p, angle, hand) for p in points],
            "width": float(width), "taper": taper,
            "color": color, "group": group,
        })

    def tip(p, radius, color, angle, hand):
        scene["tips"].append({"pos": point(p, angle, hand),
                              "radius": radius, "color": color})

    # Every fork begins at an explicit vertex of its parent rail. Each arm
    # occupies its own cardinal sector; the open diagonals remain uncluttered.
    for arm, angle in enumerate((-90, 0, 90, 180)):
        hand = (1, -1, 1, -1)[arm]
        first = (145, 151, 141, 148)[arm]
        second = (250, 256, 245, 252)[arm]
        reach = (378, 366, 387, 373)[arm]
        upper_reach = (316, 329, 307, 321)[arm]
        lower_reach = (369, 357, 374, 363)[arm]
        crown = (127, 135, 121, 131)[arm]
        lower_depth = (-145, -133, -150, -140)[arm]

        trunk = [(48, 0), (first, 0), (first, -32),
                 (second, -32), (second, 24), (reach, 24)]
        path(trunk, (23, 21, 24, 22)[arm], 0, arm, angle, hand, .80)
        tip(trunk[-1], 5.6, 2, angle, hand)

        # Large outward fork above the main stepped rail.
        upper = [(first, 0), (first, 82), (224, 82),
                 (224, crown), (upper_reach, crown)]
        path(upper, 10.8, 1, arm, angle, hand, .75)
        tip(upper[-1], 5.0, 2, angle, hand)

        # Lower fork is intentionally longer and more heavily articulated.
        lower = [(second, -32), (second, -109), (325, -109),
                 (325, lower_depth), (lower_reach, lower_depth)]
        path(lower, 9.2, 0 if arm % 2 else 1, arm, angle, hand, .72)
        tip(lower[-1], 4.7, 2, angle, hand)

        # Attached fine traces stay in distinct lanes with clear spacing.
        upper_trace = [(224, 82), (286, 82), (286, 58), (350, 58)]
        path(upper_trace, 3.5, 2, arm, angle, hand, .82)
        tip(upper_trace[-1], 3.6, 0, angle, hand)

        outer_trace = [(325, -109), (363, -109),
                       (363, -73), (395, -73)]
        path(outer_trace, 3.1, 2, arm, angle, hand, .82)
        tip(outer_trace[-1], 3.7, 1, angle, hand)

        inner_trace = [(first, -32), (first, -78), (207, -78)]
        path(inner_trace, 6.5 if arm in (0, 3) else 5.8,
             1, arm, angle, hand, .75)
        tip(inner_trace[-1], 3.8, 2, angle, hand)

        if arm in (0, 2):
            # Two opposed arms gain an additional fine lower twig, creating
            # a real difference in topology while retaining compositional balance.
            twig = [(207, -78), (207, -143), (254, -143)]
            path(twig, 2.9, 2, arm, angle, hand, .80)
            tip(twig[-1], 3.4, 0, angle, hand)
        else:
            # The other pair carries a short silver terminal extension upward.
            twig = [(224, crown), (224, crown + 35), (274, crown + 35)]
            path(twig, 3.3, 2, arm, angle, hand, .80)
            tip(twig[-1], 3.4, 0, angle, hand)

        scene["nodes"].append({"pos": point((first, 0), angle, hand),
                               "radius": (24, 26, 23, 25)[arm],
                               "style": "junction", "color": arm % 2,
                               "group": arm})

    scene["rings"].append({"center": [0, 0], "radius": 444,
                           "width": 7.7, "segments": 4, "gap": 28,
                           "start": -76, "color": 0})
    scene["nodes"].append({"pos": [0, 0], "radius": 55,
                           "style": "hub", "color": 0})
    return scene


if __name__ == "__main__":
    import json
    geometry = build()
    print(json.dumps(geometry, indent=2))
