"""Two unique Circuit sample artworks for the approved 1,100-piece collection."""
from pathlib import Path
import os,math,json,hashlib,copy,concurrent.futures,subprocess,time
os.environ['OMP_NUM_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np
from PIL import Image,ImageDraw,ImageFilter,ImageChops
import style as s
from preview_geometry import build as preview_build
from families_geometric import build as family_build
ROOT=Path(__file__).resolve().parents[1];FPS=20;COUNT=240
PALETTE=s.PALETTES['Circuit'];AXES=[-90+60*i for i in range(6)]

def digest(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def export_json(path,data):path.write_text(json.dumps(data,indent=2)+'\n')
def volumetric_geometry():
 g=family_build('Circuit',seed=20261018,variant=0)
 g['description']='Six stepped gate assemblies with six prominent outer junctions, a fixed faceted hub, two front segmented rings and a thin rear halo; layered separation/merging.'
 # Substantial terminal gates distinguish this architecture from the four-arm Preview.
 for rec in g['paths']:
  if rec['width']>15:
   g['nodes'].append({'pos':rec['points'][-1],'radius':13.5,'style':'junction','color':1 if rec['group']%2 else 2,'group':rec['group']})
 g['rings'][0].update(width=4.4,segments=12,gap=10)
 g['rings'][1].update(width=8.0,segments=6,gap=18)
 return g

G=volumetric_geometry()
def opening(frame):return .5+.5*math.sin(2*math.pi*(frame%COUNT)/COUNT)
def owner(point):
 angle=math.degrees(math.atan2(point[1],point[0]));return min(range(6),key=lambda i:abs((angle-AXES[i]+180)%360-180))
def transform(point,group,o,layer):
 if layer=='front':scale=.80+.14*o;radial=28*o;hinge=4*o
 else:scale=.80;radial=0;hinge=-o
 turn=(-1 if group%2==0 else 1)*hinge;a=math.radians(turn);co,si=math.cos(a),math.sin(a);x,y=point
 axis=math.radians(AXES[group]+turn)
 return [(x*co-y*si)*scale+radial*math.cos(axis),(x*si+y*co)*scale+radial*math.sin(axis)]

def render_volumetric(frame,size=1000,ss=2):
 o=opening(frame);native=round(size*ss);scale=native/1024
 im=s.background(native,PALETTE);p=s.Painter(im,scale)
 # Thin blue rear rail layer remains visible as the foreground assemblies lift away.
 rear_ring=copy.deepcopy(G['rings'][0]);rear_ring.update(radius=340+8*o,width=1.6,color=1)
 s.ring(p,rear_ring,PALETTE)
 for rec in G['paths']:
  pts=[transform(q,rec['group'],o,'rear') for q in rec['points']]
  width=max(1.4,rec['width']*.24)
  p.line(pts,(4,21,56),width+2.4,(1.5,3))
  p.line(pts,(24,68,151),width+1.0)
  p.line(pts,(65,130,225),max(.8,width*.58))
 for tip in G['tips']:
  q=transform(tip['pos'],owner(tip['pos']),o,'rear');s.orb(p,q,2.5,(65,130,225))
 # Front rings follow the same slow expansion, keeping breathing movement coherent.
 for i,rec in enumerate(G['rings']):
  r=copy.deepcopy(rec);r['radius']=rec['radius']*(.84+.16*o)+(12 if i==0 else 16)*o;s.ring(p,r,PALETTE)
 moved=[]
 for rec in G['paths']:
  r=copy.deepcopy(rec);r['points']=[transform(q,rec['group'],o,'front') for q in rec['points']];moved.append(r)
  if rec['width']>15:
   q=r['points'][0];radius=math.hypot(*q)
   if radius>49:moved.append({'points':[[q[0]/radius*49,q[1]/radius*49],q],'width':13.5,'taper':.78,'color':0,'group':rec['group']})
 for rec in sorted(moved,key=lambda r:-r['width']):s.rail(p,rec,PALETTE)
 for tip in G['tips']:
  q=transform(tip['pos'],owner(tip['pos']),o,'front');s.orb(p,q,tip.get('radius',3),PALETTE[tip.get('color',2)])
 for node in G['nodes']:
  if node.get('style')=='hub':continue
  n=copy.deepcopy(node);n['pos']=transform(node['pos'],node.get('group',owner(node['pos'])),o,'front');s.hub(p,n,PALETTE,'Circuit')
 # The opaque central hub is composited last at its original fixed coordinates.
 for node in G['nodes']:
  if node.get('style')=='hub':s.hub(p,node,PALETTE,'Circuit')
 emission=im.point([max(0,round((v-140)*.12)) for v in range(256)]*3)
 im=ImageChops.add(im,emission.filter(ImageFilter.GaussianBlur(scale*1.5)))
 return im.resize((size,size),Image.Resampling.LANCZOS)

def frame_worker(frame):
 target=ROOT/'internal'/'frames'/f'{frame:04d}.png'
 render_volumetric(frame).save(target,compress_level=1)
 return frame

def comparison():
 out=Image.new('RGB',(1920,1230),(5,9,15));d=ImageDraw.Draw(out)
 d.text((38,25),'FORGE PASS / 1,100 ARTWORKS',font=s.font(39,True),fill=(220,237,245))
 d.text((40,83),'Approved structure: 11 families × (90 Preview + 10 Volumetric)',font=s.font(23),fill=(145,171,189))
 for index,(filename,title,caption) in enumerate([
 ('Circuit_Preview_Sample.png','PREVIEW / QUAD CIRCUIT','4 assemblies · 4 large junctions · 1 broken ring'),
 ('Circuit_Volumetric_Sample.png','VOLUMETRIC / SIX-GATE BLOOM','6 assemblies · 6 outer junctions · layered halos')]):
  x=index*960
  with Image.open(ROOT/'artwork'/filename) as im:out.paste(im.resize((960,960),Image.Resampling.LANCZOS),(x,140))
  d.text((x+35,1120),title,font=s.font(29,True),fill=(222,235,244))
  d.text((x+35,1170),caption,font=s.font(20),fill=(146,170,190))
 out.save(ROOT/'delivery'/'ForgePass_1100_Sample_Comparison.jpg',quality=95)
 sheet=Image.new('RGB',(1920,540),(5,9,15));d=ImageDraw.Draw(sheet)
 for index,frame in enumerate([0,60,120,180]):
  with Image.open(ROOT/'internal'/'frames'/f'{frame:04d}.png') as im:sheet.paste(im.resize((480,480),Image.Resampling.LANCZOS),(index*480,0))
  label=['Layer separation','Maximum opening','Layer separation','Layers merged'][index]
  d.text((index*480+20,486),f'{frame/20:g}s / {label}',font=s.font(20),fill=(200,223,239))
 sheet.save(ROOT/'delivery'/'Volumetric_Loop_Keyframes.jpg',quality=95)

def encode():
 base=['ffmpeg','-hide_banner','-loglevel','error','-y','-threads','1','-filter_threads','1']
 frames=ROOT/'internal'/'frames'/'%04d.png';palette=ROOT/'internal'/'palette.png';output=ROOT/'artwork'/'Circuit_Volumetric_Sample.gif'
 for colours in [256,192,128]:
  subprocess.run(base+['-framerate','20','-i',str(frames),'-vf',f'palettegen=max_colors={colours}:reserve_transparent=0:stats_mode=full','-frames:v','1','-update','1',str(palette)],check=True)
  subprocess.run(base+['-framerate','20','-i',str(frames),'-i',str(palette),'-filter_complex_threads','1','-filter_complex','[0:v][1:v]paletteuse=dither=none:diff_mode=rectangle','-loop','0','-final_delay','5',str(output)],check=True)
  if output.stat().st_size<50_000_000:return colours
 raise RuntimeError('GIF exceeds 50 MB')

def validate(colours):
 output=ROOT/'artwork'/'Circuit_Volumetric_Sample.gif';duration=0;firsthub=None;poses={};count=0
 with Image.open(output) as im:
  assert im.size==(1000,1000) and im.n_frames==240 and im.info.get('loop')==0
  for frame in range(im.n_frames):
   im.seek(frame);im.load();assert im.info.get('duration')==50;duration+=im.info['duration'];count+=1
   rgb=im.convert('RGB');hub=np.array(rgb.crop((478,478,522,522)))
   if firsthub is None:firsthub=hub
   else:assert np.array_equal(firsthub,hub),'Hub core changes'
   if frame in [0,1,60,120,180,239]:poses[frame]=np.array(rgb,dtype=np.int16)
 assert np.array_equal(np.array(render_volumetric(0)),np.array(render_volumetric(240)))
 delta=lambda a,b:float(np.abs(poses[a]-poses[b]).mean())
 seam=delta(239,0);step=delta(0,1);visible=delta(60,180)
 assert seam<step*1.8 and visible>4,(seam,step,visible)
 for path in (ROOT/'artwork').glob('*.png'):
  with Image.open(path) as im:im.load();assert im.size==(2048,2048) and im.mode=='RGB'
 files=[{'file':p.name,'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted((ROOT/'artwork').iterdir()) if p.is_file()]
 report={'complete':True,'sample_artworks':2,'preview_artworks':1,'volumetric_artworks':1,'png_exports':2,'gif_exports':1,'gif_size':[1000,1000],'png_size':[2048,2048],'gif_frames':count,'duration_ms':duration,'fps':20,'loop':0,'palette_colours':colours,'native_loop_endpoints_identical':True,'fixed_hub_core_all_frames':True,'all_gifs_below_50_MB':output.stat().st_size<50_000_000,'loop_seam_delta':seam,'ordinary_step_delta':step,'open_vs_merged_delta':visible,'files':files}
 export_json(ROOT/'Validation.json',report);return report

def main():
 started=time.time();preview=preview_build();export_json(ROOT/'source'/'Preview_Geometry.json',preview);export_json(ROOT/'source'/'Volumetric_Geometry.json',G)
 s.render(preview).save(ROOT/'artwork'/'Circuit_Preview_Sample.png',compress_level=6)
 render_volumetric(60,2048,2).save(ROOT/'artwork'/'Circuit_Volumetric_Sample.png',compress_level=6)
 print('2048px PNGs rendered',flush=True)
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
  for frame in pool.map(frame_worker,range(COUNT)):
   if frame%40==0:print('Frame',frame,'of',COUNT,flush=True)
 print('Encoding GIF',flush=True);colours=encode();report=validate(colours);comparison()
 print(json.dumps(report,indent=2),flush=True);print('Elapsed seconds',round(time.time()-started,1),flush=True)
if __name__=='__main__':main()
