# Source backup

Run `python Restore_Geometry.py` once after extraction to restore the gzip-compressed geometry JSON files. Then follow README.md.

The media are delivered separately. Collection.json is a production manifest, not deployed NFT metadata. No minting or listing has been performed.

Included contact sheets: 161. Omitted to keep this ZIP below 80 MB: 0.
