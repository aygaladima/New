from pathlib import Path
import json,math,concurrent.futures
import numpy as np
from PIL import Image,ImageDraw,ImageFilter
import style
ROOT=Path(__file__).resolve().parents[1]

def thumb(item,size):
 p=ROOT/'internal/thumbnails'/f"{item['id']:04d}.jpg"
 with Image.open(p) as im:return im.resize((size,size),Image.Resampling.LANCZOS)
def draw_sheet(items,cols,tile,title,path,subtitle=''):
 rows=math.ceil(len(items)/cols);header=90;cell=tile+58
 out=Image.new('RGB',(cols*tile,header+rows*cell),(5,9,15));d=ImageDraw.Draw(out)
 d.text((18,15),title,font=style.font(27,True),fill=(222,238,247))
 d.text((20,53),subtitle,font=style.font(15),fill=(143,166,186))
 for index,item in enumerate(items):
  x=index%cols*tile;y=header+index//cols*cell;out.paste(thumb(item,tile),(x,y))
  d.text((x+10,y+tile+3),f"#{item['id']:04d}  {item['tier']}",font=style.font(15,True),fill=(204,227,241))
  label=item['subtype_name']
  while d.textlength(label,font=style.font(13))>tile-20:label=label[:-2]
  d.text((x+10,y+tile+28),label,font=style.font(13),fill=(139,163,184))
 out.save(path,quality=93)

def silhouette(g):
 im=Image.new('L',(256,256));d=ImageDraw.Draw(im)
 point=lambda p:((p[0]+512)/4,(p[1]+512)/4)
 for r in g['rings']:
  x,y=point(r['center']);rr=r['radius']/4;span=360/r['segments']-r['gap']
  for i in range(r['segments']):
   a=r['start']+i*360/r['segments'];d.arc((x-rr,y-rr,x+rr,y+rr),a,a+span,fill=255,width=max(1,round(r['width']/4)))
 for rec in g['paths']:d.line([point(p) for p in rec['points']],fill=255,width=max(1,round(rec['width']/4)),joint='curve')
 for r in g['nodes']+g['tips']:
  x,y=point(r['pos']);rr=r['radius']/4;d.ellipse((x-rr,y-rr,x+rr,y+rr),fill=255)
 for rec in g.get('facets',[]):d.polygon([point(p) for p in rec['points']],fill=255)
 im=im.filter(ImageFilter.GaussianBlur(1.3)).resize((64,64),Image.Resampling.LANCZOS)
 v=np.array(im,dtype=float).ravel()/255;return v/max(1e-8,np.linalg.norm(v))

def main():
 items=json.loads((ROOT/'Collection.json').read_text())['items'];families=list(dict.fromkeys(i['family'] for i in items));out=ROOT/'review';out.mkdir(exist_ok=True)
 pairs=[]
 for family in families:
  members=[i for i in items if i['family']==family]
  if not all((ROOT/'internal/thumbnails'/f"{i['id']:04d}.jpg").exists() for i in members):continue
  reps=[i for i in members if i['tier']=='Volumetric']
  draw_sheet(reps,5,360,f'FORGE PASS / {family.upper()} / 10 ARCHITECTURES',out/f'{family}_Architectures.jpg','Each subtype includes nine unique Preview artworks and one Volumetric artwork.')
  for sub in range(10):
   group=[i for i in members if i['subtype_index']==sub]
   draw_sheet(group,5,300,f"{family.upper()} / {group[0]['subtype_name']}",out/f'{family}_Subtype_{sub+1:02d}.jpg','Nine Preview compositions plus one Volumetric composition; stills shown for review.')
   preview=[i for i in group if i['tier']=='Preview'];vectors=[silhouette(json.loads((ROOT/i['geometry_file']).read_text())) for i in preview]
   for a in range(9):
    for b in range(a+1,9):pairs.append({'family':family,'subtype_name':group[0]['subtype_name'],'ids':[preview[a]['id'],preview[b]['id']],'silhouette_cosine':round(float(np.dot(vectors[a],vectors[b])),6)})
  print('Reviewed sheet coverage',family,len(members),flush=True)
 reps=[i for i in items if i['tier']=='Volumetric']
 if all((ROOT/'internal/thumbnails'/f"{i['id']:04d}.jpg").exists() for i in reps):
  draw_sheet(reps,10,200,'FORGE PASS / 110 STRUCTURAL SUBTYPES',out/'ForgePass_1100_Overview.jpg','1,100 artworks: 990 Preview + 110 Volumetric. Each row is one family.')
 pairs.sort(key=lambda x:-x['silhouette_cosine']);(ROOT/'internal/Silhouette_Neighbours.json').write_text(json.dumps({'closest_pairs':pairs[:100],'pairs_checked':len(pairs),'note':'Screening aid; visual review remains necessary.'},indent=2)+'\n')
 if pairs:
  byid={i['id']:i for i in items};selected=[byid[ident] for pair in pairs[:12] for ident in pair['ids']]
  draw_sheet(selected,6,280,'CLOSEST SILHOUETTES / VISUAL CHECK',ROOT/'internal/Closest_Silhouettes.jpg','Colour-independent shape comparison; pairs are consecutive left to right.')
 print('Nearest similarities',pairs[:5],flush=True)
if __name__=='__main__':main()
