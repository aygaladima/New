"""Forge Pass production geometry: Circuit, Lightning, and Trident.

Thirty deliberately different structural architectures.  Every fork is attached
to an explicit parent vertex; all outputs are plain, deterministic JSON data.
The variant is a composition choice, not merely a random seed or rotation.
"""
from __future__ import annotations

import math
import random


SUBTYPES = {
    "Circuit": ["Quad Relay", "Six-Gate Bloom", "Eight-Spoke Array",
                "Twin-Core Bridge", "Circuit Tower", "Split Wings",
                "Triangular Network", "Square Stack", "Offset Network",
                "Perimeter Circuit"],
    "Lightning": ["Storm Triad", "Sky Strike", "Horizon Storm", "Twin Fault",
                  "Storm Fan", "Triangular Arc", "Crown Strike", "Thunder Cross",
                  "Diagonal Fault", "Fracture Network"],
    "Trident": ["Sovereign Tine", "Opposed Forks", "Triune Engine",
                "Cruciform Tridents", "Stacked Scepters", "Crown of Tines",
                "Twin-Pylon Bridge", "Triangular Citadel", "Nested Harpoons",
                "Diagonal Spearworks"],
}


def _round_point(point):
    return [round(float(point[0]), 5), round(float(point[1]), 5)]


def _transform(point, origin=(0, 0), angle=0, scale=1):
    theta = math.radians(angle)
    x, y = point[0] * scale, point[1] * scale
    return _round_point((origin[0] + x * math.cos(theta) - y * math.sin(theta),
                         origin[1] + x * math.sin(theta) + y * math.cos(theta)))


def _scene(family, subtype, variant, seed, layout):
    return {"name": family, "subtype_name": SUBTYPES[family][subtype],
            "structural_subtype": SUBTYPES[family][subtype],
            "description": "", "layout": layout, "variant": variant,
            "seed": seed, "paths": [], "tips": [], "rings": [],
            "nodes": [], "facets": [], "anchor_points": [],
            "main_assemblies": 0, "assembly_groups": []}


def _path(s, points, width, color=0, group=0, taper=.68, origin=(0, 0), angle=0):
    points = [_transform(p, origin, angle) for p in points]
    # Suppress an unnecessary vertex if a deliberately straight layout folds it
    # onto the preceding one.  Its parent junction retains the same coordinate.
    clean = [points[0]]
    for p in points[1:]:
        if p != clean[-1]:
            clean.append(p)
    if len(clean) < 2:
        raise ValueError("Degenerate generated rail")
    s["paths"].append({"points": clean, "width": float(width), "color": color % 3,
                       "group": int(group), "taper": float(taper)})
    return clean


def _tip(s, point, radius=4.2, color=2, group=0, origin=(0, 0), angle=0):
    s["tips"].append({"pos": _transform(point, origin, angle),
                      "radius": float(radius), "color": color % 3,
                      "group": int(group)})


def _node(s, point, radius, style="junction", color=0, group=0,
          origin=(0, 0), angle=0):
    pos = _transform(point, origin, angle)
    s["nodes"].append({"pos": pos, "radius": float(radius), "style": style,
                       "color": color % 3, "group": int(group)})
    if style == "hub":
        s["anchor_points"].append({"group": int(group), "pos": pos})


def _ring(s, radius, width=4.0, segments=1, gap=0, start=0, color=0,
          center=(0, 0), group=-1):
    s["rings"].append({"center": _round_point(center), "radius": float(radius),
                       "width": float(width), "segments": int(segments),
                       "gap": float(gap), "start": float(start),
                       "color": color % 3, "group": int(group)})


def _circuit_arm(s, rng, variant, group, origin=(0, 0), angle=0,
                 reach=380, spread=105, root=38, width=22, collar=True):
    """Stepped parent rail with genuine variant-dependent fork topologies."""
    v = variant
    hand = 1 if (group + v // 3) % 2 == 0 else -1
    first = reach * (.32 + .025 * (v % 3))
    second = reach * (.61 + .025 * ((v + 1) % 3))
    bend = hand * spread * (.24 + .06 * (v % 2))
    final_y = -hand * spread * (.10 + .045 * (v % 3))
    end = reach * (1 + .015 * rng.randint(-1, 1))
    trunk = [(root, 0), (first, 0), (first, bend),
             (second, bend), (second, final_y), (end, final_y)]
    _path(s, trunk, width, 0 if (group + v) % 3 else 1, group, .78,
          origin, angle)
    _tip(s, trunk[-1], 4.6 + .4 * (v % 2), 2, group, origin, angle)
    # Every alternative changes the graph, silhouettes, and branch hierarchy.
    if v in (1, 4, 7):
        roots = [(trunk[1], -hand), (trunk[3], -hand),
                 (trunk[4], hand)] if v == 4 else [(trunk[1], hand),
                                                  (trunk[3], hand)]
    elif v in (2, 5, 6, 8):
        roots = [(trunk[1], -hand), (trunk[2], hand), (trunk[4], -hand)]
    else:
        roots = [(trunk[1], hand), (trunk[3], -hand)]
    for j, (root_p, sign) in enumerate(roots):
        outer_y = sign * spread * (.72 + .15 * ((v + j) % 3))
        knee_x = min(end - reach * .11,
                     root_p[0] + reach * (.18 + .025 * ((j + v) % 2)))
        term_x = min(end + reach * .04, knee_x + reach * (.20 + .035 * (v % 2)))
        fork = [root_p, (root_p[0], outer_y), (knee_x, outer_y),
                (knee_x, outer_y + sign * spread * .24),
                (term_x, outer_y + sign * spread * .24)]
        _path(s, fork, max(5.1, width * (.40 - .025 * j)), 1 if j % 2 == 0 else 0,
              group, .70, origin, angle)
        _tip(s, fork[-1], 4.0, 2 if j != 1 else 1, group, origin, angle)
        # Different variants carry a secondary trace, a terminal satellite,
        # or a forked ladder.  Both alternatives attach at parent vertices.
        if (v + j) % 3 != 1:
            side = -sign
            trace = [fork[2], (knee_x + reach * .08, outer_y),
                     (knee_x + reach * .08, outer_y + side * spread * .27),
                     (min(end + reach * .06, term_x + reach * .06),
                      outer_y + side * spread * .27)]
            _path(s, trace, 2.7 + .3 * (v % 2), 2, group, .82, origin, angle)
            _tip(s, trace[-1], 3.1, (j + v) % 2, group, origin, angle)
        if v in (2, 7, 9) and j == 0:
            _node(s, fork[-1], 10.5 + 2 * (v % 2), "junction", 1,
                  group, origin, angle)
    if collar:
        _node(s, trunk[1], min(25, max(12, spread * .20)), "junction",
              (group + v) % 2, group, origin, angle)
    if v in (0, 3, 6, 9):
        inner = [trunk[2], (first, -hand * spread * .45),
                 (first + reach * .14, -hand * spread * .45)]
        _path(s, inner, 4.5, 1, group, .75, origin, angle)
        _tip(s, inner[-1], 3.5, 2, group, origin, angle)
    return trunk


def _framing(s, variant, primary=444, style="radial", center=(0, 0)):
    """Ten purposeful framing treatments rather than arbitrary ring counts."""
    v = variant
    if v in (0, 3, 6, 9):
        _ring(s, primary, 6.0 + v % 3, 4 + 2 * (v // 3 % 2),
              20 if v in (0, 6) else 32, -78, 0, center)
        if v in (3, 9):
            _ring(s, primary - 38, 2.3, 8, 22, -72, 1, center)
    elif v in (1, 5):
        _ring(s, primary - 6, 3.4, 2, 100 if v == 1 else 76, -60, 1, center)
    elif v in (2, 8):
        _ring(s, primary, 4.8, 8, 15, -85, 0, center)
        _ring(s, primary - 31, 1.8, 4, 40, -65, 2, center)
    else:
        _ring(s, primary - 12, 2.2, 1, 105, -48, 1, center)


def _circuit(subtype, variant, rng, seed):
    layouts = ["radial", "radial", "radial", "horizontal", "vertical",
               "horizontal", "triangular", "rectangular", "asymmetric", "perimeter"]
    s = _scene("Circuit", subtype, variant, seed, layouts[subtype])
    v = variant
    if subtype in (0, 1, 2):
        count = (4, 6, 8)[subtype]
        spread = (112, 73, 51)[subtype] * (1 + .07 * ((v % 3) - 1))
        reach = (377, 364, 390)[subtype] - 10 * (v % 3)
        for g in range(count):
            length = reach * (1 - (.075 if v in (1, 5, 8) and g % 2 else 0))
            _circuit_arm(s, rng, v, g, angle=-90 + g * 360 / count,
                         reach=length, spread=spread, width=23 - subtype * 2)
        _node(s, (0, 0), (55, 52, 48)[subtype], "hub", v % 2)
        _framing(s, v)
        s["main_assemblies"] = count
    elif subtype == 3:
        for h, center in enumerate(((-182, 0), (182, 0))):
            _node(s, center, 47 + 3 * (v % 3), "hub", h)
            angles = (132, 180, 228) if h == 0 else (-48, 0, 48)
            for j, angle in enumerate(angles):
                _circuit_arm(s, rng, v, h * 3 + j, center, angle,
                             reach=212 + 12 * ((v + j) % 3),
                             spread=43 + 4 * (v % 3), width=19)
            if v not in (1, 4, 7):
                _ring(s, 164 + 6 * (v % 3), 3.5, 4, 43, -70,
                      h, center)
        bridge = [(-182, 0), (-82, 0), (-82, -32 if v % 2 else 32),
                  (82, -32 if v % 2 else 32), (82, 0), (182, 0)]
        _path(s, bridge, 23, 2 if v in (2, 6) else 0, 6, .8)
        _node(s, bridge[2], 18, "junction", 2, 6)
        _node(s, bridge[3], 18, "junction", 1, 6)
        if v in (3, 5, 8, 9):
            _path(s, [bridge[2], (-82, -150), (0, -150), (0, -216)],
                  8.5, 1, 6)
            _tip(s, (0, -216), 5, 2, 6)
        s["main_assemblies"] = 6
    elif subtype == 4:
        levels = 3 if v in (1, 5, 8) else 4
        ys = [190 - i * (440 / (levels - 1)) for i in range(levels)]
        trunk = [(0, 310)] + [(0, y) for y in ys] + [(0, -350)]
        _path(s, trunk, 24, 0, 0, .62)
        _node(s, (0, 310), 53, "hub", 0)
        _tip(s, trunk[-1], 6, 2, 0)
        for i, y in enumerate(ys):
            reach = (230 + 80 * math.sin((i + 1) / (levels + 1) * math.pi))
            if v in (2, 6, 9):
                reach += 15 if i % 2 else -20
            _node(s, (0, y), 20 + 2 * (i % 2), "junction", i % 2, i + 1)
            for side in (0, 1):
                _circuit_arm(s, rng, v, 1 + i * 2 + side, (0, y),
                             0 if side == 0 else 180, reach, 36 + 4 * (v % 3),
                             root=0, width=17)
        _ring(s, 390, 2.6, 2, 95, -45, 1, (0, -15))
        s["main_assemblies"] = levels * 2
    elif subtype == 5:
        _node(s, (0, 0), 64, "hub", 0)
        for g, angle in enumerate((0, 180)):
            arm = _circuit_arm(s, rng, v, g, angle=angle, reach=378,
                               spread=156 + 10 * (v % 3), width=24)
            # Additional broad wing lanes change the silhouette and retain
            # an explicit connection at each assembly's inner elbow.
            for j, sign in enumerate((-1, 1)):
                side_y = sign * (195 + 12 * (v % 2))
                extension = [arm[1], (arm[1][0], side_y * .72),
                             (266 - 8 * (v % 3), side_y * .72),
                             (266 - 8 * (v % 3), side_y),
                             (346 + 10 * (v % 3), side_y)]
                _path(s, extension, 8 + j, 1 if j == 0 else 0, g, .68,
                      angle=angle)
                _tip(s, extension[-1], 5.2, 2, g, angle=angle)
                _node(s, extension[2], 16 + 2 * j, "junction", j, g,
                      angle=angle)
        _ring(s, 185 + 8 * (v % 3), 4, 2, 105, -36, 1)
        if v in (0, 3, 6, 9):
            _ring(s, 440, 3, 2, 122, -28, 0)
        s["main_assemblies"] = 2
    elif subtype == 6:
        vertices = [(0, -228), (226, 156), (-226, 156)]
        routes = [[vertices[0], (78, -228), (78, -25), (226, -25), vertices[1]],
                  [vertices[1], (0, 156), vertices[2]],
                  [vertices[2], (-226, -25), (-78, -25), (-78, -228), vertices[0]]]
        for g, points in enumerate(routes):
            _path(s, points, 17 + (v % 3), g % 2, g, .8)
        _node(s, (0, 156), 42, "hub", 0)
        for g, (origin, angle) in enumerate(zip(vertices, (-90, 28, 152))):
            _node(s, origin, 31 + 3 * (v % 2), "junction", g % 2, g)
            _circuit_arm(s, rng, v, g, origin, angle, reach=168 + 9 * (v % 3),
                         spread=46 + 4 * (v % 3), root=0, width=20)
        if v in (1, 4, 7):
            _ring(s, 91, 3, 3, 48, -85, 2, (0, 10))
        else:
            _framing(s, v)
        s["main_assemblies"] = 3
    elif subtype == 7:
        half = 195 + 12 * (v % 3)
        inner = 92 + 12 * ((v + 1) % 3)
        corners = [(-half, -half), (half, -half), (half, half), (-half, half)]
        _path(s, corners + [corners[0]], 21, 0, 0, .8)
        smaller = [(-inner, -inner), (inner, -inner), (inner, inner), (-inner, inner)]
        _path(s, smaller + [smaller[0]], 10.5, 1, 1, .8)
        _node(s, smaller[0], 29, "hub", 0)
        for g, (p, q, angle) in enumerate(zip(corners, smaller, (-135, -45, 45, 135))):
            _path(s, [p, (q[0], p[1]), q], 7.0 + v % 3, 2, g)
            _node(s, p, 24 + 2 * (v % 2), "junction", g % 2, g)
            _circuit_arm(s, rng, v, g, p, angle, reach=203 - 8 * (v % 3),
                         spread=38 + 3 * (v % 3), root=0, width=16)
        if v in (2, 5, 8, 9):
            _ring(s, 61, 2.5, 4, 35, -90, 2)
        s["main_assemblies"] = 4
    elif subtype == 8:
        center = (-125 + 12 * (v % 3), 90 - 8 * (v // 3))
        _node(s, center, 58, "hub", 0)
        angles = (-112, -62, -8, 58, 157) if v % 2 == 0 else (-120, -55, 8, 74, 175)
        lengths = (352, 395, 420, 288, 238)
        for g, (angle, length) in enumerate(zip(angles, lengths)):
            _circuit_arm(s, rng, v, g, center, angle,
                         reach=length - 10 * (v % 3), spread=57,
                         width=23 if g in (1, 2) else 17)
        _ring(s, 386, 4.0, 3, 43, -80, 1, (36, -20))
        if v in (0, 2, 5, 9):
            _ring(s, 134, 2.7, 2, 65, -35, 2, center)
        s["main_assemblies"] = 5
    else:
        h = 327 + 8 * (v % 3)
        perimeter = [(0, -h), (h, -h), (h, 0), (h, h),
                     (0, h), (-h, h), (-h, 0), (-h, -h), (0, -h)]
        _path(s, perimeter, 17 + v % 3, 0, 0, .8)
        _path(s, [(0, 0), (0, -155), (0, -h)], 21, 0, 0, .76)
        _node(s, (0, 0), 47, "hub", 0)
        origins = [(0, -h), (h, 0), (0, h), (-h, 0)]
        for g, (origin, angle) in enumerate(zip(origins, (90, 180, -90, 0))):
            _node(s, origin, 23 + 2 * (v % 3), "junction", g % 2, g)
            _circuit_arm(s, rng, v, g, origin, angle,
                         reach=172 + 12 * ((v + g) % 3),
                         spread=77, root=0, width=18)
        for g, p in enumerate(((-h, -h), (h, -h), (h, h), (-h, h))):
            _node(s, p, 16 + 2 * (v % 2), "junction", 2, g)
        if v in (1, 3, 6, 9):
            _ring(s, 117, 3.5, 4, 37, -75, 1)
        s["main_assemblies"] = 4
    s["description"] = (f"{s['subtype_name']}: {s['layout']} stepped circuit architecture; "
                            f"composition {variant + 1} uses connected orthogonal forks, "
                            "separate trace lanes, circular junctions and raised metal rails.")
    return s


def _bolt(s, rng, v, group, origin=(0, 0), angle=0, reach=400,
          spread=114, root=35, width=23, fork_count=None):
    """Jagged parent bolt and irregular, explicitly attached fork graph."""
    ratios = [.0, .20, .33, .47, .62, .78, 1.0]
    wave = [0, -.13, .20, -.19, .29, -.04, .23]
    if v in (1, 4, 7):
        wave = [0, .15, -.29, .16, -.24, .18, -.06]
    hand = -1 if (group + v) % 2 else 1
    trunk = [(root + (reach - root) * t,
              hand * spread * wave[i] * (1 + .12 * (v % 3)))
             for i, t in enumerate(ratios)]
    _path(s, trunk, width, 0, group, .46, origin, angle)
    _tip(s, trunk[-1], 4.7, 2, group, origin, angle)
    n = fork_count if fork_count is not None else (2 + (1 if v in (2, 4, 6, 8, 9) else 0))
    indices = ((2, 4, 5), (1, 3, 4), (2, 3, 5), (1, 4, 5),
               (1, 2, 4), (2, 4, 5), (1, 2, 5), (2, 3, 4),
               (1, 3, 5), (1, 4, 5))[v]
    for j, index in enumerate(indices[:n]):
        p = trunk[index]
        sign = hand * (-1 if j % 2 == 0 else 1)
        if v in (4, 7):
            sign = -hand
        remaining = reach - p[0]
        endx = min(reach * (1.03 if v in (2, 8) else .96),
                   p[0] + max(reach * .21, remaining * .86))
        outer = sign * spread * (.77 + .16 * ((v + j) % 3))
        fork = [p, (p[0] + (endx - p[0]) * .29, outer * .58),
                (p[0] + (endx - p[0]) * .55, outer * .43),
                (p[0] + (endx - p[0]) * .76, outer),
                (endx, outer * .84)]
        _path(s, fork, max(7.0, width * (.59 - .055 * j)),
              1 if j % 2 == 0 else 0, group, .46, origin, angle)
        _tip(s, fork[-1], 4.1, 2, group, origin, angle)
        if (v + j) % 3 != 0:
            knee = fork[2]
            twig = [knee, (knee[0] + reach * .06, knee[1] - sign * spread * .31),
                    (min(reach * 1.01, knee[0] + reach * .17),
                     knee[1] - sign * spread * .24)]
            _path(s, twig, 3.4 + .35 * (v % 2), 2 if j == 0 else 1,
                  group, .48, origin, angle)
            _tip(s, twig[-1], 3.1, 2, group, origin, angle)
    _node(s, trunk[2 if v % 2 == 0 else 3],
          11.0 + 2 * (v % 3), "junction", 1, group, origin, angle)
    if v in (3, 5, 8, 9):
        # A detached-looking luminous sphere is actually centred on a parent
        # junction.  It is structurally connected and moves with that group.
        _node(s, trunk[4], 8.0 + v % 3, "orb", 2, group, origin, angle)
    if v == 9 and fork_count is not None:
        lead = [trunk[1], (trunk[1][0] + reach * .08, -hand * spread * .43),
                (trunk[1][0] + reach * .16, -hand * spread * .37)]
        _path(s, lead, 3.3, 2, group, .48, origin, angle)
        _tip(s, lead[-1], 3.3, 2, group, origin, angle)
    return trunk


def _lightning(subtype, variant, rng, seed):
    layouts = ["radial", "vertical", "horizontal", "diagonal", "fan",
               "triangular", "crown", "cross", "diagonal", "asymmetric"]
    s = _scene("Lightning", subtype, variant, seed, layouts[subtype])
    v = variant
    if subtype == 0:
        _node(s, (0, 0), 50, "hub", 0)
        for g, angle in enumerate((-92, 29, 150)):
            _bolt(s, rng, v, g, angle=angle,
                  reach=397 - 14 * ((v + g) % 3), spread=119, width=23.5)
        _ring(s, 444, 4.3, 3, 40 + 6 * (v % 3), -83, 1)
        s["main_assemblies"] = 3
    elif subtype == 1:
        origin = (0, 315)
        _node(s, origin, 49, "hub", 0)
        trunk = _bolt(s, rng, v, 0, origin, -90,
                      reach=685, spread=186 + 12 * (v % 3), root=0,
                      width=24, fork_count=3)
        for g, index in enumerate((1, 3, 4)):
            _node(s, trunk[index], 15 + g * 2, "junction", g % 2, 0,
                  origin, -90)
        if v in (0, 3, 6, 9):
            _ring(s, 378, 2.5, 2, 115, -35, 1, (0, -15))
        s["main_assemblies"] = 1
    elif subtype == 2:
        origin = (-315, -20 if v % 2 else 20)
        _node(s, origin, 50, "hub", 0)
        trunk = _bolt(s, rng, v, 0, origin, 0, reach=688,
                      spread=205, root=0, width=24, fork_count=3)
        for g, index in enumerate((1, 3, 4)):
            _node(s, trunk[index], 15 + g * 2, "junction", g % 2, 0, origin)
        if v in (2, 5, 8, 9):
            for side in (-1, 1):
                _ring(s, 65 + 5 * (v % 3), 3.0, 3, 36, -50, 1,
                      (118, side * 262), 0)
        s["main_assemblies"] = 1
    elif subtype == 3:
        a, b = (-220, -125), (220, 125)
        bridge = [a, (-119, -152), (-73, -25), (39, -49), (82, 104), b]
        _path(s, bridge, 24, 0, 0, .57)
        _node(s, a, 44, "hub", 0)
        _node(s, b, 44, "hub", 1)
        for g, (origin, angle, reach) in enumerate(((a, 165, 195),
                                                   (a, -82, 232),
                                                   (b, -15, 195),
                                                   (b, 98, 232))):
            _bolt(s, rng, v, g + 1, origin, angle, reach, 65,
                  root=0, width=20, fork_count=2)
        _node(s, bridge[2], 21, "junction", 2)
        _node(s, bridge[3], 17, "junction", 1)
        if v in (0, 3, 7, 9):
            _ring(s, 152, 3.0, 2, 95, -45, 1, a)
            _ring(s, 152, 3.0, 2, 95, 135, 0, b)
        s["main_assemblies"] = 4
    elif subtype == 4:
        origin = (-245, 247)
        _node(s, origin, 54, "hub", 0)
        angles = (-92, -64, -35, -6) if v not in (1, 4, 7) else (-90, -48, -6)
        for g, angle in enumerate(angles):
            _bolt(s, rng, v, g, origin, angle,
                  reach=510 + 15 * (g % 2) - 10 * (v % 3),
                  spread=49, root=0, width=22 - g * 1.5, fork_count=2)
        _ring(s, 397, 3.3, 2, 100, -85, 1, (8, -5))
        s["main_assemblies"] = len(angles)
    elif subtype == 5:
        vertices = [(0, -267), (253, 172), (-253, 172)]
        for g in range(3):
            a, b = vertices[g], vertices[(g + 1) % 3]
            dx, dy = b[0] - a[0], b[1] - a[1]
            length = math.hypot(dx, dy)
            angle = math.degrees(math.atan2(dy, dx))
            # Reaches the next junction exactly; the forks remain exterior.
            local = [(0, 0), (length * .22, -20), (length * .38, 19),
                     (length * .60, -23), (length * .79, 17), (length, 0)]
            if g == 1:
                # The bottom fixed hub is an explicit vertex of this rail.
                local.insert(3, (length * .5, 0))
            _path(s, local, 18 + v % 3, g % 2, g, .62, a, angle)
            fork_indices = ((1, 3), (1,), (2, 4), (1, 2, 4), (2, 3),
                            (1, 3, 4), (2,), (1, 2), (2, 3, 4), (1, 4))[v]
            for j, idx in enumerate(fork_indices):
                p = local[idx]
                sign = -1
                branch = [p, (p[0] + 32, p[1] + sign * 38),
                          (p[0] + 64, p[1] + sign * 25),
                          (p[0] + 93 + 7 * (v % 3), p[1] + sign * (65 + 7 * j))]
                _path(s, branch, 7.4, 1 if j else 0, g, .46, a, angle)
                _tip(s, branch[-1], 3.8, 2, g, a, angle)
            _node(s, a, 31 + 2 * (v % 3), "junction", g % 2, g)
        _node(s, (0, 172), 43, "hub", 0)
        if v in (1, 4, 7):
            _ring(s, 95, 2.0, 3, 38, -82, 2, (0, 20))
        else:
            _ring(s, 443, 3.3, 3, 53, -86, 1)
        s["main_assemblies"] = 3
    elif subtype == 6:
        _node(s, (0, 306), 51, "hub", 0)
        base = [(0, 306), (-15, 214), (19, 164), (0, 100)]
        _path(s, base, 24, 0, 0, .66)
        _node(s, (0, 100), 24, "junction", 2, 0)
        angles = (-155, -122, -90, -58, -25) if v % 3 != 1 else (-151, -110, -70, -29)
        for g, angle in enumerate(angles):
            reach = 365 + 110 * (1 - abs(angle + 90) / 70)
            _bolt(s, rng, v, g + 1, (0, 100), angle, reach, 47,
                  root=0, width=20, fork_count=2)
        _ring(s, 391, 3.2, 1, 133, 202, 1, (0, 20))
        s["main_assemblies"] = len(angles)
    elif subtype == 7:
        _node(s, (0, 0), 57, "hub", 0)
        for g, angle in enumerate((-90, 0, 90, 180)):
            trunk = _bolt(s, rng, v, g, angle=angle, reach=395 - 12 * (v % 3),
                          spread=88 + 7 * (v % 2), width=23)
            p = _transform(trunk[3], angle=angle)
            _ring(s, 31 + 5 * (v % 3), 2.3, 3, 37, -80, g % 2, p, g)
        s["main_assemblies"] = 4
    elif subtype == 8:
        origin = (-245, 245)
        _node(s, origin, 53, "hub", 0)
        trunk = _bolt(s, rng, v, 0, origin, -45, reach=694,
                      spread=167 + 8 * (v % 3), root=0, width=24, fork_count=3)
        for j, index in enumerate((1, 3, 5)):
            _node(s, trunk[index], 14 + 2 * j, "junction", j % 2, 0,
                  origin, -45)
        if v in (0, 2, 5, 9):
            _ring(s, 337, 3.8, 2, 103, -22, 1)
        s["main_assemblies"] = 1
    else:
        center = (-57 + 12 * (v % 3), 44 - 8 * (v % 2))
        _node(s, center, 51, "hub", 0)
        angles = (-118, -39, 31, 102, 178) if v % 3 != 1 else (-107, -12, 66, 164)
        for g, angle in enumerate(angles):
            reach = [344, 408, 339, 328, 300][g] + 10 * (v % 3)
            _bolt(s, rng, v, g, center, angle, reach, 77,
                  width=23 if g in (0, 1) else 17.5,
                  fork_count=3 if g % 2 == 0 else 2)
        s["main_assemblies"] = len(angles)
    s["description"] = (f"{s['subtype_name']}: {s['layout']} lightning architecture, "
                            f"composition {v + 1}; irregular connected zigzag forks, "
                            "amber metal, orange side rails and icy terminal lights.")
    return s


def _trident_arm(s, rng, v, group, origin=(0, 0), angle=0,
                 reach=404, spread=100, root=35, width=24, tip_nodes=False):
    early = v in (2, 4, 7)
    split = reach * (.44 if early else (.61 if v in (1, 5, 8) else .54))
    stem = [(root, 0), (reach * .23, 0), (split, 0)]
    _path(s, stem, width, 0, group, .8, origin, angle)
    center_end = reach * (.87 if v in (1, 5) else 1.04 if v in (2, 8) else 1.0)
    middle = [(split, 0), ((split + center_end) * .5, 0), (center_end, 0)]
    _path(s, middle, width * .68, 0, group, .53, origin, angle)
    _tip(s, middle[-1], 5.2, 2, group, origin, angle)
    junction_radius = min(30, max(18, spread * .24))
    _node(s, stem[-1], junction_radius, "junction", 2, group, origin, angle)
    _node(s, stem[1], 7.2 + v % 3, "junction", 1, group, origin, angle)
    if v == 9:
        feeder = [stem[1], (stem[1][0], spread * .28),
                  (split * .88, spread * .28)]
        _path(s, feeder, 3.2, 2, group, .8, origin, angle)
        _tip(s, feeder[-1], 3.2, 1, group, origin, angle)
    for j, hand in enumerate((-1, 1)):
        extent = spread * (1 + .09 * (v % 3))
        end = reach * (1.03 if v in (1, 5) else (.88 if v in (2, 8) else .96))
        if v in (3, 6, 9):
            # Strong right-angle outer knees alter the physical construction.
            side = [(split, 0), (split, hand * extent * .61),
                    (reach * .77, hand * extent * .61),
                    (reach * .77, hand * extent), (end, hand * extent)]
        else:
            asym = 1 + (.10 * hand if v in (4, 5, 8) else 0)
            side = [(split, 0), (split + (end - split) * .40, hand * extent * .70),
                    (end * .93, hand * extent * asym), (end, hand * extent * asym)]
        _path(s, side, width * (.73 if j == 0 else .66),
              0 if j == 0 else 1, group, .57, origin, angle)
        _tip(s, side[-1], 5.0 + .5 * (v % 2), 2, group, origin, angle)
        if tip_nodes or v in (2, 8):
            _node(s, side[-1], 12 + 2 * (v % 3), "junction", j,
                  group, origin, angle)
        if v in (0, 3, 7, 9):
            # One connected inset rail per side, not an unattached decoration.
            p = side[1]
            trace = [p, (p[0] + reach * .08, p[1] - hand * extent * .17),
                     (min(end * .96, p[0] + reach * .22),
                      p[1] - hand * extent * .17)]
            _path(s, trace, 3.0, 2, group, .8, origin, angle)
            _tip(s, trace[-1], 3.1, 1, group, origin, angle)
    return stem


def _trident(subtype, variant, rng, seed):
    layouts = ["vertical", "horizontal", "radial", "cross", "vertical",
               "fan", "twin towers", "triangular", "descending", "diagonal"]
    s = _scene("Trident", subtype, variant, seed, layouts[subtype])
    v = variant
    if subtype == 0:
        origin = (0, 295)
        _node(s, origin, 56, "hub", 0)
        _trident_arm(s, rng, v, 0, origin, -90, reach=650,
                     spread=205 + 10 * (v % 3), root=0, tip_nodes=True)
        _ring(s, 365, 4.0, 1, 112, 216, 1, (0, -30))
        s["main_assemblies"] = 1
    elif subtype == 1:
        _node(s, (0, 0), 64, "hub", 0)
        for g, angle in enumerate((0, 180)):
            _trident_arm(s, rng, v, g, angle=angle,
                         reach=391 - 8 * (v % 3), spread=156 + 7 * (v % 3),
                         tip_nodes=v in (1, 4, 7, 9))
        _ring(s, 250, 3.0, 2, 123, -35, 1)
        s["main_assemblies"] = 2
    elif subtype == 2:
        _node(s, (0, 0), 61, "hub", 0)
        for g, angle in enumerate((-90, 30, 150)):
            _trident_arm(s, rng, v, g, angle=angle,
                         reach=395 - 10 * (v % 3), spread=99,
                         tip_nodes=False)
        if v in (0, 3, 6, 9):
            _ring(s, 445, 3, 3, 54, -83, 1)
        s["main_assemblies"] = 3
    elif subtype == 3:
        _node(s, (0, 0), 57, "hub", 0)
        for g, angle in enumerate((-90, 0, 90, 180)):
            _trident_arm(s, rng, v, g, angle=angle,
                         reach=383 - 10 * (v % 3), spread=80 + 3 * (v % 3),
                         width=22)
        _ring(s, 440, 4.0, 4, 35, -70, 1)
        if v in (2, 5, 8):
            _ring(s, 151, 2.5, 4, 45, -80, 2)
        s["main_assemblies"] = 4
    elif subtype == 4:
        origins = [(0, 307), (0, 90), (0, -127)]
        _path(s, origins, 24, 0, 0, .8)
        _node(s, origins[0], 48, "hub", 0)
        for g, origin in enumerate(origins):
            _trident_arm(s, rng, v, g, origin, -90,
                         reach=231 - 5 * (v % 3),
                         spread=(158, 137, 111)[g], root=0, width=21)
            _ring(s, 51 + 4 * (v % 3), 2.6, 3, 37, -70, g % 2,
                  (0, origin[1] - 120), g)
        s["main_assemblies"] = 3
    elif subtype == 5:
        origin = (0, 285)
        _node(s, origin, 56, "hub", 0)
        angles = (-145, -90, -35) if v not in (1, 4, 7) else (-153, -111, -69, -27)
        for g, angle in enumerate(angles):
            reach = 460 + (112 if abs(angle + 90) < 25 else 0)
            _trident_arm(s, rng, v, g, origin, angle, reach,
                         62 if len(angles) == 4 else 77, root=0, width=22)
        _ring(s, 367, 4.0, 1, 125, 211, 1, (0, -5))
        s["main_assemblies"] = len(angles)
    elif subtype == 6:
        origins = [(-220, 234), (220, 234)]
        bridge = [origins[0], (-90, 234), (-90, 285),
                  (90, 285), (90, 234), origins[1]]
        _path(s, bridge, 22, 1, 2, .8)
        for g, origin in enumerate(origins):
            _node(s, origin, 47, "hub", g)
            _trident_arm(s, rng, v, g, origin, -90,
                         reach=585 - 8 * (v % 3), spread=91,
                         root=0, width=24, tip_nodes=v in (2, 5, 8))
        _node(s, bridge[2], 17, "junction", 2, 2)
        _node(s, bridge[3], 17, "junction", 0, 2)
        if v in (0, 3, 6, 9):
            _ring(s, 385, 2.5, 2, 112, -28, 1)
        s["main_assemblies"] = 2
    elif subtype == 7:
        vertices = [(0, -166), (170, 118), (-170, 118)]
        _path(s, vertices + [vertices[0]], 18, 1, 3, .8)
        _node(s, (0, 118), 43, "hub", 0)
        _path(s, [vertices[1], (0, 118), vertices[2]], 15, 0, 3, .8)
        for g, (origin, angle) in enumerate(zip(vertices, (-90, 30, 150))):
            _node(s, origin, 29, "junction", g % 2, g)
            _trident_arm(s, rng, v, g, origin, angle,
                         reach=229 - 7 * (v % 3), spread=62,
                         root=0, width=21)
        if v in (1, 4, 7):
            _ring(s, 73, 2.4, 3, 50, -80, 2, (0, -6))
        else:
            _ring(s, 441, 3.1, 3, 53, -82, 1)
        s["main_assemblies"] = 3
    elif subtype == 8:
        origin = (0, -303)
        _node(s, origin, 52, "hub", 0)
        main = _trident_arm(s, rng, v, 0, origin, 90,
                            reach=610 - 7 * (v % 3), spread=188,
                            root=0, width=24)
        # Small side harpoons grow from the primary split.  Their roots share
        # the exact primary junction and their silhouettes point downward.
        split_world = _transform(main[-1], origin, 90)
        for g, angle in enumerate((39, 141)):
            _trident_arm(s, rng, v, g + 1, split_world, angle,
                         reach=259 - 8 * (v % 3), spread=59,
                         root=0, width=18, tip_nodes=v in (2, 5, 8))
        _ring(s, 375, 3, 1, 129, 27, 1, (0, 12))
        s["main_assemblies"] = 3
    else:
        origin = (-244, 244)
        _node(s, origin, 54, "hub", 0)
        main = _trident_arm(s, rng, v, 0, origin, -45,
                            reach=670 - 8 * (v % 3), spread=145,
                            root=0, width=24, tip_nodes=True)
        junction = _transform(main[-1], origin, -45)
        _trident_arm(s, rng, v, 1, junction, 135,
                     reach=263 - 7 * (v % 3), spread=103,
                     root=0, width=18)
        _ring(s, 348, 3.3, 2, 118, -17, 1)
        s["main_assemblies"] = 2
    s["description"] = (f"{s['subtype_name']}: {s['layout']} three-prong machinery; "
                            f"composition {v + 1} uses substantial connected stems, "
                            "scarlet and titanium tines, amber collars and circular junctions.")
    return s


def _finish(s):
    """Keep every body, terminal, halo and shadow inside a safe logical margin."""
    extent = 0.0
    for p in s["paths"]:
        for x, y in p["points"]:
            extent = max(extent, abs(x) + p["width"] / 2 + 6,
                         abs(y) + p["width"] / 2 + 8)
    for obj in s["nodes"] + s["tips"]:
        extent = max(extent, *(abs(q) + obj["radius"] + 8 for q in obj["pos"]))
    for r in s["rings"]:
        extent = max(extent, *(abs(q) + r["radius"] + r["width"] / 2 + 8
                              for q in r["center"]))
    scale = min(1.0, 456.0 / max(1, extent))
    if scale < 1:
        for p in s["paths"]:
            p["points"] = [_round_point((x * scale, y * scale)) for x, y in p["points"]]
            p["width"] = max(2.0, round(p["width"] * scale, 5))
        for obj in s["nodes"] + s["tips"]:
            obj["pos"] = _round_point([q * scale for q in obj["pos"]])
            obj["radius"] = round(obj["radius"] * scale, 5)
        for r in s["rings"]:
            r["center"] = _round_point([q * scale for q in r["center"]])
            r["radius"] = round(r["radius"] * scale, 5)
            r["width"] = round(r["width"] * scale, 5)
        for anchor in s["anchor_points"]:
            anchor["pos"] = _round_point([q * scale for q in anchor["pos"]])
    s["assembly_groups"] = sorted({p["group"] for p in s["paths"]})
    s["normalization_scale"] = round(scale, 7)
    return s


def _variant_identity(s):
    """Give each of the nine previews a visible composition and circle hierarchy.

    These choices supplement the builder's different fork graphs.  In particular,
    a single three-prong sculpture needs more than different random fork lengths
    to remain recognisable as a separately composed artwork at thumbnail scale.
    Volumetric variant nine preserves the representative architectural framing.
    """
    v = s["variant"]
    if v == 9:
        s["variant_composition"] = "Layered architectural representative"
        return s
    aspects = [(1, 1), (1.18, .83), (.81, 1.12), (1.05, .98),
               (.94, 1.06), (.76, 1.08), (1.20, .85), (.90, 1.04), (1.25, .82)]
    sx, sy = aspects[v]
    def stretch(p):
        return _round_point((p[0] * sx, p[1] * sy))
    for path in s["paths"]:
        path["points"] = [stretch(p) for p in path["points"]]
    for obj in s["nodes"] + s["tips"]:
        obj["pos"] = stretch(obj["pos"])
    for ring in s["rings"]:
        ring["center"] = stretch(ring["center"])
    for anchor in s["anchor_points"]:
        anchor["pos"] = stretch(anchor["pos"])
    for facet in s["facets"]:
        facet["points"] = [stretch(p) for p in facet["points"]]
    # Preserve purposeful small node rings, while changing the large framing
    # architecture.  This creates clear differences in circular figure counts.
    if v != 0:
        s["rings"] = [r for r in s["rings"] if r["radius"] < 300]
    if v == 2:
        _ring(s, 399, 3.6, 4, 42, -73, 1)
        _ring(s, 445, 5.4, 8, 18, -79, 0)
    elif v == 3:
        junctions = sorted((n for n in s["nodes"] if n["style"] == "junction"),
                           key=lambda n: -n["radius"])
        for j, node in enumerate(junctions[:2]):
            _ring(s, node["radius"] * (1.58 + j * .15), 3.2, 3, 40,
                  -80 + 30 * j, j, node["pos"], node["group"])
    elif v == 4:
        _ring(s, 398, 4.6, 2, 69, -65, 1, (-28, 24))
    elif v == 5:
        _ring(s, 134, 3.5, 2, 48, -77, 2)
        _ring(s, 207, 2.0, 4, 46, -70, 1)
    elif v == 6:
        _ring(s, 430, 5.8, 3, 50, -85, 0)
        _ring(s, 306, 2.6, 3, 73, -76, 1)
    elif v == 7:
        hubs = [n for n in s["nodes"] if n["style"] == "hub"]
        if hubs:
            _ring(s, hubs[0]["radius"] * 1.42, 2.4, 4, 37, -70, 2,
                  hubs[0]["pos"], hubs[0]["group"])
    elif v == 8:
        for radius, width, segments, gap, color in ((356, 2.3, 2, 71, 1),
                                                    (401, 3.8, 4, 39, 2),
                                                    (445, 5.8, 8, 16, 0)):
            _ring(s, radius, width, segments, gap, -77, color)
    # Change circular terminals on selected compositions.  Farthest-point
    # selection distributes the major lights rather than clustering them.
    count = {1: 2, 4: 3, 7: 4, 8: 2}.get(v, 0)
    count = min(count, max(0, 24 - len(s["nodes"])))
    candidates = sorted(s["tips"], key=lambda t: -math.hypot(*t["pos"]))
    chosen = []
    while candidates and len(chosen) < count:
        if not chosen:
            pick = candidates.pop(0)
        else:
            pick = max(candidates, key=lambda t: min(math.dist(t["pos"], q["pos"])
                                                     for q in chosen))
            candidates.remove(pick)
        if any(math.dist(pick["pos"], q["pos"]) < 45 for q in chosen):
            continue
        chosen.append(pick)
    for j, tip in enumerate(chosen):
        # Replace an existing terminal collar, if any, instead of hiding it
        # beneath a second independent circular object at the same coordinate.
        s["nodes"] = [n for n in s["nodes"] if math.dist(n["pos"], tip["pos"]) > .01]
        _node(s, tip["pos"], 16 + 2.5 * (j % 3),
              "orb" if v in (1, 4) else "junction", 2 if j % 2 == 0 else 1,
              tip.get("group", 0))
        s["tips"].remove(tip)
    titles = ["Balanced architectural frame", "Broad open terminals",
              "Elongated double halo", "Stepped circular collars",
              "Offset halo and luminous satellites", "Slender nested centre",
              "Wide broken-ring structure", "Large terminal junctions",
              "Broad triple-halo array"]
    s["variant_composition"] = titles[v]
    s["description"] += " " + titles[v] + "."
    return s


def build(family: str, subtype: int, variant: int, seed: int):
    if family not in SUBTYPES:
        raise ValueError(f"Unsupported family: {family}")
    if not 0 <= subtype <= 9 or not 0 <= variant <= 9:
        raise ValueError("Subtype and variant must be in 0..9")
    rng = random.Random(int(seed))
    fn = {"Circuit": _circuit, "Lightning": _lightning, "Trident": _trident}[family]
    return _finish(_variant_identity(fn(subtype, variant, rng, int(seed))))


def _selftest():
    import hashlib
    import json
    fingerprints = set()
    stats = {}
    for family in SUBTYPES:
        rows = []
        for subtype in range(10):
            for variant in range(10):
                scene = build(family, subtype, variant,
                              110000000 + list(SUBTYPES).index(family) * 10000 + subtype * 100 + variant)
                assert 1 <= len(scene["paths"]) <= 65, (family, subtype, variant, len(scene["paths"]))
                assert len(scene["nodes"]) >= 4, (family, subtype, variant, "few nodes")
                for path in scene["paths"]:
                    assert 2 <= path["width"] <= 24
                    assert .45 <= path["taper"] <= .85
                    for a, b in zip(path["points"], path["points"][1:]):
                        assert math.dist(a, b) > 1e-5
                    for x, y in path["points"]:
                        assert math.isfinite(x) and math.isfinite(y)
                        assert max(abs(x), abs(y)) + path["width"] / 2 + 8 < 470
                for node in scene["nodes"] + scene["tips"]:
                    assert max(map(abs, node["pos"])) + node["radius"] + 8 < 470
                for ring in scene["rings"]:
                    assert max(map(abs, ring["center"])) + ring["radius"] + ring["width"] / 2 + 8 < 470
                    assert 360 / ring["segments"] - ring["gap"] > 0
                # Every connected rail component must meet a real fixed hub.
                parents = {}
                def find(q):
                    if q not in parents:
                        parents[q] = q
                    while parents[q] != q:
                        parents[q] = parents[parents[q]]
                        q = parents[q]
                    return q
                for path in scene["paths"]:
                    vertices = [tuple(p) for p in path["points"]]
                    for a, b in zip(vertices, vertices[1:]):
                        parents[find(a)] = find(b)
                hubs = [n for n in scene["nodes"] if n["style"] == "hub"]
                grounded = {find(p) for p in parents if any(
                    math.dist(p, h["pos"]) < h["radius"] for h in hubs)}
                assert {find(p) for p in parents} <= grounded, (family, subtype, variant, "unanchored rail")
                media_geometry = {k: scene[k] for k in ("paths", "tips", "rings", "nodes", "facets")}
                fingerprint = hashlib.sha256(json.dumps(media_geometry, sort_keys=True).encode()).hexdigest()
                assert fingerprint not in fingerprints, (family, subtype, variant, "duplicate geometry")
                fingerprints.add(fingerprint)
                rows.append((len(scene["paths"]), len(scene["nodes"])))
        stats[family] = {"items": len(rows), "paths_min_max": [min(x[0] for x in rows), max(x[0] for x in rows)],
                         "nodes_min_max": [min(x[1] for x in rows), max(x[1] for x in rows)]}
    print(json.dumps({"unique_geometries": len(fingerprints), "families": stats}, indent=2))


if __name__ == "__main__":
    _selftest()
