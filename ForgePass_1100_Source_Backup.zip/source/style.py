"""Forge Pass V2: reproducible dimensional branch studies, native supersampling.
Geometry is newly constructed for this review; no input artwork is edited.
"""
from pathlib import Path
import math,json,hashlib,concurrent.futures,argparse
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageChops, ImageFont, PngImagePlugin
ROOT=Path(__file__).resolve().parents[1]
PALETTES={
 'Circuit':[(20,190,226),(39,82,215),(199,230,245)],
 'Lightning':[(248,170,39),(234,72,24),(211,241,255)],
 'Coral':[(163,70,231),(24,202,194),(248,96,179)],
 'Frost':[(101,202,239),(186,208,231),(168,137,235)],
 'Roots':[(28,166,96),(23,181,175),(239,186,75)],
 'Trident':[(217,45,69),(95,114,144),(246,163,45)],
 'Crown':[(224,164,42),(154,170,227),(244,234,200)],
 'Lattice':[(41,105,229),(158,72,224),(34,214,220)],
 'Cascade':[(179,207,222),(31,184,185),(72,101,173)],
 'Bonsai':[(193,111,66),(48,166,126),(230,184,80)],
 'Starburst':[(209,139,132),(45,108,201),(230,225,212)]
}
ORDER=list(PALETTES)
CAPTIONS={
 'Circuit':'6 angular arms / 2 segmented rings',
 'Lightning':'3 jagged arms / 1 broken ring',
 'Coral':'4 flowing arms / 3 halo rings',
 'Frost':'8 crystal arms / 1 fine ring',
 'Roots':'Asymmetric roots / 1 offset halo',
 'Trident':'3 tridents / 3 large junctions',
 'Crown':'Upward fan / 1 open halo',
 'Lattice':'4 diagonal assemblies / 4 nodes',
 'Cascade':'Hanging branches / 2 offset halos',
 'Bonsai':'1 sculptural trunk / 7 golden fruits',
 'Starburst':'12 alternating rays / 3 rings'
}
_cache={}
def colour(c,f=1,white=0):return tuple(int(np.clip(v*f+(255-v*f)*white,0,255)) for v in c)
def mix(a,b,t):return tuple(int(x*(1-t)+y*t) for x,y in zip(a,b))
def ribbon(path,widths):
 path=np.array(path,dtype=float);delta=np.diff(path,axis=0);norm=np.linalg.norm(delta,axis=1)
 if np.any(norm<1e-7):raise ValueError('Zero-length rail segment')
 directions=delta/norm[:,None];normals=np.stack([-directions[:,1],directions[:,0]],axis=1);sides=[]
 for i in range(len(path)):
  if i==0:n=normals[0]
  elif i==len(path)-1:n=normals[-1]
  else:
   n=normals[i-1]+normals[i];m=np.linalg.norm(n)
   if m<1e-6:n=normals[i]
   else:n=n/m/max(.64,float(np.dot(n/m,normals[i])))
  sides.append(n*widths[i]/2)
 sides=np.array(sides);return path+sides,path-sides
class Painter:
 def __init__(self,im,ss):self.im=im;self.d=ImageDraw.Draw(im);self.ss=ss
 def point(self,p,offset=(0,0)):return ((p[0]+512+offset[0])*self.ss,(p[1]+512+offset[1])*self.ss)
 def polygon(self,ps,col,offset=(0,0)):self.d.polygon([self.point(p,offset) for p in ps],fill=tuple(col))
 def line(self,ps,col,width,offset=(0,0)):
  self.d.line([self.point(p,offset) for p in ps],fill=tuple(col),width=max(1,round(width*self.ss)),joint='curve')
 def circle(self,p,r,col=None,outline=None,width=1,offset=(0,0)):
  x,y=self.point(p,offset);r*=self.ss;self.d.ellipse((x-r,y-r,x+r,y+r),fill=col,outline=outline,width=max(1,round(width*self.ss)))
 def arc(self,c,r,start,end,width,col,offset=(0,0)):
  x,y=self.point(c,offset);r*=self.ss
  self.d.arc((x-r,y-r,x+r,y+r),start,end,fill=tuple(col),width=max(1,round(width*self.ss)))

def background(native,palette):
 key=(native,tuple(palette[0]))
 if key not in _cache:
  yy,xx=np.ogrid[-1:1:complex(native),-1:1:complex(native)]
  rr=np.sqrt(xx*xx+yy*yy);v=np.maximum(0,1-rr*.8)
  tint=np.array(palette[0],float)/255
  data=np.empty((native,native,3),dtype=np.uint8)
  for channel,(floor,extra) in enumerate([(3,4),(5,5),(10,7)]):data[:,:,channel]=floor+v*(extra+tint[channel]*3)
  _cache[key]=Image.fromarray(data)
 return _cache[key].copy()

def rail(p,rec,palette):
 pts=np.array(rec['points'],float);width=float(rec['width']);base=palette[rec.get('color',0)]
 distances=np.r_[0,np.cumsum(np.linalg.norm(np.diff(pts,axis=0),axis=1))]
 progress=distances/max(1e-8,distances[-1]);ws=width*(1-progress*(1-rec.get('taper',.62)))
 left,right=ribbon(pts,ws);shape=np.concatenate([left,right[::-1]])
 depth=min(6,max(1.4,width*.24));offset=(depth*.65,depth*1.25)
 p.polygon(shape,colour(base,.15),offset)
 p.polygon(shape,colour(base,.30))
 # Bevelled solid body; nested faces give the rail a readable raised cross-section.
 for fraction,brightness in [(.88,.52),(.72,.84),(.54,1.0),(.31,1.08)]:
  l,r=ribbon(pts,ws*fraction);p.polygon(np.concatenate([l,r[::-1]]),colour(base,brightness))
 left,right=ribbon(pts,ws*.77)
 for i,(a,b) in enumerate(zip(pts[:-1],pts[1:])):
  v=b-a;n=np.array([-v[1],v[0]])/np.linalg.norm(v);face=float(np.dot(n,[-.707,-.707]))
  edge=left if face>0 else right
  p.line([edge[i],edge[i+1]],colour(base,.9,.48),max(.55,width*.065))
 if width>10:
  p.line(pts,colour(base,.43),max(.65,width*.055))
  if len(pts)<10:
   for q in pts[1:-1]:
    p.circle(q,min(4.6,width*.22),colour(base,.24));p.circle(q,min(2.5,width*.12),colour(base,.9,.28))

def ring(p,r,palette):
 c=r.get('center',[0,0]);radius=r['radius'];w=r.get('width',4);segments=r.get('segments',1);gap=r.get('gap',0);start=r.get('start',0);base=palette[r.get('color',0)]
 span=360/segments-gap
 for i in range(segments):
  a=start+i*360/segments;b=a+span
  p.arc(c,radius+1,a,b,w+3,colour(base,.13),(2.4,4.7))
  p.arc(c,radius,a,b,w+1.5,colour(base,.29))
  p.arc(c,radius-.6,a,b,max(.65,w*.70),colour(base,.9))
  p.arc(c,radius-1.1,a,b,max(.5,w*.16),colour(base,1,.45))

def orb(p,pos,r,base):
 key=('sphere',round(r*p.ss,4),tuple(base))
 if key not in _cache:
  radius=r*p.ss;half=math.ceil(radius)+2;n=half*2+1
  yy,xx=np.mgrid[:n,:n].astype(np.float32);nx=(xx-half)/radius;ny=(yy-half)/radius;rr=nx*nx+ny*ny
  nz=np.sqrt(np.maximum(0,1-rr));inside=rr<=1
  light=np.array([-.45,-.55,.76],dtype=float);light/=np.linalg.norm(light)
  diffuse=np.maximum(0,nx*light[0]+ny*light[1]+nz*light[2])
  halfway=light+np.array([0,0,1]);halfway/=np.linalg.norm(halfway)
  spec=np.maximum(0,nx*halfway[0]+ny*halfway[1]+nz*halfway[2])**40
  intensity=.13+.87*diffuse
  rgb=np.asarray(base)[None,None,:]*intensity[:,:,None]+spec[:,:,None]*205
  alpha=(inside*255).astype(np.uint8)
  rgba=np.dstack([np.clip(rgb,0,255).astype(np.uint8),alpha]);_cache[key]=(Image.fromarray(rgba),half)
 sphere,half=_cache[key]
 p.circle(pos,r+.6,colour(base,.08),offset=(1.1,1.9))
 x,y=p.point(pos);p.im.paste(sphere,(round(x-half),round(y-half)),sphere)

def hub(p,node,palette,family):
 c=node['pos'];r=node['radius'];base=palette[node.get('color',0)];secondary=palette[1];accent=palette[2]
 if node.get('style')=='orb':orb(p,c,r,base);return
 if node.get('style')=='junction':
  p.circle(c,r+2,colour(base,.12),offset=(2,4));p.circle(c,r,colour(base,.2))
  for factor,w,col in [( .94,1,colour(base,.8,.4)),(.77,r*.11,base),(.57,1,colour(secondary,1,.25))]:p.circle(c,r*factor,None,col,w)
  orb(p,c,r*.28,accent);return
 p.circle(c,r+2,(2,5,10),offset=(3,5))
 p.circle(c,r,colour(base,.22))
 for step in range(int(r*.95),0,-1):
  t=1-step/r;p.circle((c[0]-r*.024,c[1]-r*.037),step,mix((5,10,18),colour(base,.32),t))
 for f,w,col in [(.96,1,colour(base,.9,.38)),(.87,.045,colour(base,.47)),(.76,.085,colour(base,.12)),(.66,.035,colour(secondary,.95)),(.53,.08,colour(base,.33)),(.43,.02,colour(accent,.9))]:p.circle(c,r*f,None,col,max(.65,r*w) if w<1 else w)
 for a in range(0,360,60):
  q=(c[0]+math.cos(math.radians(a-30))*r*.82,c[1]+math.sin(math.radians(a-30))*r*.82)
  p.circle(q,r*.025,colour(accent,1,.3))
 verts=[(c[0]+r*.31*math.cos(math.radians(30+i*60)),c[1]+r*.31*math.sin(math.radians(30+i*60))) for i in range(6)]
 for i in range(6):
  col=mix(base,accent,.40) if i%2 else mix(base,secondary,.35)
  p.polygon([c,verts[i],verts[(i+1)%6]],colour(col,[1.05,.76,.5,.65,1.15,1.0][i],.18 if i==4 else 0))
 p.circle((c[0]-r*.05,c[1]-r*.06),r*.055,colour(accent,1,.65))

def render(geometry,size=2048,supersample=2):
 palette=PALETTES[geometry['name']];ss=size/1024*supersample;native=round(1024*ss)
 im=background(native,palette);p=Painter(im,ss)
 for r in geometry['rings']:ring(p,r,palette)
 for fac in geometry.get('facets',[]):
  col=palette[fac.get('color',0)];p.polygon(fac['points'],colour(col,.38));p.line(fac['points']+[fac['points'][0]],colour(col,.8,.2),.7)
 for rec in sorted(geometry['paths'],key=lambda x:-x['width']):rail(p,rec,palette)
 for tip in geometry['tips']:orb(p,tip['pos'],tip.get('radius',3),palette[tip.get('color',2)])
 for node in geometry['nodes']:hub(p,node,palette,geometry['name'])
 # Controlled light spill, preserving sharp surface edges.
 emission=im.point([max(0,round((v-140)*.12)) for v in range(256)]*3)
 im=ImageChops.add(im,emission.filter(ImageFilter.GaussianBlur(ss*1.5)))
 return im.resize((size,size),Image.Resampling.LANCZOS)

def font(size,bold=False):
 names=['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf']
 for name in names:
  if Path(name).exists():return ImageFont.truetype(name,size)
 return ImageFont.load_default(size=size)
