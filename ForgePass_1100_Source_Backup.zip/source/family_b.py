"""Thirty visibly distinct organic architectures for FORGE PASS 1100.

Only standard-library modules are used. All forks start on an exact sampled
point of a previously emitted parent. Variant controls alter branching topology,
canopy breadth, fork arrangement, ring configuration, and fruit placement.
"""
from __future__ import annotations

import hashlib
import json
import math
import random


CORAL_NAMES = ["Four-Lobe Reef", "Twin Anemones", "Upright Reef", "Reef Bridge",
               "Spiral Colony", "Coral Bowl", "Hanging Reef", "Crescent Reef",
               "Three Colonies", "Asymmetric Fan"]
ROOTS_NAMES = ["Grounded Tree", "Radial Root Web", "Downward Root Mass", "Twin Trunks",
               "Root Bridge", "Rising Antlers", "Offset Root Fan", "Split Vertical",
               "Root Crescent", "Mangrove"]
BONSAI_NAMES = ["S-Curve Trunk", "Twin-Trunk Grove", "Windswept", "Cascade Bonsai",
                "Umbrella Canopy", "Layered Pagoda", "Split Arch", "Three-Tree Forest",
                "Slanting Canopy", "Living Root Bridge"]


def add(a, b): return [a[0] + b[0], a[1] + b[1]]
def mul(a, s): return [a[0] * s, a[1] * s]
def polar(r, deg): return [r*math.cos(math.radians(deg)), r*math.sin(math.radians(deg))]


def resample(ends, count):
    """Distribute major supports across a template's complete architectural span."""
    if count == len(ends): return [list(q) for q in ends]
    if count == 1: return [list(ends[len(ends)//2])]
    result=[]
    for i in range(count):
        at=i*(len(ends)-1)/(count-1);lo=int(at);hi=min(len(ends)-1,lo+1);t=at-lo
        result.append([ends[lo][j]*(1-t)+ends[hi][j]*t for j in (0,1)])
    return result


def bezier(a, b, c, d, n=25):
    result = []
    for i in range(n):
        t = i/(n-1); u = 1-t
        result.append([u*u*u*a[k] + 3*u*u*t*b[k] + 3*u*t*t*c[k] + t*t*t*d[k]
                       for k in (0, 1)])
    result[0] = list(a); result[-1] = list(d)
    return result


class Design:
    def __init__(self, family, subtype, variant, seed):
        self.family = family; self.variant = variant; self.rng = random.Random(seed)
        self.data = dict(name=family, subtype_name=subtype,
                         description="", layout=subtype.lower().replace(' ', '_'),
                         main_assemblies=0, paths=[], tips=[], rings=[], nodes=[], facets=[], anchor_points={})
        # Distinct, deterministic growth plans: no variant is just a seed change.
        self.levels = [(8, 16), (7, 13, 19), (6, 11, 16, 21), (8, 17),
                       (7, 14, 20), (6, 12, 18, 22), (7, 15), (8, 14, 20),
                       (6, 10, 15, 20), (7, 13, 19)][variant]
        self.spread = [.78, 1.0, .90, 1.23, 1.08, .82, 1.15, .96, 1.17, 1.04][variant]

    def count(self, original, values):
        return original if self.variant == 9 else values[self.variant]

    def path(self, pts, width, color=0, group=0, taper=.57, tip=False, radius=3.5):
        p = [[float(x), float(y)] for x, y in pts]
        self.data['paths'].append(dict(points=p, width=float(width), taper=float(taper),
                                       color=int(color), group=int(group)))
        self.data['anchor_points'].setdefault(str(group), list(p[0]))
        if tip: self.tip(p[-1], radius, color, group)
        return p

    def curve(self, a, b, c, e, width, color=0, group=0, taper=.55, tip=False,
              radius=3.5, n=25):
        return self.path(bezier(a, b, c, e, n), width, color, group, taper, tip, radius)

    def tip(self, p, radius=3.5, color=2, group=0):
        self.data['tips'].append(dict(pos=list(p), radius=float(radius), color=int(color), group=int(group)))

    def node(self, p, radius=35, style='hub', color=0):
        group = next((q['group'] for q in reversed(self.data['paths'])
                      if any(x == list(p) for x in q['points'])), 0)
        self.data['nodes'].append(dict(pos=list(p), radius=float(radius), style=style,
                                       color=int(color), group=int(group)))

    def ring(self, c, r, width=2.1, segments=1, gap=0, start=0, color=1):
        self.data['rings'].append(dict(center=list(c), radius=float(r), width=float(width),
                                       segments=int(segments), gap=float(gap), start=float(start), color=int(color)))

    def stem(self, root, c1, c2, end, width, group, color=0):
        vx, vy = end[0]-root[0], end[1]-root[1]
        length = math.hypot(vx, vy); normal = [-vy/length, vx/length]
        # Substantial controlled changes to trunk curvature supplement the
        # discrete fork plans. Shared endpoints stay exact, including arch peaks.
        bend = [-.065, .045, -.095, .080, -.025, .105, -.110, .065, -.045, .018][self.variant]
        modulation = 1 + .13*((group+self.variant) % 3-1)
        c1 = add(c1, mul(normal, length*bend*modulation))
        c2 = add(c2, mul(normal, -length*bend*.54*modulation))
        width *= [.91, 1, .95, .88, .98, .92, 1, .94, .90, 1][self.variant]
        return self.curve(root, c1, c2, end, width, color, group, .48, True, 4.6)

    def forks(self, stem, group, width=8.5, reach=82, levels=None, both=False, fine=True,
              lean=1, color=1):
        """Growing forks attach at exact parent samples, with local tangent frames."""
        levels = self.levels if levels is None else levels
        for k, ix in enumerate(levels):
            q = stem[ix]
            tangent = [stem[ix+1][0]-stem[ix-1][0], stem[ix+1][1]-stem[ix-1][1]]
            tangent = mul(tangent, 1/math.hypot(*tangent)); normal = [-tangent[1], tangent[0]]
            signs = (-1, 1) if both else ((-1 if (k+self.variant) % 2 else 1)*lean,)
            for sign in signs:
                span = reach*self.spread*(1-.10*k)
                forward = span*(.43 if self.variant % 3 else .72)
                end = add(add(q, mul(tangent, forward)), mul(normal, sign*span))
                fork = self.curve(q, add(q, mul(tangent, span*.46)),
                                  add(end, mul(normal, -sign*span*.26)), end,
                                  max(3.4, width-k*.7), color, group, .48, True, 3.8, n=19)
                if fine and (k+self.variant) % 3 != 1:
                    fr = fork[11 if self.variant % 2 else 13]
                    e2 = add(fr, add(mul(tangent, span*.43), mul(normal, -sign*span*.36)))
                    self.curve(fr, add(fr, mul(tangent, span*.22)),
                               add(e2, mul(tangent, -span*.12)), e2, 3.3, 2, group,
                               .52, True, 2.9, n=15)

    def canopy(self, stem, group, breadth=128, levels=(9, 15, 20), fruit=True):
        """Copper woody boughs carrying jade forked shoots and golden fruit."""
        shift = [-1, 1, -2, 0, 2, -1, 1, -2, 0, 0][self.variant]
        levels = tuple(max(5, min(22, ix+shift)) for ix in levels)
        if self.variant < 9:
            # Distinct crown masses: two-tier, stacked, alternating, or spreading.
            if self.variant in (0, 6): levels = (levels[0], levels[-1])
            elif self.variant == 2 and len(levels) < 4 and breadth >= 110: levels = (6, 11, 16, 21)
            elif self.variant == 5: levels = (7, 16, 22)
            breadth *= [.82, 1.18, .94, 1.30, 1.03, .80, 1.25, .93, 1.18][self.variant]
        for k, ix in enumerate(levels):
            root = stem[ix]
            signs = (-1, 1) if (k+self.variant) % 3 != 1 else ((-1 if k % 2 else 1),)
            if self.variant in (3, 6): signs = ((-1 if k % 2 else 1),)
            elif self.variant in (1, 7): signs = (-1, 1)
            for sign in signs:
                reach = breadth*self.spread*(1-.13*k)
                rise = 36+13*((k+self.variant) % 3)
                end = [root[0]+sign*reach, root[1]-rise]
                b = self.curve(root, [root[0]+sign*reach*.35, root[1]+10],
                               [end[0]-sign*reach*.2, end[1]+24], end,
                               10.5-k*1.1, 0, group, .48)
                shoot_count = 2 + int((k+self.variant) % 3 == 0)
                for j in range(shoot_count):
                    at = 12+4*j; q = b[at]
                    ex = q[0]+sign*(22+9*j)
                    ey = q[1]-(41+9*((j+self.variant) % 3))
                    s = self.curve(q, [q[0]+sign*5, q[1]-22], [ex-sign*8, ey+17],
                                   [ex, ey], 4.5 if j else 5.8, 1, group, .58,
                                   True, 3.2, n=17)
                    if fruit and (k+j+self.variant) % 3 == 0:
                        # Fruit is centred on its branch endpoint, never floating nearby.
                        self.node(s[-1], 7.2+1.7*((k+j+self.variant) % 3), 'orb', 2)
                if fruit and (k+self.variant) % 2 == 0:
                    self.node(b[-1], 8.5, 'orb', 2)

    def finish(self, description, assemblies):
        self.data['description'] = description
        self.data['main_assemblies'] = int(assemblies)
        if self.variant in (1, 4, 7):
            # Alternate broken halo configurations have visibly different gaps.
            for r in self.data['rings']:
                r['segments'] = min(6, r['segments']+1)
                r['gap'] = min(360/r['segments']*.48, 16+8*(self.variant//3))
                r['start'] += 17+11*(self.variant//3)
        if self.variant in (2, 5, 8):
            # Junction counts vary structurally, at exact existing branch roots.
            candidates = [p for p in self.data['paths'] if 5 <= p['width'] <= 12]
            step = max(1, len(candidates)//(2+self.variant//3))
            for p in candidates[::step][:2+self.variant//3]:
                self.node(p['points'][0], 8.5+1.5*(self.variant//3), 'junction', 1)
        if self.variant < 9:
            # All objects share this exact coordinate map: connected trunks and
            # forks remain connected while the composition changes substantially.
            sx,sy,shear,bow = [(.78,1.04,-.08,.050),(1.17,.82,.10,-.030),
                              (.98,1.02,-.16,.045),(.84,1.14,.18,-.055),
                              (1.24,.91,-.05,.025),(1.02,.84,-.21,-.040),
                              (.88,1.10,-.14,.060),(1.16,.97,.17,-.025),
                              (.94,1.13,.04,.035)][self.variant]
            def warp(q):
                x,y=q
                return [sx*x+shear*y+bow*(y*y/350-125), sy*y+.055*x*y/350]
            for p in self.data['paths']:
                p['points']=[warp(q) for q in p['points']]
                if p['width'] > 10: p['width'] *= [1,.88,1,.91,1,.83,.97,.86,1][self.variant]
            for p in self.data['nodes']+self.data['tips']: p['pos']=warp(p['pos'])
            self.data['anchor_points']={k:warp(p) for k,p in self.data['anchor_points'].items()}
            for r in self.data['rings']:
                r['center']=warp(r['center']);r['radius']*=min(1.05,max(.85,(sx+sy)/2))
            if self.data['rings']:
                if self.variant in (0,3,6): self.data['rings']=self.data['rings'][:1]
                if self.variant in (2,5,8):
                    r=self.data['rings'][0]
                    self.ring(r['center'],r['radius']*(.64 if self.variant==2 else .81),
                              2.2+(.5 if self.variant==8 else 0),
                              segments=(2,3,4)[self.variant//3],gap=35,start=17,color=2)
        # Geometry-dependent rings vary in number/configuration, not just colour.
        # Their exact centres and radii remain inside the renderer's safe bounds.
        extent = 1.0
        for p in self.data['paths']:
            extent = max(extent, *(math.hypot(*q)+p['width']*.65+8 for q in p['points']))
        for p in self.data['nodes']+self.data['tips']:
            extent = max(extent, math.hypot(*p['pos'])+p['radius']+8)
        for r in self.data['rings']:
            extent = max(extent, math.hypot(*r['center'])+r['radius']+r['width']+8)
        scale = min(1.0, 440/extent)
        if scale < 1:
            for p in self.data['paths']:
                p['points'] = [mul(q, scale) for q in p['points']]
                p['width'] *= scale
            for p in self.data['nodes']+self.data['tips']:
                p['pos'] = mul(p['pos'], scale); p['radius'] *= scale
            for r in self.data['rings']:
                r['center'] = mul(r['center'], scale); r['radius'] *= scale; r['width'] *= scale
            self.data['anchor_points'] = {k:mul(p, scale) for k,p in self.data['anchor_points'].items()}
        return self.data


def coral(subtype, variant, seed):
    d = Design('Coral', CORAL_NAMES[subtype], variant, seed)
    groups = 0

    def lobe(root, end, bend=35, reach=72, dense=False):
        nonlocal groups
        g = groups; groups += 1
        vx, vy = end[0]-root[0], end[1]-root[1]
        length = math.hypot(vx, vy); n = [-vy/length, vx/length]
        c1 = add(add(root, [vx*.35, vy*.35]), mul(n, bend))
        c2 = add(add(root, [vx*.72, vy*.72]), mul(n, -bend*.6))
        p = d.stem(root, c1, c2, end, 17.5+(variant % 3), g)
        fine = (not dense or variant % 2 == 0) and not (subtype == 8 and variant in (2,4,7))
        d.forks(p, g, 8.9, reach, both=dense, fine=fine)
        return p

    if subtype == 0:
        root = [0, 0]
        for angle in (-135, -45, 45, 135):
            lobe(root, polar(347+9*(variant % 3), angle), 33, 79, variant % 3 == 1)
        d.node(root, 45)
        for r, col in ((393, 1), (424, 0), (445, 2)):
            d.ring([0, 0], r, 1.5+col*.35, color=col)
    elif subtype == 1:
        roots = [[-177, 119], [177, 119]]
        bridge = d.curve(roots[0], [-70, 191], [70, 191], roots[1], 13, 1, 0)
        for j, root in enumerate(roots):
            count=d.count(3,[2,3,4,2,4,3,2,4,3])
            angles=[-145+i*110/(count-1) for i in range(count)]
            for angle in angles:
                lobe(root, add(root, polar(237, angle)), 24*(-1 if j else 1), 53)
            d.node(root, 32, 'hub', j)
            d.ring([root[0], -20], 193, 2.0, segments=2, gap=30, color=j)
    elif subtype == 2:
        root = [0, 295]
        ends=([-305, -175], [-180, -323], [0, -389], [185, -325], [308, -170])
        for end in resample(ends,d.count(5,[3,4,5,6,7,4,3,6,5])):
            lobe(root, end, 31, 62)
        d.node(root, 43)
        d.ring([0, -26], 408, 3, gap=89, start=137, color=2)
    elif subtype == 3:
        root = [-350, 130]
        trunk = d.stem(root, [-155, 48], [126, 177], [354, 72], 23, 0)
        groups = 1
        count=d.count(5,[3,4,5,6,7,4,3,6,5])
        indices=[round(4+i*16/(count-1)) for i in range(count)]
        for k, ix in enumerate(indices):
            q = trunk[ix]
            lobe(q, [q[0]+(34 if k % 2 else -27), -240-45*(k % 3)], 34, 51)
        d.node(root, 31); d.node(trunk[-1], 20, 'junction', 1)
        d.ring([0, 16], 425, 2.8, segments=2, gap=46, start=21, color=1)
    elif subtype == 4:
        root = [0, 16]
        a = lobe(root, [-305, -120], -175, 64)
        b = lobe(root, [303, 133], -175, 64)
        count=d.count(1,[0,1,2,1,2,0,1,2,1])
        for j in range(count):
            at=15 if count==1 else (10,18)[j]
            lobe(a[at], [-122+72*j, -328+39*j], 49, 57)
            lobe(b[at], [120-72*j, 328-39*j], 49, 57)
        d.node(root, 39)
        d.ring([0, 0], 418, 3.2, segments=3, gap=31, start=17, color=0)
        if variant % 2: d.ring([0, 0], 371, 1.2, segments=2, gap=61, color=2)
    elif subtype == 5:
        root = [0, 245]
        left = lobe(root, [-277, -205], -150, 76, False)
        right = lobe(root, [277, -205], 150, 76, False)
        count=d.count(2,[0,1,2,3,2,1,0,3,2])
        for p, sign in ((left, -1), (right, 1)):
            for ix in ((9,16) if variant==9 else (6,12,18)[:count]):
                q = p[ix]
                lobe(q, [q[0]-sign*45, q[1]-163], sign*33, 42)
        d.node(root, 42)
        d.ring([0, 5], 421, 2, gap=100, start=140, color=2)
    elif subtype == 6:
        root = [0, -272]
        ends=([-302, 200], [-149, 363], [142, 370], [307, 193])
        for k, end in enumerate(resample(ends,d.count(4,[2,3,4,5,6,3,2,5,4]))):
            lobe(root, end, (k-1.5)*27, 77)
        d.node(root, 44)
        d.ring([0, 22], 420, 2.4, segments=2, gap=55, start=34, color=1)
        d.ring([0, 73], 327, 1.5, gap=109, start=211, color=2)
    elif subtype == 7:
        root = [-185, 224]
        a = lobe(root, [113, -333], -158, 77)
        lobe(a[13], [341, -30], -46, 71)
        lobe(root, [309, 228], 83, 69)
        if variant < 9 and variant in (1,2,4,5,7,8):
            lobe(a[18], [268,-228], 35, 57)
        if variant < 9 and variant in (2,5,8):
            lobe(a[8], [-292,-170], -46, 54)
        d.node(root, 40)
        d.ring([26, -3], 411, 3.6, gap=121, start=120, color=0)
    elif subtype == 8:
        roots = [[-202, 150], [191, 151], [0, -178]]
        d.curve(roots[0], [-120, 239], [109, 242], roots[1], 11, 1)
        d.curve(roots[0], [-101, 81], [-98, -131], roots[2], 11, 1)
        groups = 1
        for j, root in enumerate(roots):
            angles = ((125, 205), (-25, 55), (-120, -60))[j]
            count=d.count(2,[1,2,3,2,3,1,2,3,2])
            angles=[(angles[0]+angles[-1])/2] if count==1 else [angles[0]+k*(angles[-1]-angles[0])/(count-1) for k in range(count)]
            for angle in angles: lobe(root, add(root, polar(192, angle)), 29, 43)
            d.node(root, 30, 'hub', j)
        d.ring([0, 0], 435, 2.0, segments=3, gap=47, color=2)
    else:
        root = [-260, 175]
        ends=([-247, -191], [-136, -330], [65, -347], [255, -229], [342, -26])
        for end in resample(ends,d.count(5,[3,4,5,6,7,4,3,6,5])):
            lobe(root, end, 24, 67)
        d.node(root, 42)
        d.ring([3, -12], 420, 2.7, gap=103, start=90, color=1)
        for q in ((-320, 95), (-311, 16)):
            p = d.curve(root, [-294, 148], [-310, 108], q, 6, 2, 0, tip=True)
    return d.finish(f"{d.data['subtype_name']}: rounded violet and turquoise colonies with connected curling forks.", groups)


def roots(subtype, variant, seed):
    d = Design('Roots', ROOTS_NAMES[subtype], variant, seed)
    groups = 0

    def root(root, c1, c2, end, width=22, reach=89, many=False):
        nonlocal groups
        g = groups; groups += 1
        p = d.stem(root, c1, c2, end, width, g)
        d.forks(p, g, 9.2, reach, both=many, fine=True)
        return p

    if subtype == 0:
        c = [0, 132]
        tree = root(c, [-95, -7], [103, -210], [30, -356], 24, 119)
        ends=([-299, 308], [-133, 394], [137, 395], [307, 290])
        for k, e in enumerate(resample(ends,d.count(4,[2,3,4,5,6,3,2,5,4]))):
            root(c, [e[0]*.28, 215], [e[0]*.78, 277], e, 16, 50)
        d.node(c, 36); d.ring([0, 0], 436, 2.3, gap=43, start=73, color=1)
    elif subtype == 1:
        c = [0, 0]
        count=d.count(6,[4,5,6,7,8,5,4,7,6])
        angles=(-110,-47,13,76,140,199) if variant==9 else [-110+k*360/count for k in range(count)]
        for k, angle in enumerate(angles):
            end = polar(358+11*(variant % 3), angle)
            n = polar(51 if k % 2 else -51, angle+90)
            root(c, add(mul(end, .28), n), add(mul(end, .72), mul(n, -1)), end, 21, 73)
        d.node(c, 43); d.ring([18, -8], 421, 2.0, segments=2, gap=27, color=1)
    elif subtype == 2:
        c = [0, -274]
        ends=([-310, 198], [-181, 346], [-10, 401], [165, 354], [313, 202])
        for k, e in enumerate(resample(ends,d.count(5,[3,4,5,6,7,4,3,6,5]))):
            root(c, [(k-2)*31, -111], [e[0]*.8, 147], e, 24-abs(k-2)*2, 73)
        d.node(c, 43); d.ring([0, 35], 410, 2.5, gap=102, start=221, color=2)
    elif subtype == 3:
        cs = [[-144, 220], [151, 220]]
        d.curve(cs[0], [-78, 309], [88, 310], cs[1], 14, 1)
        for j, c in enumerate(cs):
            sign = -1 if j == 0 else 1
            t = root(c, [c[0]+sign*91, 66], [c[0]-sign*56, -174], [sign*167, -342], 24, 98)
            root(c, [c[0]+sign*60, 274], [c[0]+sign*105, 301], [sign*338, 289], 15, 42)
            d.node(c, 34)
        d.ring([0, -5], 435, 2.1, segments=2, gap=42, start=12, color=1)
    elif subtype == 4:
        c = [-340, 133]
        bridge = d.stem(c, [-122, -138], [163, -121], [347, 117], 24, 0)
        groups = 1
        count=d.count(5,[3,4,5,6,7,4,3,6,5])
        for k, ix in enumerate([round(4+i*16/(count-1)) for i in range(count)]):
            q = bridge[ix]; e = [q[0]+(27 if k % 2 else -21), 285+48*(k % 3)]
            root(q, [q[0]-25, q[1]+82], [e[0]+36, e[1]-87], e, 14, 57)
        d.node(c, 31); d.node(bridge[-1], 28, 'junction', 1)
        d.ring([0, -14], 415, 2.8, segments=2, gap=72, start=36, color=2)
    elif subtype == 5:
        c = [0, 301]
        for sign in (-1, 1):
            p=root(c, [sign*80, 132], [sign*320, -132], [sign*195, -369], 24, 110, variant % 3 == 1)
            if variant in (1,2,4,5,7,8):
                q=p[12];root(q, [q[0]+sign*40,q[1]-51],[sign*310,-240],[sign*331,-321],16,48)
        d.node(c, 43); d.ring([0, -7], 429, 2.8, gap=83, start=134, color=1)
    elif subtype == 6:
        c = [-251, 159]
        ends=([-162, -316], [62, -369], [288, -232], [367, -22], [303, 230])
        for k, e in enumerate(resample(ends,d.count(5,[3,4,5,6,7,4,3,6,5]))):
            root(c, [-179, 80-k*11], [e[0]-64, e[1]+62], e, 22-k*.7, 79)
        d.node(c, 42); d.ring([3, -17], 421, 2.2, gap=121, start=91, color=2)
    elif subtype == 7:
        c = [0, 0]
        for k, e in enumerate(([-157, -363], [153, -364], [-194, 350], [197, 351])):
            sign = -1 if e[0] < 0 else 1
            root(c, [sign*88, e[1]*.22], [-sign*8, e[1]*.74], e, 23, 97)
        if variant in (1,4,7):
            for sign in (-1,1):root(c,[sign*108,-19],[sign*228,39],[sign*358,28],16,61)
        d.node(c, 41)
        d.ring([0, -137], 265, 1.8, segments=2, gap=42, color=1)
        d.ring([0, 140], 262, 2.2, segments=2, gap=55, start=21, color=2)
    elif subtype == 8:
        c = [-208, 236]
        arc = root(c, [-395, -18], [-171, -351], [187, -288], 24, 106)
        root(arc[16], [-25, -92], [173, -10], [344, 105], 18, 86)
        root(c, [-83, 282], [121, 368], [325, 261], 18, 67)
        d.node(c, 41); d.ring([4, 0], 425, 3.4, gap=128, start=108, color=1)
    else:
        c = [0, -31]
        root(c, [-67, -127], [25, -258], [0, -375], 23, 126, variant % 2 == 0)
        ends=([-344, 227], [-178, 357], [0, 397], [175, 359], [343, 229])
        for k, e in enumerate(resample(ends,d.count(5,[3,4,5,6,7,4,3,6,5]))):
            root(c, [e[0]*.17, 81], [e[0]*.84, 209], e, 20, 58)
        d.node(c, 40); d.ring([0, 3], 434, 1.7, color=1)
        if variant in (2, 5, 8): d.ring([0, 3], 394, 1.2, segments=3, gap=40, color=2)
    return d.finish(f"{d.data['subtype_name']}: emerald woody roots, teal tendrils, and restrained golden terminal lights.", groups)


def bonsai(subtype, variant, seed):
    d = Design('Bonsai', BONSAI_NAMES[subtype], variant, seed)
    groups = 0

    def trunk(c, c1, c2, e, width=24, breadth=117, levels=(9, 15, 20)):
        nonlocal groups
        g = groups; groups += 1
        p = d.stem(c, c1, c2, e, width, g)
        d.canopy(p, g, breadth, levels)
        return p

    def base_roots(c, width=8, length=80, group=0):
        for sign in (-1, 1):
            e = [c[0]+sign*length, c[1]+26]
            d.curve(c, [c[0]+sign*22, c[1]+5], [e[0]-sign*15, e[1]-9], e,
                    width, 0, group, .52, True, 3)

    if subtype == 0:
        c = [0, 279]
        trunk(c, [-171, 85], [169, -135], [17, -343], breadth=154,
              levels=(8, 13, 18, 22) if variant % 3 == 0 else (9, 15, 20))
        base_roots(c, length=110); d.node(c, 35)
        d.ring([0, -12], 427, 2.4, color=1)
    elif subtype == 1:
        c = [0, 264]
        trunk(c, [-124, 135], [-62, -176], [-174, -305], breadth=105)
        trunk(c, [162, 84], [41, -130], [172, -349], width=21, breadth=111,
              levels=(10, 17, 21))
        base_roots(c, length=116); d.node(c, 34)
        d.ring([0, -13], 430, 2.3, segments=2, gap=24, color=2)
    elif subtype == 2:
        c = [-240, 230]
        trunk(c, [-182, 1], [113, -270], [341, -257], breadth=131,
              levels=(8, 13, 18, 22))
        base_roots(c, length=70); d.node(c, 32)
        d.ring([3, -15], 427, 2.8, gap=108, start=60, color=1)
    elif subtype == 3:
        c = [-151, -95]
        p = trunk(c, [12, -342], [261, -127], [253, 342], breadth=105,
                  levels=(7, 12, 17, 21))
        # The smaller reverse canopy counterbalances the long falling trunk.
        trunk(c, [-229, -152], [-299, -208], [-341, -151], width=16, breadth=47,
              levels=(11, 18))
        d.node(c, 33); d.ring([2, -6], 429, 2.5, segments=2, gap=62, start=15, color=2)
    elif subtype == 4:
        c = [0, 287]
        p = d.stem(c, [-32, 132], [39, -52], [0, -221], 24, 0); groups = 1
        for k, end in enumerate(([-347, -151], [-257, -278], [-119, -359],
                                 [116, -357], [259, -281], [346, -153])):
            root = p[17+(k % 3)]
            b = d.curve(root, [end[0]*.39, root[1]-36], [end[0]*.83, end[1]-20],
                        end, 11, 0, k+1, .51)
            d.forks(b, k+1, 4.8, 37, levels=(13, 19), both=variant % 2 == 0, fine=False, color=1)
            if k % 2 == variant % 2: d.node(b[-1], 10, 'orb', 2)
        groups = 7; base_roots(c, length=115); d.node(c, 33)
        d.ring([0, -13], 431, 2.1, gap=47, start=66, color=1)
    elif subtype == 5:
        c = [0, 304]
        p = d.stem(c, [-24, 95], [24, -139], [0, -366], 24, 0); groups = 1
        tier_indices = (7, 12, 17, 21) if variant % 3 != 2 else (8, 15, 21)
        d.canopy(p, 0, 208, tier_indices)
        base_roots(c, length=105); d.node(c, 33)
        d.ring([0, -1], 431, 2.3, segments=3, gap=24, color=2)
    elif subtype == 6:
        cs = [[-260, 234], [260, 234]]
        peak = [0, -314]
        for sign, c in zip((-1, 1), cs):
            trunk(c, [sign*303, -17], [sign*162, -320], peak, breadth=89,
                  levels=(10, 16, 21))
            base_roots(c, length=58); d.node(c, 29)
        d.node(peak, 17, 'junction', 1)
        d.ring([0, -11], 432, 2.4, segments=2, gap=31, color=1)
    elif subtype == 7:
        cs = [[-223, 242], [0, 282], [220, 239]]
        d.curve(cs[0], [-150, 301], [-49, 291], cs[1], 8.5, 0)
        d.curve(cs[1], [70, 315], [155, 292], cs[2], 8.5, 0)
        for j, c in enumerate(cs):
            top = [[-242, -217], [18, -374], [232, -251]][j]
            trunk(c, [c[0]-38, 62], [top[0]+39, top[1]+125], top,
                  width=22 if j == 1 else 18, breadth=77 if j != 1 else 99,
                  levels=(10, 17, 21) if variant % 2 else (11, 19))
            d.node(c, 27 if j == 1 else 23)
        d.ring([0, -2], 438, 1.9, color=1)
    elif subtype == 8:
        c = [-177, 284]
        trunk(c, [-109, 65], [157, -109], [276, -332], breadth=145,
              levels=(7, 13, 18, 22))
        base_roots(c, length=99); d.node(c, 34)
        d.ring([0, -5], 430, 2.8, gap=80, start=84, color=2)
    else:
        c = [-316, 219]
        p = d.stem(c, [-180, -140], [152, -131], [322, 210], 24, 0); groups = 1
        d.canopy(p, 0, 104, (5, 10, 15, 20))
        # Hanging live roots descend from exact support samples.
        for k, ix in enumerate((7, 12, 17)):
            q = p[ix]; e = [q[0]+(-17 if k % 2 else 19), 275+30*(k % 2)]
            r = d.curve(q, [q[0]+23, q[1]+74], [e[0]-25, e[1]-87], e,
                        9.5, 0, 0, .48, True, 3.3)
            if variant % 2: d.forks(r, 0, 3.8, 28, levels=(15,), fine=False, color=1)
        d.node(c, 29); d.node(p[-1], 25, 'junction', 0)
        d.ring([0, 0], 429, 2.4, segments=2, gap=65, color=1)
    return d.finish(f"{d.data['subtype_name']}: sculptural copper wood, jade branchlets, and attached golden fruit.", groups)


def build(family, subtype, variant, seed):
    if not 0 <= subtype <= 9 or not 0 <= variant <= 9:
        raise ValueError('subtype and variant must lie in 0..9')
    functions = {'Coral': coral, 'Roots': roots, 'Bonsai': bonsai}
    if family not in functions:
        raise ValueError(f'Unsupported organic family: {family}')
    return functions[family](int(subtype), int(variant), int(seed))


def selftest():
    hashes = set(); summary = {}
    for family in ('Coral', 'Roots', 'Bonsai'):
        counts = []; maxextent = 0
        for subtype in range(10):
            for variant in range(10):
                g = build(family, subtype, variant, 451000+subtype*101+variant*11)
                anchors = {tuple(n['pos']) for n in g['nodes'] if n['style'] in ('hub', 'junction')}
                # All supports either start at a visible base/core or at an exact
                # point of a support already added to this geometry.
                for p in g['paths']:
                    assert tuple(p['points'][0]) in anchors, (family, subtype, variant, 'unattached root')
                    assert 1.5 <= p['width'] <= 24
                    assert .45 <= p['taper'] <= .85
                    for a, b in zip(p['points'], p['points'][1:]):
                        assert all(math.isfinite(x) for x in a+b)
                        assert math.dist(a, b) > 1e-6
                    anchors.update(tuple(q) for q in p['points'])
                    for q in p['points']: maxextent = max(maxextent, math.hypot(*q)+p['width']*.65+8)
                for n in g['nodes']+g['tips']:
                    assert tuple(n['pos']) in anchors, (family, subtype, variant, 'floating node')
                    maxextent = max(maxextent, math.hypot(*n['pos'])+n['radius']+8)
                for r in g['rings']:
                    maxextent = max(maxextent, math.hypot(*r['center'])+r['radius']+r['width']+8)
                assert len(g['paths']) <= 65, (family, subtype, variant, len(g['paths']))
                counts.append(len(g['paths']))
                geometry = {k:g[k] for k in ('paths', 'tips', 'rings', 'nodes')}
                h = hashlib.sha256(json.dumps(geometry, sort_keys=True).encode()).hexdigest()
                assert h not in hashes, (family, subtype, variant, 'duplicate geometry')
                hashes.add(h)
        assert maxextent <= 452.000001, (family, maxextent)
        summary[family] = dict(items=100, min_paths=min(counts), max_paths=max(counts),
                               max_extent=round(maxextent, 3))
    return summary


if __name__ == '__main__':
    print(json.dumps(selftest(), indent=2))
