from pathlib import Path
import json,hashlib,collections,math
from PIL import Image
from build_collection import fingerprint
ROOT=Path(__file__).resolve().parents[1]
PIPELINE=hashlib.sha256((Path(__file__).parent/'render_art.py').read_bytes()+(Path(__file__).parent/'style.py').read_bytes()).hexdigest()
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def main():
 c=json.loads((ROOT/'Collection.json').read_text());items=c['items'];assert len(items)==1100 and [i['id'] for i in items]==list(range(1,1101))
 assert collections.Counter(i['tier'] for i in items)=={'Preview':990,'Volumetric':110}
 assert len({i['geometry_sha256'] for i in items})==1100
 families=collections.defaultdict(list)
 for i in items:families[i['family']].append(i)
 assert len(families)==11
 files=[];geometry_checks=[]
 for item in items:
  g=json.loads((ROOT/item['geometry_file']).read_text());assert fingerprint(g)==item['geometry_sha256']
  # Every graph component must reach a core; families without core hubs use a joined network.
  adjacency=collections.defaultdict(set)
  for rec in g['paths']:
   pts=[tuple(round(x,5) for x in p) for p in rec['points']]
   for a,b in zip(pts,pts[1:]):
    assert math.dist(a,b)>1e-7
    adjacency[a].add(b);adjacency[b].add(a)
  hubs=[n for n in g['nodes'] if n['style']=='hub'];remaining=set(adjacency);components=0
  while remaining:
   start=next(iter(remaining));seen={start};queue=[start]
   while queue:
    for q in adjacency[queue.pop()]:
     if q not in seen:seen.add(q);queue.append(q)
   remaining-=seen;components+=1
   if hubs:assert any(math.dist(v,h['pos'])<=h['radius']+1.5 for v in seen for h in hubs),(item['id'],'unanchored rail graph')
  if not hubs:assert components==1,(item['id'],'disconnected coreless network')
  geometry_checks.append({'id':item['id'],'connected_components':components,'paths':len(g['paths']),'fixed_cores':len(hubs)})
  for kind in ['png','gif']:
   if kind not in item:continue
   path=ROOT/'artwork'/item[kind];rep=json.loads((ROOT/'internal/reports'/f"{item['id']:04d}_{kind}.json").read_text())
   assert rep['geometry_sha256']==item['geometry_sha256'] and rep['pipeline_sha256']==PIPELINE and path.stat().st_size==rep['bytes'] and sha(path)==rep['sha256']
   if kind=='png':
    with Image.open(path) as im:im.load();assert im.size==(2048,2048) and im.mode=='RGB'
   else:assert rep['duration_ms']==12000 and rep['source_frames']==240 and rep['fps']==20 and rep['loop']==0 and rep['bytes']<50_000_000 and rep['native_loop_endpoints_identical'] and rep['fixed_hub_interiors_stable']
   files.append({**rep,'artifact':item[kind],'tier':item['tier'],'family':item['family'],'subtype_index':item['subtype_index'],'subtype_name':item['subtype_name'],'format':kind})
 for family,group in families.items():
  assert len(group)==100 and collections.Counter(i['tier'] for i in group)=={'Preview':90,'Volumetric':10}
  for sub in range(10):assert collections.Counter(i['tier'] for i in group if i['subtype_index']==sub)=={'Preview':9,'Volumetric':1}
 expected={f['artifact'] for f in files};actual={str(p.relative_to(ROOT/'artwork')) for p in (ROOT/'artwork').rglob('*') if p.is_file()}
 assert expected==actual and len(files)==1210 and len({f['sha256'] for f in files})==1210
 report={'complete':True,'artwork_count':1100,'media_count':1210,'png_count':1100,'gif_count':110,'tier_counts':{'Preview':990,'Volumetric':110},'all_geometry_hashes_unique':True,'all_media_hashes_unique':True,'all_rail_components_anchored':True,'all_gifs_fully_decoded':True,'all_gifs_below_50_MB':True,'total_bytes':sum(f['bytes'] for f in files),'files':files,'geometry_checks':geometry_checks}
 (ROOT/'Validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['files','geometry_checks']},indent=2))
if __name__=='__main__':main()
