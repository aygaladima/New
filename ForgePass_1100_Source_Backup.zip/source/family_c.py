"""Frost, Crown and Cascade: thirty architectural templates for Forge Pass.

Every child branch starts at an existing parent vertex.  Variants alter topology,
proportion and node/ring arrangements, rather than rotating the same structure.
The module uses the standard library and returns renderer-neutral JSON geometry.
"""
from __future__ import annotations

import hashlib
import json
import math
import random

FAMILIES = ("Frost", "Crown", "Cascade")
SUBTYPES = {
    "Frost": ("Stellar Snowflake", "Fourfold Crystal", "Ice Pinnacle",
              "Frozen Diadem", "Shard Fan", "Twin Crystals", "Diagonal Comb",
              "Prism Bridge", "Hanging Icicles", "Crystal Cluster"),
    "Crown": ("Regal Fan", "Double Fan", "Triple Crown", "Arch Diadem",
              "Sovereign Spire", "Layered Crown", "Asymmetric Crest",
              "Split Wings", "Sweeping Crest", "Twin Tiara"),
    "Cascade": ("Silver Curtain", "Twin Falls", "Side Waterfall", "Terrace Falls",
                "Stepped Canopies", "Ribbon Arch", "Converging Falls",
                "Diagonal Stream", "Drooping Fountain", "Weeping Column"),
}


def _p(r, degrees):
    t = math.radians(degrees)
    return [r * math.cos(t), r * math.sin(t)]


def _add(a, b):
    return [a[0] + b[0], a[1] + b[1]]


def _lerp(a, b, t):
    return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]


def _bez(a, b, c, d, n=25):
    pts = []
    for i in range(n):
        t = i / (n - 1)
        u = 1 - t
        pts.append([u**3*a[k] + 3*u*u*t*b[k] + 3*u*t*t*c[k] + t**3*d[k]
                    for k in range(2)])
    pts[0], pts[-1] = list(a), list(d)
    return pts


class _D:
    def __init__(self, family, subtype, description):
        self.s = dict(name=family, subtype_name=SUBTYPES[family][subtype],
                      description=description, layout="", main_assemblies=0,
                      paths=[], tips=[], nodes=[], rings=[], facets=[])

    def path(self, pts, w=10, color=0, group=0, taper=.55, tip=False, radius=3.3):
        out = [[float(x), float(y)] for x, y in pts]
        # Duplicated consecutive vertices do not belong in a tapered rail.
        out = [p for i, p in enumerate(out)
               if not i or math.dist(p, out[i-1]) > 1e-7]
        if len(out) < 2:
            raise ValueError("Degenerate branch")
        self.s["paths"].append(dict(points=out, width=float(w), color=int(color),
                                    group=int(group), taper=float(taper)))
        if tip:
            self.tip(out[-1], radius, color if color == 2 else 2)
        return out

    def curve(self, a, b, c, e, w=10, color=0, group=0, taper=.55,
              tip=False, radius=3.3):
        return self.path(_bez(a, b, c, e), w, color, group, taper, tip, radius)

    def tip(self, p, r=3.2, color=2):
        self.s["tips"].append(dict(pos=list(p), radius=float(r), color=int(color)))

    def node(self, p, r=40, style="hub", color=0):
        self.s["nodes"].append(dict(pos=list(p), radius=float(r), style=style, color=int(color)))

    def ring(self, c, r, w=2, segments=1, gap=0, start=0, color=1):
        self.s["rings"].append(dict(center=list(c), radius=float(r), width=float(w),
                                    segments=int(segments), gap=float(gap),
                                    start=float(start), color=int(color)))

    def shard(self, tip, direction, size=13, color=2):
        axis = _p(1, direction)
        normal = [-axis[1], axis[0]]
        base = _add(tip, [-axis[0]*size, -axis[1]*size])
        pts = [tip, _add(base, [normal[0]*size*.30, normal[1]*size*.30]),
               _add(tip, [-axis[0]*size*1.85, -axis[1]*size*1.85]),
               _add(base, [-normal[0]*size*.30, -normal[1]*size*.30])]
        self.s["facets"].append(dict(points=pts, color=color))

    def finish(self, layout, assemblies):
        self.s["layout"], self.s["main_assemblies"] = layout, int(assemblies)
        # Fit the whole construction, including detached halos and large cores.
        extent = 0.0
        for rec in self.s["paths"]:
            extent = max(extent, max(max(abs(x), abs(y)) for x, y in rec["points"]) + rec["width"]/2 + 8)
        for rec in self.s["tips"] + self.s["nodes"]:
            extent = max(extent, max(map(abs, rec["pos"])) + rec["radius"] + 8)
        for rec in self.s["rings"]:
            extent = max(extent, max(map(abs, rec["center"])) + rec["radius"] + rec["width"] + 7)
        for rec in self.s["facets"]:
            extent = max(extent, max(max(map(abs, p)) for p in rec["points"]) + 4)
        factor = min(1., 451. / max(1., extent))
        if factor < 1:
            def scaled(p): return [p[0]*factor, p[1]*factor]
            for rec in self.s["paths"] + self.s["facets"]:
                rec["points"] = [scaled(p) for p in rec["points"]]
            for rec in self.s["tips"] + self.s["nodes"]:
                rec["pos"] = scaled(rec["pos"])
                rec["radius"] *= factor
            for rec in self.s["rings"]:
                rec["center"] = scaled(rec["center"])
                rec["radius"] *= factor
        return self.s


def _ice_spear(d, root, end, group, v, width=11, pairs=2, span=55,
               color=0, comb=False):
    """A straight crystalline spine, exact attached needle forks and a facet."""
    dx, dy = end[0]-root[0], end[1]-root[1]
    length = math.hypot(dx, dy)
    ax = [dx/length, dy/length]
    normal = [-ax[1], ax[0]]
    fractions = ([.36, .64] if pairs == 2 else [.29, .49, .70])
    if pairs == 1:
        fractions = [.53]
    spine = [list(root)] + [_lerp(root, end, t) for t in fractions] + [list(end)]
    d.path(spine, width, color, group, .45, True, 2.8)
    for j, origin in enumerate(spine[1:-1]):
        for hand in ((1,) if comb else (-1, 1)):
            reach = min(length*(.26-j*.025), 100-j*9)
            spread = span*(1-j*.19)*(1 + .06*((v+group)%3-1))
            knee = _add(origin, [ax[0]*reach*.55 + normal[0]*hand*spread*.72,
                                 ax[1]*reach*.55 + normal[1]*hand*spread*.72])
            tip = _add(origin, [ax[0]*reach + normal[0]*hand*spread,
                                ax[1]*reach + normal[1]*hand*spread])
            needle = d.path([origin, knee, tip], max(2.4, width*.49-j*.45),
                            (j+v)%2, group, .45, True, 2.4)
            if (v + j + group) % 4 == 1:
                q = needle[1]
                e = _add(q, [ax[0]*27-normal[0]*hand*15,
                             ax[1]*27-normal[1]*hand*15])
                d.path([q, e], 2.3, 2, group, .45, True, 2.0)
    d.shard(end, math.degrees(math.atan2(dy, dx)), 13+v%3*2, 2)
    return spine


def _frost(st, v, rng):
    d = _D("Frost", st, "Crystalline needle forks, faceted spear tips and silver-blue layered geometry.")
    phase = v % 3
    if st == 0:
        count = (6, 8, 10)[phase]
        for i in range(count):
            angle = -90 + i*360/count
            reach = (407, 379)[i%2] + (v//3)*5
            _ice_spear(d, [0, 0], _p(reach, angle), i, v, 10.5,
                       2 if count < 10 else 1, 39 if count >= 8 else 63)
        d.node([0, 0], 43, color=1)
        d.ring([0, 0], 442, 1.5, segments=1 if v%2 == 0 else 6,
               gap=0 if v%2 == 0 else 19, color=1)
        return d.finish("radial crystalline snowflake", count)
    if st == 1:
        for i, angle in enumerate((-90, 0, 90, 180)):
            _ice_spear(d, [0, 0], _p(407 if i%2 == 0 else 352+phase*17, angle),
                       i, v, 16, 1+phase, 102-phase*8)
            if v >= 3:
                d.node(_p(180+phase*15, angle), 10+v%2*3, "junction", 1)
        d.node([0, 0], 48, color=1)
        if v%2:
            d.ring([0, 0], 287, 2.1, 4, 28, -31, 2)
        d.ring([0, 0], 443, 2, 4, 34, -57, 1)
        return d.finish("fourfold crystal cross with broad needle tiers", 4)
    if st == 2:
        core = [0, 305]
        levels = 2+phase
        joints = [[0, 166-i*336/(levels-1)] for i in range(levels)]
        trunk = d.path([core]+joints+[[0, -410]], 22, 0, 0, .46, True)
        for j, q in enumerate(trunk[1:-1]):
            for side in (-1, 1):
                e = [side*(220-j*45+phase*12), q[1]-137-(v//3)*9]
                _ice_spear(d, q, e, 1+j*2+(side == 1), v, 10-j, 1+int(j == 0 and v%2 == 0), 30)
        d.node(core, 45, color=1)
        d.ring([0, 0], 431, 1.7, 2 if phase else 1, 41 if phase else 0, 18, 1)
        return d.finish("vertical ice pinnacle with tiered paired shards", 1+levels*2)
    if st == 3:
        core = [0, 270]
        count = (5, 7, 9)[phase]
        for i in range(count):
            x = -330 + 660*i/(count-1)
            e = [x, -390+abs(x)*.40+(v//3)*9]
            q = [x*.22, 120-abs(x)*.13]
            d.path([core, q], 14, 0, i, .75)
            _ice_spear(d, q, e, i, v, 10, 1 if count >= 9 else 2, 28)
        d.node(core, 46, color=1)
        d.ring([0, -10], 423, 2, 1, 102, 146, 1)
        return d.finish("upright crown of narrow ice blades", count)
    if st == 4:
        core = [-217, 230]
        count = (5, 6, 7)[phase]
        for i in range(count):
            t = i/(count-1)
            end = [-276+640*t, -370+245*t*t + (v//3)*11]
            _ice_spear(d, core, end, i, v, 14-i*.75, 2, 34)
        d.node(core, 46, color=1)
        d.ring([36, -7], 385, 2, 3, 37, -103, 2)
        if v%2:
            d.node([0, 0], 10, "orb", 2)
            d.path([core, [0, 0]], 3.1, 1, 0, .6)
        return d.finish("asymmetric angled fan of long crystalline shards", count)
    if st == 5:
        cores = [[-195, 0], [195, 0]]
        d.path(cores, 11, 1, 0, .8)
        count = (4, 5, 6)[phase]
        for side, core in enumerate(cores):
            for i in range(count):
                angle = -90 + i*360/count
                reach = 186+(v//3)*8 if i%2 else 222
                _ice_spear(d, core, _add(core, _p(reach, angle)), side*count+i,
                           v, 9.5, 1, 30)
            d.node(core, 37, color=1)
            d.ring(core, 232, 1.4, 2 if v%2 else 1, 24 if v%2 else 0, 0, side)
        return d.finish("two connected independent crystal rosettes", count*2)
    if st == 6:
        root, end = [-288, 310], [287, -328]
        count = (5, 6, 7)[phase]
        joints = [_lerp(root, end, (i+1)/(count+1)) for i in range(count)]
        d.path([root]+joints+[end], 19, 0, 0, .5, True)
        d.node(root, 39, color=1)
        for i, q in enumerate(joints):
            # All long teeth share a direction, giving a genuine comb silhouette.
            e = [q[0]+105+(i%2)*19, q[1]+91+(v//3)*8]
            _ice_spear(d, q, e, i+1, v, 8, 1, 24)
            if v%2 == 0 and i%2 == 0:
                _ice_spear(d, q, [q[0]-64, q[1]-53], i+1, v, 4.8, 1, 15)
        d.ring([0, 0], 436, 1.6, 4, 46, 0, 1)
        return d.finish("diagonal crystal comb with one-sided needles", count+1)
    if st == 7:
        left, right = [-332, 0], [332, 0]
        count = (3, 4, 5)[phase]
        joints = [[-252+504*i/(count-1), 0] for i in range(count)]
        d.path([left]+joints+[right], 18, 0, 0, .78)
        for i, q in enumerate(joints):
            height = 245-(abs(q[0])*.34)+(v//3)*12
            for side in (-1, 1):
                end = [q[0]+(-1 if i%2 else 1)*30, side*height]
                _ice_spear(d, q, end, i+1, v, 9, 2, 35)
        d.node(left, 42, color=1)
        d.node(right, 42, color=1)
        for q in joints[1:-1]:
            d.node(q, 8, "junction", 2)
        if v%2:
            d.ring([0, 0], 361, 1.6, 2, 58, 20, 1)
        return d.finish("horizontal prism bridge with opposing crystal fins", count*2)
    if st == 8:
        core = [0, -272]
        count = (5, 7, 9)[phase]
        roots = [[-326+652*i/(count-1), -272] for i in range(count)]
        d.path(roots, 14, 1, 0, .85)
        d.node(core, 43, color=1)
        # Insert the core into the beam when even-count topology is used later.
        for i, q in enumerate(roots):
            end = [q[0]+(i%2*2-1)*(12+v//3*7),
                   220+138*(1-abs(q[0])/350)+(i%2)*20]
            _ice_spear(d, q, end, i+1, v, 12-i%2*3, 2, 24)
        d.ring([0, -61], 363, 1.7, 2, 62, 18, 1)
        return d.finish("suspended row of uneven crystalline icicles", count)
    # Three separated crystal crowns connect to one small lower root.
    core = [0, 280]
    centres = [[-221, -47], [0, -142], [223, -38]]
    count = (3, 4, 5)[phase]
    for j, c in enumerate(centres):
        d.path([core, c], 15 if j == 1 else 11, 0, j, .55)
        d.node(c, 22, "junction", 1)
        for i in range(count):
            angle = -157 + i*132/(count-1)
            _ice_spear(d, c, _add(c, _p(193+(v//3)*7, angle)), j*count+i,
                       v, 8, 1, 22)
    d.node(core, 42, color=1)
    for c in centres:
        if v%2:
            d.ring(c, 137, 1.4, 3, 28, 0, 2)
    return d.finish("three branching crystalline clusters above a common root", count*3)


def _crown_fan(d, core, ends, v, groupstart=0, width=16, forks=2):
    for i, end in enumerate(ends):
        dx, dy = end[0]-core[0], end[1]-core[1]
        # Upright stems retain the upward ceremonial fan identity.
        p = d.curve(core, [core[0]+dx*.15, core[1]+dy*.37],
                    [core[0]+dx*.85, core[1]+dy*.74], end,
                    width-(i%3)*1.1, 0 if i%3 else 1, groupstart+i, .57, True, 4.2)
        for k, index in enumerate((13, 19)[:forks]):
            q = p[index]
            hand = -1 if i < len(ends)/2 else 1
            if (i+v)%3 == 0:
                hand *= -1
            spread = 29+(v%3)*9-k*6
            e = [q[0]+hand*spread, q[1]-(80-k*15)]
            d.curve(q, [q[0]+hand*7, q[1]-33],
                    [e[0], e[1]+23], e, 5.5-k*.8, 1 if k == 0 else 2,
                    groupstart+i, .52, True, 3.1)


def _crown(st, v, rng):
    d = _D("Crown", st, "Golden upward branching fans, pale-blue secondary stems and restrained pearl accents.")
    mode, band = v%3, v//3
    if st == 0:
        core, count = [0, 279], (5, 7, 9)[mode]
        ends = []
        for i in range(count):
            x = -342+684*i/(count-1)
            ends.append([x, -396+abs(x)*.52+band*8])
        _crown_fan(d, core, ends, v, forks=2)
        d.node(core, 52)
        d.ring([0, -8], 424, 3, 1, 111, 145, 2)
        if v%2:
            d.path([[-84, 279], core, [84, 279]], 6, 1, 0, .8)
            for x in (-84, 84): d.node([x, 279], 11, "junction", 2)
        return d.finish("single wide rising crown fan", count)
    if st == 1:
        count = (3, 4, 5)[mode]
        cores = [[-162, 235], [162, 235]]
        d.path(cores, 9, 1, 0, .8)
        for side, c in enumerate(cores):
            ends = [[c[0]-181+362*i/(count-1), -325-64*(1-abs(i/(count-1)-.5)*2)+band*7]
                    for i in range(count)]
            _crown_fan(d, c, ends, v, side*count, 14, 2)
            d.node(c, 41)
            d.ring([c[0], -66], 248, 2.1, 1, 122, 151, side)
        return d.finish("two independent upward fans joined at their bases", count*2)
    if st == 2:
        count = (3, 4, 5)[mode]
        for j, c in enumerate(([-238, 190], [0, 283], [238, 190])):
            if j != 1:
                d.path([[0, 283], c], 10, 1, j, .8)
            height = 472 if j == 1 else 423
            ends = [[c[0]-116+232*i/(count-1), c[1]-height-40*(i%2)+band*9]
                    for i in range(count)]
            _crown_fan(d, c, ends, v, j*count, 13.5, 1)
            d.node(c, 39 if j != 1 else 48)
            if v%2:
                d.ring([c[0], c[1]-174], 155, 1.6, 1, 128, 154, 2)
        return d.finish("three tall crown fans on a low three-core base", count*3)
    if st == 3:
        core, count = [0, 300], (5, 7, 9)[mode]
        ends = []
        for i in range(count):
            a = -157+i*134/(count-1)
            ends.append(_add([0, 30], _p(371-band*7, a)))
        _crown_fan(d, core, ends, v, width=16.5, forks=2)
        # The arch itself connects exact endpoints, becoming a structural crown rim.
        d.path(ends, 5.2, 2, 0, .85)
        d.node(core, 49)
        d.ring([0, 26], 411, 2.2, 1, 140, 160, 1)
        return d.finish("broad curved crown rim with attached rising stems", count)
    if st == 4:
        core = [0, 325]
        levels = 2+mode
        joints = [[0, 165-i*339/(levels-1)] for i in range(levels)]
        trunk = d.path([core]+joints+[[0, -412]], 21, 0, 0, .55, True, 4.5)
        for level, q in enumerate(trunk[1:-1]):
            for side in (-1, 1):
                ends = [[side*(111+(mode)*14), q[1]-161-band*7],
                        [side*(167+mode*14), q[1]-94-band*7]]
                _crown_fan(d, q, ends[:1+(v+level)%2], v, 1+level*4+(side == 1)*2,
                           10.7-level, 1)
        d.node(core, 49)
        d.ring([0, -15], 422, 2, 2, 84, -43, 2)
        return d.finish("narrow golden sovereign spire with rising side finials", 1+levels*2)
    if st == 5:
        core = [0, 315]
        levels = (2, 4, 6)[mode] if v < 9 else (3, 4, 5)[mode]
        joints = ([[0, 219-i*450/(levels-1)] for i in range(levels)]
                  if v < 9 else [[0, 219-i*113] for i in range(levels)])
        d.path([core]+joints+[[0, -405]], 19, 0, 0, .55, True, 4.1)
        for j, q in enumerate(joints):
            span = 311-j*43+band*4
            ends = [[-span, q[1]-120], [span, q[1]-120]]
            _crown_fan(d, q, ends, v, j*2+1, 13-j*.8, 2 if levels < 5 else 1)
            if j%2 == v%2:
                d.node(q, 10, "junction", 2)
        d.node(core, 50)
        if v%2:
            d.ring([0, -12], 428, 1.8, 1, 116, 148, 1)
        return d.finish("vertically layered diadem with stepped open crown tiers", levels*2+1)
    if st == 6:
        core = [-132, 278]
        count = (5, 6, 7)[mode]
        ends = [[-300+665*i/(count-1), -233-165*math.sin(i/(count-1)*math.pi*.72)+band*8]
                for i in range(count)]
        _crown_fan(d, core, ends, v, width=17, forks=2)
        d.node(core, 51)
        d.ring([21, -27], 393, 2.8, 1, 133, 150, 2)
        if v%2:
            for x in (-220, -45):
                p = [x, 278]
                d.path([core, p], 5.5, 1, 0, .8)
                d.node(p, 10, "junction", 2)
        return d.finish("asymmetric right-sweeping crest from an offset low core", count)
    if st == 7:
        core = [0, 288]
        hubs = [[-181, 74], [181, 74]]
        count = (3, 4, 5)[mode]
        for side, q in enumerate(hubs):
            d.curve(core, [q[0]*.25, 210], [q[0], 160], q, 20, 0, side, .65)
            ends = [[q[0]-166+332*i/(count-1), -235-134*(i/(count-1) if side == 0 else 1-i/(count-1))+band*6]
                    for i in range(count)]
            _crown_fan(d, q, ends, v, side*count+2, 12.5, 2)
            d.node(q, 22, "junction", 2)
        d.node(core, 48)
        d.ring([0, -8], 422, 2.4, 2, 95, -43, 1)
        return d.finish("paired elevated crown wings above a shared lower core", count*2)
    if st == 8:
        core = [-257, 249]
        arc = d.curve(core, [-280, -180], [90, -365], [346, -123], 21, 0, 0, .53, True, 4.8)
        indices = ((7, 11, 15, 19), (6, 10, 14, 18, 22),
                   (6, 9, 12, 15, 18, 21))[mode]
        for j, ix in enumerate(indices):
            q = arc[ix]
            end = [q[0] - 11 + band*8, q[1] - (101 if j%2 == 0 else 72)]
            _crown_fan(d, q, [end], v+j, j+1, 10, 1)
            if v%2 and j%2:
                d.node(q, 9, "junction", 2)
        # Preview silhouettes have one, two or three substantial crest arches.
        # Additional arches share the actual lower core and carry their own
        # attached finials, making the change visible without inspecting tips.
        if v < 9:
            for branch in range(mode):
                inset = branch+1
                e = [346-inset*95, -123+inset*76]
                extra = d.curve(core,
                                [-280+inset*67, -180+inset*29],
                                [90-inset*5, -365+inset*104], e,
                                16-inset*2, 1 if inset == 1 else 2,
                                20+inset, .55, True, 3.7)
                for ix in (11, 18):
                    q = extra[ix]
                    end = [q[0]+12, q[1]-59]
                    _crown_fan(d, q, [end], v, 20+inset, 6.2, 0)
        d.node(core, 48)
        d.ring([0, 0], 426, 2, 1, 102, 151, 2)
        layout = ("single sweeping crest", "double nested branching crest",
                  "triple nested branching crest")[mode] if v < 9 else "one sweeping arch supporting an upright row of finials"
        return d.finish(layout, len(indices)+1+(mode if v < 9 else 0))
    root = [0, 307]
    hubs = [[-176, 20], [176, 20]]
    count = (3, 5, 7)[mode]
    for side, q in enumerate(hubs):
        d.path([root, [q[0]*.7, 151], q], 18, 0, side, .67)
        ends = [[q[0]-171+342*i/(count-1), -327-49*math.sin(i/(count-1)*math.pi)+band*8]
                for i in range(count)]
        _crown_fan(d, q, ends, v, side*count+2, 12.5, 1)
        d.node(q, 35)
        d.ring([q[0], -137], 216, 1.9, 1, 127, 152, side)
    d.node(root, 46, color=2)
    return d.finish("two high tiaras with separate cores and a shared golden base", count*2)


def _fall(d, root, end, group, v, width=13, forks=2, lean=1):
    dx, dy = end[0]-root[0], end[1]-root[1]
    bow = 35+(v%3)*14
    spine = d.curve(root, [root[0]+lean*bow, root[1]+dy*.31],
                    [end[0]-lean*bow*.43, end[1]-dy*.27], end,
                    width, 0 if group%3 else 1, group, .48, True, 3.3)
    for j, ix in enumerate((10, 17)[:forks]):
        q = spine[ix]
        side = -1 if (group+j+v)%2 else 1
        e = [q[0]+side*(39+(v%3)*10), q[1]+(90-j*15)]
        d.curve(q, [q[0]+side*35, q[1]+12], [e[0]-side*13, e[1]-31],
                e, 5.1-j*.7, 1 if j == 0 else 2, group, .48, True, 2.7)
    return spine


def _cascade(st, v, rng):
    d = _D("Cascade", st, "Silver-turquoise downward ribbons, hanging forks and offset blue halos.")
    mode, band = v%3, v//3
    if st == 0:
        core = [0, -294]
        count = (5, 7, 9)[mode]
        roots = [[-307+614*i/(count-1), -258+abs(-307+614*i/(count-1))*.17]
                 for i in range(count)]
        d.path([core]+roots[:count//2][::-1], 11, 1, 0, .65)
        d.path([core]+roots[count//2:], 11, 1, 1, .65)
        for i, q in enumerate(roots):
            end = [q[0]+(-1 if i%2 else 1)*(20+band*6), 310+54*(i%3)]
            _fall(d, q, end, i+2, v, 13-i%2*2, 2, -1 if i<count/2 else 1)
        d.node(core, 44)
        d.ring([0, -14], 427, 1.8, 1, 83, 49, 1)
        if v%2:
            d.ring([19, 43], 352, 1.4, 2, 53, 19, 2)
        return d.finish("broad suspended curtain with uneven hanging ribbons", count)
    if st == 1:
        cores = [[-195, -277], [195, -277]]
        d.path([cores[0], [0, -305], cores[1]], 10, 1, 0, .8)
        count = (3, 4, 5)[mode]
        for side, q in enumerate(cores):
            for i in range(count):
                end = [q[0]-139+278*i/(count-1), 340-85*abs(i/(count-1)-.5)*2+band*11]
                _fall(d, q, end, side*count+i, v, 14-i%2*2, 2, -1 if side == 0 else 1)
            d.node(q, 42)
            d.ring([q[0], 10], 225, 2, 1, 91, 45, side)
        return d.finish("two independent downward waterfalls linked at their sources", count*2)
    if st == 2:
        core = [-249, -310]
        main = d.curve(core, [-294, -30], [249, 34], [208, 385], 22, 0, 0, .5, True, 4.3)
        indices = ((5, 10, 15, 20), (4, 8, 12, 16, 20),
                   (4, 7, 10, 13, 16, 19))[mode]
        for i, ix in enumerate(indices):
            q = main[ix]
            side = -1 if i%2 == 0 else 1
            end = [q[0]+side*(112+mode*19), q[1]+113-band*5]
            _fall(d, q, end, i+1, v, 10.5, 2, side)
            if v%2 == 0:
                d.node(q, 8, "junction", 1)
        d.node(core, 46)
        d.ring([9, 16], 413, 2.1, 2, 73, -41, 1)
        return d.finish("asymmetric descending S-stream with side waterfalls", len(indices)+1)
    if st == 3:
        core = [0, -332]
        count = (3, 4, 5)[mode]
        joints = [[0, -212+i*(398/(count-1))] for i in range(count)]
        d.path([core]+joints, 19, 0, 0, .65)
        for i, q in enumerate(joints):
            reach = 297-i*34+band*5
            ends = [[-reach, q[1]], [reach, q[1]]]
            d.path([ends[0], q, ends[1]], 10.5-i*.6, 1, i+1, .8)
            for side, root in enumerate(ends):
                _fall(d, root, [root[0]+(-1 if side == 0 else 1)*15, q[1]+141],
                      i*2+2+side, v, 9.3, 1, -1 if side == 0 else 1)
            d.node(q, 12, "junction", 2)
        d.node(core, 45)
        if v%2:
            d.ring([0, 1], 424, 1.6, 2, 81, 10, 2)
        return d.finish("horizontal waterfall terraces on a central descending spine", count*2)
    if st == 4:
        core = [0, -335]
        count = (2, 4, 6)[mode] if v < 9 else (3, 4, 5)[mode]
        spacing = 416/(count-1) if v < 9 else 104
        joints = [[0, -226+i*spacing] for i in range(count)]
        d.path([core]+joints, 20, 0, 0, .6)
        for i, q in enumerate(joints):
            span = 321-i*41+band*4
            for side in (-1, 1):
                end = [side*span, q[1]+137]
                branch = d.curve(q, [side*span*.45, q[1]-36],
                                 [side*span, q[1]+21], end, 13-i*.7,
                                 1 if i%2 else 0, 1+i*2+(side == 1), .53, True, 3.5)
                p = branch[15]
                _fall(d, p, [p[0]+side*22, p[1]+115], 1+i*2+(side == 1),
                      v, 4.8, 0, side)
        d.node(core, 45)
        d.ring([0, 19], 410, 1.6, 1, 80, 51, 2)
        return d.finish("stacked drooping branch canopies of decreasing span", count*2)
    if st == 5:
        core = [0, -302]
        sides = []
        for side in (-1, 1):
            arc = d.curve(core, [side*214, -360], [side*366, -145],
                          [side*344, 77], 18, 0, int(side == 1), .6, True, 3.6)
            indices = ((7, 13, 19), (6, 11, 16, 21), (6, 10, 14, 18, 22))[mode]
            for i, ix in enumerate(indices):
                q = arc[ix]
                end = [q[0]-side*(18+band*7), 231+i*37]
                _fall(d, q, end, 2+int(side == 1)*5+i, v, 8.7-i*.3,
                      1 if len(indices)>3 else 2, -side)
            sides.append(arc[-1])
        d.node(core, 47)
        d.ring([0, -15], 428, 1.7, 1, 75, 52, 1)
        if v%2:
            for q in sides: d.node(q, 9, "junction", 2)
        return d.finish("twin high arches carrying a descending ribbon curtain", len(indices)*2)
    if st == 6:
        left, right, merge = [-261, -288], [261, -288], [0, 21]
        for side, core in enumerate((left, right)):
            d.curve(core, [core[0]*.91, -87], [core[0]*.34, -49], merge,
                    20, side, side, .65)
            d.node(core, 41, color=side)
        d.node(merge, 30, "junction", 2)
        count = (5, 7, 9)[mode]
        for i in range(count):
            end = [-278+556*i/(count-1), 343+band*10-43*abs(i/(count-1)-.5)*2]
            _fall(d, merge, end, i+2, v, 12-i%2*2, 1 if count>=9 else 2,
                  -1 if i<count/2 else 1)
        d.ring([-71, 38], 338, 1.7, 2, 56, 7, 1)
        if v%2:
            d.ring([77, 16], 308, 1.3, 2, 74, -19, 2)
        return d.finish("two separate sources merge into a broad lower waterfall", count+2)
    if st == 7:
        core = [-292, -300]
        end = [282, 311]
        main = d.curve(core, [-150, -292], [159, 151], end, 22, 0, 0, .55, True, 4)
        indices = ((5, 10, 15, 20), (4, 8, 12, 16, 20),
                   (4, 7, 10, 13, 16, 19))[mode]
        for i, ix in enumerate(indices):
            q = main[ix]
            e = [q[0]-78-mode*14, q[1]+143+band*7]
            _fall(d, q, e, i+1, v, 10.7-i*.4, 2 if len(indices)<6 else 1, -1)
            if (v+i)%3 == 0:
                e2 = [q[0]+74, q[1]+58]
                _fall(d, q, e2, i+1, v, 4.2, 0, 1)
        d.node(core, 46)
        d.ring([0, 4], 426, 1.7, 2, 82, -37, 2)
        return d.finish("diagonal silver stream carrying downward hanging tributaries", len(indices)+1)
    if st == 8:
        core = [0, -131]
        count = (5, 7, 9)[mode]
        for i in range(count):
            x = -346+692*i/(count-1)
            end = [x, 253+123*(1-abs(x)/360)+band*7]
            dx = end[0]-core[0]
            arc = d.curve(core, [core[0]+dx*.62, -219],
                          [end[0]+dx*.13, 69], end, 15-i%3,
                          0 if i%2 else 1, i, .49, True, 3.8)
            for k, ix in enumerate((11, 18) if count<9 else (16,)):
                q = arc[ix]
                side = -1 if x<0 else 1
                e = [q[0]+side*(30+mode*7), q[1]+101-k*13]
                _fall(d, q, e, i, v, 5.1, 0, side)
        d.node(core, 48)
        d.ring([0, 42], 390, 1.9, 1, 83, 48, 1)
        if v%2: d.ring([0, 69], 317, 1.3, 2, 56, 12, 2)
        return d.finish("high fountain source with wide arcing then drooping branches", count)
    core = [0, -324]
    joints = [[0, -179], [0, -39], [0, 89]]
    d.path([core]+joints, 24, 0, 0, .68)
    count = (5, 7, 9)[mode]
    base = joints[-1]
    for i in range(count):
        end = [-327+654*i/(count-1), 351+band*10-(i%2)*35]
        _fall(d, base, end, i+1, v, 12-i%2*2,
              1 if count>=9 else 2, -1 if i<count/2 else 1)
    for j, q in enumerate(joints[:-1]):
        for side in (-1, 1):
            _fall(d, q, [side*(153+j*54), q[1]+143], count+j*2+1+(side == 1),
                  v, 7.8, 1, side)
    d.node(core, 47)
    d.node(base, 18, "junction", 2)
    d.ring([0, 22], 416, 2, 1, 80, 52, 1)
    return d.finish("single descending trunk ending in a wide weeping ribbon skirt", count+4)


def build(family: str, subtype: int, variant: int, seed: int):
    """Build one of ten compositions; variant 9 is the separate GIF artwork."""
    if family not in FAMILIES:
        raise ValueError(f"Unsupported family {family!r}")
    if not (0 <= subtype < 10 and 0 <= variant < 10):
        raise ValueError("subtype and variant must be in 0..9")
    rng = random.Random(seed)
    d = {"Frost": _frost, "Crown": _crown, "Cascade": _cascade}[family](subtype, variant, rng)
    # A second explicit variant axis changes the architecture from balanced to
    # narrow/tall to broad/low. Combined with mode-dependent branch counts, this
    # supplies visibly different silhouettes in all nine static slots. The GIF
    # slot receives its own intermediate proportion and branching treatment.
    band = variant // 3
    sx = (1., .83, 1.18, .94)[band] * (1 + rng.uniform(-.014, .014))
    sy = (1., 1.12, .80, 1.06)[band] * (1 + rng.uniform(-.014, .014))
    for rec in d["paths"] + d["facets"]:
        rec["points"] = [[x*sx, y*sy] for x, y in rec["points"]]
    for rec in d["nodes"] + d["tips"]:
        rec["pos"] = [rec["pos"][0]*sx, rec["pos"][1]*sy]
    for rec in d["rings"]:
        rec["center"] = [rec["center"][0]*sx, rec["center"][1]*sy]
    extent = max(max(max(map(abs, p)) for p in rec["points"])+rec["width"]/2+8
                 for rec in d["paths"])
    for rec in d["nodes"] + d["tips"]:
        extent = max(extent, max(map(abs, rec["pos"]))+rec["radius"]+8)
    for rec in d["rings"]:
        extent = max(extent, max(map(abs, rec["center"]))+rec["radius"]+rec["width"]+7)
    for rec in d["facets"]:
        extent = max(extent, max(max(map(abs, p)) for p in rec["points"])+4)
    fit = min(1., 454./extent)
    if fit < 1:
        for rec in d["paths"] + d["facets"]:
            rec["points"] = [[x*fit, y*fit] for x, y in rec["points"]]
        for rec in d["nodes"] + d["tips"]:
            rec["pos"] = [rec["pos"][0]*fit, rec["pos"][1]*fit]
            rec["radius"] *= fit
        for rec in d["rings"]:
            rec["center"] = [rec["center"][0]*fit, rec["center"][1]*fit]
            rec["radius"] *= fit
    # Auxiliary primitives inherit the group of their attached rail. Anchor
    # points make multi-core compositions explicit for coherent layer motion.
    vertices = [(p, rec["group"]) for rec in d["paths"] for p in rec["points"]]
    for rec in d["nodes"] + d["tips"]:
        rec["group"] = min(vertices, key=lambda item: math.dist(rec["pos"], item[0]))[1]
    for rec in d["facets"]:
        center = [sum(p[k] for p in rec["points"])/len(rec["points"]) for k in range(2)]
        rec["group"] = min(vertices, key=lambda item: math.dist(center, item[0]))[1]
    hubs = [rec["pos"] for rec in d["nodes"] if rec["style"] == "hub"]
    d["anchor_points"] = {}
    for rec in d["paths"]:
        group = str(rec["group"])
        if group not in d["anchor_points"]:
            d["anchor_points"][group] = list(min(hubs, key=lambda p: math.dist(p, rec["points"][0])))
    return d


def _selftest():
    hashes = set()
    for fi, family in enumerate(FAMILIES):
        counts = []
        for st in range(10):
            for v in range(10):
                g = build(family, st, v, 710000+fi*10000+st*100+v)
                assert g["name"] == family
                assert g["paths"] and len(g["paths"]) <= 70, (family, st, v, len(g["paths"]))
                # Connectivity across exact shared rail vertices or a hub's disk.
                hub_nodes = [n for n in g["nodes"] if n["style"] == "hub"]
                reached = set()
                vertices = set()
                remaining = list(range(len(g["paths"])))
                while remaining:
                    added = []
                    for i in remaining:
                        pts = g["paths"][i]["points"]
                        attach = any(tuple(p) in vertices for p in pts)
                        attach |= any(math.dist(p, n["pos"]) <= n["radius"]
                                      for p in pts for n in hub_nodes)
                        if attach:
                            added.append(i)
                            vertices.update(map(tuple, pts))
                    assert added, ("disconnected", family, st, v, remaining)
                    reached.update(added)
                    remaining = [i for i in remaining if i not in reached]
                for path in g["paths"]:
                    assert 2 <= path["width"] <= 24
                    assert .45 <= path["taper"] <= .85
                    for a, b in zip(path["points"], path["points"][1:]):
                        assert math.dist(a, b) > 1e-6
                    for p in path["points"]:
                        assert all(math.isfinite(z) for z in p)
                        assert max(map(abs, p))+path["width"]/2+8 < 470
                for tip in g["tips"]:
                    assert tuple(tip["pos"]) in vertices, ("orphan tip", family, st, v)
                for rec in g["nodes"] + g["tips"]:
                    assert max(map(abs, rec["pos"]))+rec["radius"]+8 < 470
                for rec in g["rings"]:
                    assert max(map(abs, rec["center"]))+rec["radius"]+rec["width"]+7 < 470
                signature = hashlib.sha256(json.dumps(g, sort_keys=True).encode()).hexdigest()
                assert signature not in hashes
                hashes.add(signature)
                counts.append(len(g["paths"]))
        print(f"{family}: 100 connected unique scenes; paths {min(counts)}..{max(counts)}; "
              f"subtypes: {', '.join(SUBTYPES[family])}")
    print(f"PASS: {len(hashes)} scenes")


if __name__ == "__main__":
    _selftest()
