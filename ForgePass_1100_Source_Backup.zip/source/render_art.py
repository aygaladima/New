"""Coherent depth planes, fixed hubs, and shaded vector geometry for Forge Pass."""
from pathlib import Path
import math,copy
import numpy as np
from PIL import Image,ImageChops,ImageFilter
import style
COUNT=240

def canonical(frame):
 f=frame%COUNT
 return f if f<=60 else (120-f if f<=180 else f-240)
def opening(frame):return round(.5+.5*math.sin(2*math.pi*canonical(frame)/COUNT),12)

class Renderer:
 def __init__(self,g,item):
  self.g=g;self.item=item;self.palette=[tuple(c) for c in item['palette']]
  style._cache.clear();style.PALETTES[item['family']]=self.palette
  self.hubs=[n for n in g['nodes'] if n['style']=='hub']
  self.center=np.mean([n['pos'] for n in self.hubs],axis=0) if self.hubs else np.array([0.,0.])
  layout=g.get('layout','').lower();name=item['family']
  self.mode='radial'
  if any(w in layout for w in ['vertical','tower','curtain','hanging','cascade','column','pagoda','upright','pinnacle']):self.mode='vertical'
  elif any(w in layout for w in ['bridge','horizontal','wings','span']):self.mode='bridge'
  elif any(w in layout for w in ['asym','offset','slant','fan','crest','comet','windswept','crescent']):self.mode='hinged'
  self.sign=-1 if item['subtype_index']%2 else 1
 def pose(self,frame,layer):
  o=opening(frame);c=self.center
  if layer=='front':scale=.80+.17*o;angle=self.sign*(3.0 if self.mode!='vertical' else 1.5)*o
  else:scale=.80-.015*o;angle=-self.sign*1.2*o
  shift=np.array([0.,0.])
  if self.mode=='bridge':shift[1]=(-9 if layer=='front' else 7)*o
  if self.mode=='vertical':shift[0]=(-7 if layer=='front' else 5)*self.sign*o
  if self.mode=='hinged':angle*=1.25
  a=math.radians(angle);co,si=math.cos(a),math.sin(a)
  mat=np.array([[co,-si],[si,co]])*scale
  def move(points):return ((np.array(points,dtype=float)-c)@mat.T+c+shift).tolist()
  return move,scale,o
 def render(self,frame=60,size=1000,supersample=2):
  if self.item['tier']=='Preview':return style.render(self.g,size,supersample)
  scale=size*supersample/1024;im=style.background(round(size*supersample),self.palette);p=style.Painter(im,scale)
  rear,rear_scale,o=self.pose(frame,'rear');front,front_scale,_=self.pose(frame,'front')
  back=style.colour(self.palette[1],.80,.10)
  if self.g['rings']:
   source=self.g['rings'][0];r=copy.deepcopy(source);r['center']=rear([r['center']])[0];r['radius']*=rear_scale;r['width']=max(1.,source['width']*.28);r['color']=1
   style.ring(p,r,self.palette)
  for rec in self.g['paths']:
   pts=rear(rec['points']);width=max(1.1,rec['width']*.24)
   p.line(pts,style.colour(back,.16),width+2,(1.4,2.4));p.line(pts,style.colour(back,.72),width+1);p.line(pts,back,max(.7,width*.58))
  for fac in self.g.get('facets',[]):
   pts=rear(fac['points']);p.polygon(pts,style.colour(back,.3));p.line(pts+[pts[0]],back,.65)
  for tip in self.g['tips']:
   q=rear([tip['pos']])[0];style.orb(p,q,max(1.6,tip.get('radius',3)*.62),back)
  for r0 in self.g['rings']:
   r=copy.deepcopy(r0);r['center']=front([r0['center']])[0];r['radius']*=.82+.16*o;style.ring(p,r,self.palette)
  for fac in self.g.get('facets',[]):
   pts=front(fac['points']);col=self.palette[fac.get('color',0)];p.polygon(pts,style.colour(col,.4));p.line(pts+[pts[0]],style.colour(col,.9,.2),.7)
  moved=[]
  for rec in self.g['paths']:
   r=dict(rec);r['points']=front(rec['points']);moved.append(r)
  for hub in self.hubs:
   origin=hub['pos'];q=front([origin])[0]
   if math.dist(origin,q)>hub['radius']*.24:moved.append({'points':[origin,q],'width':min(13.,hub['radius']*.36),'taper':.8,'color':hub.get('color',0)})
  for rec in sorted(moved,key=lambda r:-r['width']):style.rail(p,rec,self.palette)
  for tip in self.g['tips']:style.orb(p,front([tip['pos']])[0],tip.get('radius',3),self.palette[tip.get('color',2)])
  for node in self.g['nodes']:
   if node['style']=='hub':continue
   n=dict(node);n['pos']=front([node['pos']])[0];style.hub(p,n,self.palette,self.item['family'])
  for hub in self.hubs:style.hub(p,hub,self.palette,self.item['family'])
  emission=im.point([max(0,round((v-140)*.12)) for v in range(256)]*3)
  im=ImageChops.add(im,emission.filter(ImageFilter.GaussianBlur(scale*1.5)))
  return im.resize((size,size),Image.Resampling.LANCZOS)
