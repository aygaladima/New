"""The approved 11 × 10 × (9 Preview + 1 Volumetric) collection allocation."""
from pathlib import Path
import json,hashlib,colorsys,copy
import style
import family_a,family_b,family_c,family_d
ROOT=Path(__file__).resolve().parents[1]
FAMILIES=['Circuit','Lightning','Coral','Frost','Roots','Trident','Crown','Lattice','Cascade','Bonsai','Starburst']
MODULES={f:mod for mod in [family_a,family_b,family_c,family_d] for f in mod.FAMILIES} if all(hasattr(m,'FAMILIES') for m in [family_a,family_b,family_c,family_d]) else {'Circuit':family_a,'Lightning':family_a,'Trident':family_a,'Coral':family_b,'Roots':family_b,'Bonsai':family_b,'Frost':family_c,'Crown':family_c,'Cascade':family_c,'Lattice':family_d,'Starburst':family_d}
def fingerprint(g):
 visual={k:g.get(k,[]) for k in ['paths','tips','rings','nodes','facets']}
 return hashlib.sha256(json.dumps(visual,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def palette(family,subtype,variant):
 base=copy.deepcopy(style.PALETTES[family]);role=(variant+subtype)%6
 if role==1:base=[base[1],base[0],base[2]]
 if role==3:base=[base[0],base[2],base[1]]
 if role==5:base=[base[1],base[2],base[0]]
 hue=[-.025,0,.022,-.014,.014,0,.03,-.022,.009,0][variant]
 result=[]
 for index,c in enumerate(base):
  h,l,s=colorsys.rgb_to_hls(*(v/255 for v in c));h=(h+hue)%1
  l=max(.18,min(.83,l*[.95,1.04,1.,1.06,.93,1.02,1.08,.97,1.03,1.][variant]))
  result.append([round(v*255) for v in colorsys.hls_to_rgb(h,l,s)])
 return result

def main():
 items=[];geometry_hashes=set();root=ROOT/'geometry';root.mkdir(parents=True,exist_ok=True)
 for fi,family in enumerate(FAMILIES):
  for sub in range(10):
   for variant in range(10):
    ident=fi*100+sub*10+variant+1;tier='Volumetric' if variant==9 else 'Preview';seed=850199+ident*7919
    g=MODULES[family].build(family,sub,variant,seed)
    assert g['name']==family
    # A modest safety inset leaves room for depth-plane movement on animated pieces.
    if tier=='Volumetric':
     factor=.94
     for rec in g['paths']+g.get('facets',[]):
      rec['points']=[[x*factor,y*factor] for x,y in rec['points']]
      if 'width' in rec:rec['width']*=factor
     for rec in g['tips']+g['nodes']:rec['pos']=[v*factor for v in rec['pos']];rec['radius']*=factor
     for rec in g['rings']:rec['center']=[v*factor for v in rec['center']];rec['radius']*=factor;rec['width']*=factor
    gh=fingerprint(g);assert gh not in geometry_hashes,('Duplicate visual geometry',ident);geometry_hashes.add(gh)
    path=f'geometry/{ident:04d}.json';(ROOT/path).write_text(json.dumps(g,separators=(',',':'))+'\n')
    prefix=f'ForgePass_{ident:04d}_{family}_{tier}'
    item={'id':ident,'name':f'Forge Pass #{ident:04d}','family':family,'subtype_index':sub,'subtype_name':g['subtype_name'],'variant':variant,'tier':tier,'seed':seed,'palette':palette(family,sub,variant),'geometry_sha256':gh,'geometry_file':path,'layout':g.get('layout',''),'main_assemblies':g.get('main_assemblies',0),'path_count':len(g['paths']),'png':f'{tier}/{prefix}.png'}
    if tier=='Volumetric':item['gif']=f'{tier}/{prefix}.gif'
    items.append(item)
 manifest={'collection':'Forge Pass','edition_size':1100,'tier_counts':{'Preview':990,'Volumetric':110},'family_count':11,'structural_subtype_count':110,'per_family':{'Preview':90,'Volumetric':10},'per_subtype':{'Preview':9,'Volumetric':1},'png_size':[2048,2048],'gif_size':[1000,1000],'gif_fps':20,'volumetric_seconds':12,'artwork_ids_are_not_assigned_onchain_token_ids':True,'items':items}
 (ROOT/'Collection.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print('Built',len(items),'unique geometry definitions across',len(FAMILIES),'families and110subtypes',flush=True)
if __name__=='__main__':main()
