#!/usr/bin/env python3
"""Package the fully validated Forge Pass 1,100 collection, without publishing.

The completed Validation.json is the only media inventory accepted. Each family
is packed independently; an animated artwork's PNG and GIF always stay together.
Existing delivery files are immutable: an identical archive is reused, while a
different file under an existing delivery name causes a stop.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import tempfile
from urllib.parse import quote
import zipfile

BRANCH = "forge-pass-1100-collection"
BASE_URL = f"https://github.com/aygaladima/New/raw/refs/heads/{BRANCH}/"
ROOT = Path(__file__).resolve().parents[1]
ARTWORK_COUNT, PNG_COUNT, GIF_COUNT = 1100, 1100, 110
MEDIA_COUNT = PNG_COUNT + GIF_COUNT
TIER_COUNTS = {"Preview": 990, "Volumetric": 110}
RAW_LIMIT = 90_000_000
ZIP_LIMIT = 95_000_000
SOURCE_LIMIT = 80_000_000
FIXED_TIME = (2026, 10, 18, 0, 0, 0)
SAFE_FILENAME = re.compile(r"[A-Za-z0-9_.-]+\Z")
HEX_SHA = re.compile(r"[0-9a-f]{64}\Z")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(source):
    if isinstance(source, (Path, str)):
        with Path(source).open("rb") as stream:
            return sha256(stream)
    digest = hashlib.sha256()
    for chunk in iter(lambda: source.read(1024 * 1024), b""):
        digest.update(chunk)
    return digest.hexdigest()


def safe_relative(value):
    require(isinstance(value, str) and value and "\\" not in value, "Invalid relative path")
    path = PurePosixPath(value)
    require(not path.is_absolute() and str(path) == value and all(part not in (".", "..") for part in path.parts),
            f"Unsafe relative path: {value}")
    return path


def checked_source(base, relative):
    relative = safe_relative(relative)
    path = base.joinpath(*relative.parts)
    require(path.is_file() and not path.is_symlink(), f"Missing or symlinked source file: {relative}")
    require(path.resolve().is_relative_to(base.resolve()), f"Source path escapes its root: {relative}")
    return path


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def install_immutable(temporary, destination):
    """Install without replacing an existing file, including races with writers."""
    require(not destination.is_symlink(), f"Refusing symlinked delivery destination: {destination.name}")
    if destination.exists():
        require(destination.is_file() and sha256(destination) == sha256(temporary),
                f"Different file already exists; preserving it: {destination}")
        return
    try:
        os.link(temporary, destination)
    except FileExistsError:
        require(destination.is_file() and not destination.is_symlink()
                and sha256(destination) == sha256(temporary),
                f"Different file appeared during packaging: {destination.name}")


def write_immutable(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(prefix=".forge-package-", dir=path.parent, delete=False) as stream:
        temporary = Path(stream.name)
        stream.write(content)
    try:
        install_immutable(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def zip_info(name, compression=zipfile.ZIP_STORED):
    safe_relative(name)
    info = zipfile.ZipInfo(name, FIXED_TIME)
    info.compress_type = compression
    info.create_system = 3
    info.external_attr = 0o100644 << 16
    return info


def add_file(archive, source, name, compression=zipfile.ZIP_STORED):
    with source.open("rb") as incoming, archive.open(zip_info(name, compression), "w") as outgoing:
        shutil.copyfileobj(incoming, outgoing, length=1024 * 1024)


def check_art_archive(path, members):
    expected = {member["artifact"]: member for member in members}
    require(len(expected) == len(members), "Duplicate archive member definitions")
    with zipfile.ZipFile(path) as archive:
        require(len(archive.infolist()) == len(expected) and set(archive.namelist()) == set(expected),
                f"Archive coverage differs: {path.name}")
        for info in archive.infolist():
            record = expected[info.filename]
            require(info.file_size == record["bytes"], f"Archive member size differs: {info.filename}")
            # Reading every member to EOF verifies its ZIP CRC as well as SHA256.
            with archive.open(info) as stream:
                require(sha256(stream) == record["sha256"], f"Archive member hash differs: {info.filename}")


def load_validated_collection(root, verify_hashes=True):
    collection = json.loads((root / "Collection.json").read_text(encoding="utf-8"))
    report = json.loads((root / "Validation.json").read_text(encoding="utf-8"))
    require(report.get("complete") is True, "Validation.json must report complete:true")
    require(report.get("artwork_count") == ARTWORK_COUNT and report.get("media_count") == MEDIA_COUNT
            and report.get("png_count") == PNG_COUNT and report.get("gif_count") == GIF_COUNT
            and report.get("tier_counts") == TIER_COUNTS, "Validation counts differ from the approved collection")
    items = collection["items"]
    require(len(items) == ARTWORK_COUNT and {item["id"] for item in items} == set(range(1, ARTWORK_COUNT + 1)),
            "Collection IDs must cover 1–1100 exactly once")
    require(Counter(item["tier"] for item in items) == Counter(TIER_COUNTS), "Incorrect artwork tier counts")
    require(len({item["geometry_sha256"] for item in items}) == ARTWORK_COUNT
            and all(HEX_SHA.fullmatch(item["geometry_sha256"]) for item in items), "Geometry hashes are missing or repeated")
    families = defaultdict(list)
    expected_files = {}
    for item in sorted(items, key=lambda entry: entry["id"]):
        require(isinstance(item["family"], str) and re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]*", item["family"]),
                "Family name is unsuitable for public filenames")
        require(item["tier"] in TIER_COUNTS and type(item["subtype_index"]) is int
                and item["subtype_index"] in range(10), "Unknown tier or subtype index")
        families[item["family"]].append(item)
        checked_source(root, item["geometry_file"])
        formats = ("png", "gif") if item["tier"] == "Volumetric" else ("png",)
        require(item["tier"] == "Volumetric" or not item.get("gif"), "Preview artwork unexpectedly has a GIF")
        for kind in formats:
            artifact = item[kind]
            relative = safe_relative(artifact)
            require(relative.parts[0] == item["tier"] and relative.suffix == "." + kind,
                    f"Media path has wrong tier or extension: {artifact}")
            require(artifact not in expected_files, f"Repeated media path: {artifact}")
            expected_files[artifact] = (item, kind)
    require(len(families) == 11, "Exactly eleven design families are required")
    for family, family_items in families.items():
        require(len(family_items) == 100 and Counter(item["tier"] for item in family_items)
                == Counter({"Preview": 90, "Volumetric": 10}), f"Incorrect allocation for {family}")
        for index in range(10):
            subtype_items = [item for item in family_items if item["subtype_index"] == index]
            require(len(subtype_items) == 10 and Counter(item["tier"] for item in subtype_items)
                    == Counter({"Preview": 9, "Volumetric": 1}), f"Incorrect allocation for {family} subtype {index}")
            require(len({item["subtype_name"] for item in subtype_items}) == 1,
                    f"Subtype names disagree for {family} subtype {index}")
    records = report["files"]
    require(len(records) == MEDIA_COUNT and len({record["artifact"] for record in records}) == MEDIA_COUNT
            and {record["artifact"] for record in records} == set(expected_files), "Validated media coverage is incomplete")
    require(len({record["sha256"] for record in records}) == MEDIA_COUNT, "Duplicate media file hashes")
    by_id = defaultdict(list)
    for record in records:
        item, kind = expected_files[record["artifact"]]
        require(record["id"] == item["id"] and record["tier"] == item["tier"] and record["format"].lower() == kind,
                f"Validated media metadata disagrees: {record['artifact']}")
        require(type(record["bytes"]) is int and record["bytes"] > 0 and HEX_SHA.fullmatch(record["sha256"]),
                f"Missing media size or SHA256: {record['artifact']}")
        require(kind != "gif" or record["bytes"] < 50_000_000, f"GIF exceeds upload limit: {record['artifact']}")
        path = checked_source(root / "artwork", record["artifact"])
        require(path.stat().st_size == record["bytes"], f"Media size changed after validation: {record['artifact']}")
        if verify_hashes:
            require(sha256(path) == record["sha256"], f"Media changed after validation: {record['artifact']}")
        public_record = {key: record[key] for key in ("id", "tier", "format", "artifact", "bytes", "sha256")}
        public_record.update(family=item["family"], subtype_index=item["subtype_index"], subtype_name=item["subtype_name"])
        public_record["format"] = kind
        by_id[item["id"]].append(public_record)
    return collection, report, families, by_id


def plan_archives(families, by_id, raw_limit=RAW_LIMIT):
    require(50_000_000 < raw_limit <= RAW_LIMIT, "Raw archive limit must be above 50 MB and at most 90 MB")
    planned = []
    for family, items in families.items():
        batches, batch, size = [], [], 0
        for item in items:
            members = sorted(by_id[item["id"]], key=lambda record: (record["id"], record["format"] != "png"))
            needed = sum(record["bytes"] for record in members)
            require(needed <= raw_limit, f"Artwork {item['id']} cannot fit with its paired formats")
            if batch and size + needed > raw_limit:
                batches.append(batch)
                batch, size = [], 0
            batch.extend(members)
            size += needed
        if batch:
            batches.append(batch)
        for index, members in enumerate(batches, 1):
            ids = sorted({member["id"] for member in members})
            filename = f"ForgePass_1100_{family}_{index:02d}_{ids[0]:04d}-{ids[-1]:04d}.zip"
            planned.append({"filename": filename, "family": family, "part": index,
                            "artwork_ids": ids, "artwork_count": len(ids), "media_count": len(members),
                            "raw_bytes": sum(member["bytes"] for member in members), "artworks": members})
    return planned


def make_art_archive(root, out, plan):
    target = out / plan["filename"]
    require(not target.is_symlink(), f"Symlinked archive destination: {target.name}")
    if target.exists():
        check_art_archive(target, plan["artworks"])
    else:
        with tempfile.NamedTemporaryFile(prefix=".forge-art-", dir=out, delete=False) as stream:
            temporary = Path(stream.name)
        try:
            with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_STORED, allowZip64=False) as archive:
                for record in plan["artworks"]:
                    add_file(archive, checked_source(root / "artwork", record["artifact"]), record["artifact"])
            require(temporary.stat().st_size < ZIP_LIMIT, f"Archive exceeds public file limit: {target.name}")
            check_art_archive(temporary, plan["artworks"])
            install_immutable(temporary, target)
        finally:
            temporary.unlink(missing_ok=True)
    require(target.stat().st_size < ZIP_LIMIT, f"Archive exceeds public file limit: {target.name}")
    return dict(plan, bytes=target.stat().st_size, sha256=sha256(target), url=BASE_URL + quote(target.name))


RESTORE_GEOMETRY = '''#!/usr/bin/env python3
"""Restore the source backup's gzip-compressed geometry without overwriting files."""
import gzip
from pathlib import Path

root = Path(__file__).resolve().parent
files = sorted((root / "geometry").glob("*.json.gz"))
for compressed in files:
    target = compressed.with_suffix("")
    data = gzip.decompress(compressed.read_bytes())
    if target.exists():
        if not target.is_file() or target.is_symlink() or target.read_bytes() != data:
            raise SystemExit(f"Existing geometry differs; preserving it: {target}")
    else:
        with target.open("xb") as stream:
            stream.write(data)
print(f"Restored or checked {len(files)} geometry files")
'''


def source_contact_files(root):
    paths = []
    for directory in (root / "review",):
        if directory.exists():
            paths.extend(path for path in directory.rglob("*.jpg")
                         if path.is_file() and not path.is_symlink()
                         and not any(part.lower() in ("frames", "downloads", "delivery", "thumbnails")
                                     for part in path.relative_to(directory).parts))
    # Keep authoritative final still sheets and actual encoded-motion reviews.
    # Builder drafts and superseded variant comparisons remain local.
    internal = root / "internal"
    if internal.exists():
        paths.extend(path for path in internal.glob("*.jpg")
                     if path.is_file() and not path.is_symlink()
                     and (path.name.startswith(("Pilot_Motion_Review", "VisualReview_"))
                          or path.name == "Closest_Silhouettes.jpg"))
    # Prioritize the complete overview and family architecture sheets if the
    # optional review images approach the source ZIP's 80 MB budget.
    return sorted(paths, key=lambda path: (0 if "Overview" in path.name else
                                          1 if "Architectures" in path.name else
                                          2 if path.is_relative_to(root / "review") else 3,
                                          path.relative_to(root).as_posix()))


def make_source_backup(root, out, collection):
    """Source only; no vendor binaries, frame caches, credentials, PNGs or GIFs."""
    target = out / "ForgePass_1100_Source_Backup.zip"
    with tempfile.NamedTemporaryFile(prefix=".forge-source-", dir=out, delete=False) as stream:
        temporary = Path(stream.name)
    included, omitted = [], []
    try:
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=False) as archive:
            source_dir = root / "source"
            for path in sorted(source_dir.rglob("*")):
                if path.is_file() and not path.is_symlink() and path.suffix in (".py", ".json", ".md", ".txt"):
                    if any(part in ("__pycache__", "vendor", ".git") for part in path.relative_to(source_dir).parts):
                        continue
                    add_file(archive, path, path.relative_to(root).as_posix(), zipfile.ZIP_DEFLATED)
            for filename in ("Collection.json", "Validation.json", "README.md", "requirements.txt", "Collection_Plan.json", "Families_Subtypes.csv"):
                path = root / filename
                if path.is_file() and not path.is_symlink():
                    add_file(archive, path, filename, zipfile.ZIP_DEFLATED)
            for item in sorted(collection["items"], key=lambda item: item["id"]):
                path = checked_source(root, item["geometry_file"])
                archive.writestr(zip_info(item["geometry_file"] + ".gz"), gzip.compress(path.read_bytes(), compresslevel=6, mtime=0))
            archive.writestr(zip_info("Restore_Geometry.py", zipfile.ZIP_DEFLATED), RESTORE_GEOMETRY)
            for path in sorted((root / "internal").glob("*Review*.json")):
                if path.is_file() and not path.is_symlink():
                    add_file(archive, path, "validation/" + path.name, zipfile.ZIP_DEFLATED)
            require(temporary.stat().st_size < SOURCE_LIMIT - 1_000_000, "Source backup alone exceeds 79 MB")
            for path in source_contact_files(root):
                relative = path.relative_to(root).as_posix()
                if temporary.stat().st_size + path.stat().st_size + 200_000 < SOURCE_LIMIT:
                    add_file(archive, path, "contact_sheets/" + relative)
                    included.append(relative)
                else:
                    omitted.append(relative)
            archive.writestr(zip_info("BACKUP_CONTENTS.md", zipfile.ZIP_DEFLATED),
                              "# Source backup\n\nRun `python Restore_Geometry.py` once after extraction to restore "
                              "the gzip-compressed geometry JSON files. Then follow README.md.\n\n"
                              "The media are delivered separately. Collection.json is a production manifest, "
                              "not deployed NFT metadata. No minting or listing has been performed.\n\n"
                              f"Included contact sheets: {len(included)}. Omitted to keep this ZIP below 80 MB: {len(omitted)}.\n")
        require(temporary.stat().st_size < SOURCE_LIMIT, "Source backup exceeds 80 MB")
        with zipfile.ZipFile(temporary) as archive:
            require(archive.testzip() is None, "Source backup failed ZIP integrity validation")
        install_immutable(temporary, target)
    finally:
        temporary.unlink(missing_ok=True)
    return {"filename": target.name, "bytes": target.stat().st_size, "sha256": sha256(target),
            "url": BASE_URL + target.name, "included_contact_sheets": included, "omitted_contact_sheets": omitted}


def make_review_file(root, out, overview):
    candidates = [overview] if overview else [root / "review" / "ForgePass_1100_Overview.jpg"] + [
        root / "internal" / name for name in
        ("Collection_Overview.jpg", "ForgePass_1100_Overview.jpg", "Collection_Contact_Sheet.jpg")]
    source = next((path for path in candidates if path and path.is_file()), None)
    if source is None:
        return []
    require(not source.is_symlink(), "Symlinked overview image")
    destination = out / "ForgePass_1100_Overview.jpg"
    write_immutable(destination, source.read_bytes())
    return [{"filename": destination.name, "bytes": destination.stat().st_size, "sha256": sha256(destination),
             "url": BASE_URL + destination.name}]


def write_indexes(root, out, manifest):
    template = root / "source" / "README_DELIVERY_TEMPLATE.md"
    require(template.is_file(), "README_DELIVERY_TEMPLATE.md is required")
    total = sum(archive["bytes"] for archive in manifest["archives"])
    substitutions = {
        "{{ART_ZIP_COUNT}}": str(len(manifest["archives"])), "{{ART_GB}}": f"{total / 1e9:.2f}",
        "{{BASE_URL}}": BASE_URL,
        "{{COMPLETE_DOWNLOAD}}": "https://github.com/aygaladima/New/archive/refs/heads/" + BRANCH + ".zip",
    }
    introduction = template.read_text(encoding="utf-8")
    for key, value in substitutions.items():
        introduction = introduction.replace(key, value)
    lines = [introduction.rstrip(), ""]
    if manifest.get("review_files"):
        lines.extend(["[View all 110 structural subtypes](ForgePass_1100_Overview.jpg)", ""])
    lines.extend(["## Download the art ZIPs", "",
             "Each ZIP opens independently. Extract all ZIPs into the same folder to combine the Preview and Volumetric folders.", "",
             "| Family | Part | Artwork IDs | Contents | ZIP size | Download |",
             "|---|---:|---|---|---:|---|"])
    for archive in manifest["archives"]:
        counts = Counter(member["format"].upper() for member in archive["artworks"])
        contents = " + ".join(f"{counts[kind]} {kind}" for kind in ("PNG", "GIF") if counts[kind])
        ids = archive["artwork_ids"]
        # The manifest holds the exact ID list when a batch contains nonconsecutive IDs.
        lines.append(f"| {archive['family']} | {archive['part']} | {ids[0]:04d}–{ids[-1]:04d} | {contents} | "
                     f"{archive['bytes']/1e6:.1f} MB | [Download ZIP]({archive['url']}) |")
    source = manifest["source_backup"]
    lines.extend(["", "## Optional source backup", "",
                  f"[Source, geometry, collection map, validation, and review sheets]({source['url']}) "
                  f"({source['bytes']/1e6:.1f} MB). The source backup is separate from the 1,100 artworks.", "",
                  "After extracting the backup, run `python Restore_Geometry.py` before rebuilding.", "",
                  "[Package inventory and SHA-256 checksums](Package_Manifest.json)", ""])
    write_immutable(out / "ForgePass_1100_Downloads.md", "\n".join(lines).encode("utf-8"))
    write_immutable(out / "ForgePass_1100_README.md", introduction.rstrip().encode("utf-8") + b"\n")


def package(root=ROOT, raw_limit=RAW_LIMIT, overview=None):
    root = Path(root).resolve()
    collection, report, families, by_id = load_validated_collection(root)
    out = root / "packages"
    out.mkdir(exist_ok=True)
    archives = []
    for plan in plan_archives(families, by_id, raw_limit):
        archive = make_art_archive(root, out, plan)
        archives.append(archive)
        print(f"PACKAGED {archive['filename']} {archive['bytes']:,} bytes", flush=True)
    covered = [member for archive in archives for member in archive["artworks"]]
    require(len(covered) == MEDIA_COUNT and len({member["artifact"] for member in covered}) == MEDIA_COUNT,
            "Packaging did not cover the media exactly once")
    id_archive = defaultdict(set)
    for archive in archives:
        for ident in archive["artwork_ids"]:
            id_archive[ident].add(archive["filename"])
    require(len(id_archive) == ARTWORK_COUNT and all(len(locations) == 1 for locations in id_archive.values()),
            "An artwork is missing or its formats were split across archives")
    source = make_source_backup(root, out, collection)
    reviews = make_review_file(root, out, Path(overview).resolve() if overview else None)
    manifest = {
        "schema": "forge-pass-package-manifest-v1", "edition_size": ARTWORK_COUNT,
        "artwork_count": ARTWORK_COUNT, "media_count": MEDIA_COUNT, "png_count": PNG_COUNT, "gif_count": GIF_COUNT,
        "tier_counts": TIER_COUNTS, "family_count": 11,
        "family_allocation": {family: {"Preview": 90, "Volumetric": 10, "artworks": 100} for family in families},
        "subtypes_per_family": 10, "subtype_allocation": {"Preview": 9, "Volumetric": 1},
        "validation_complete": True, "coverage_exactly_once": True, "animated_formats_kept_together": True,
        "artwork_bytes": sum(record["bytes"] for record in report["files"]),
        "raw_archive_limit": raw_limit, "zip_file_limit_exclusive": ZIP_LIMIT,
        "publication_branch": BRANCH, "base_url": BASE_URL,
        "archives": archives, "source_backup": source, "review_files": reviews,
        "index_files": ["Package_Manifest.json", "ForgePass_1100_README.md", "ForgePass_1100_Downloads.md"],
    }
    write_immutable(out / "Package_Manifest.json", json_bytes(manifest))
    write_indexes(root, out, manifest)
    expected = {archive["filename"] for archive in archives}
    expected.update([source["filename"], *manifest["index_files"], *(item["filename"] for item in reviews)])
    unexpected = [path.name for path in out.iterdir() if path.name not in expected]
    require(not unexpected, f"Unexpected files in packages directory: {unexpected}")
    print(json.dumps({"art_archives": len(archives), "artwork_count": ARTWORK_COUNT,
                      "media_count": MEDIA_COUNT, "art_archive_bytes": sum(archive["bytes"] for archive in archives),
                      "source_backup_bytes": source["bytes"]}, indent=2), flush=True)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--raw-limit", type=int, default=RAW_LIMIT)
    parser.add_argument("--overview", type=Path, help="Optional JPG overview to publish beside the ZIPs")
    parser.add_argument("--plan", action="store_true", help="Validate and show archive groups without writing packages")
    args = parser.parse_args()
    if args.plan:
        _, _, families, by_id = load_validated_collection(args.root.resolve())
        plans = plan_archives(families, by_id, args.raw_limit)
        print(json.dumps([{key: value for key, value in plan.items() if key != "artworks"} for plan in plans], indent=2))
    else:
        package(args.root, args.raw_limit, args.overview)


if __name__ == "__main__":
    main()
