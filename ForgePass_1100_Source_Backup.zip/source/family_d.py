"""Lattice and Starburst: twenty architectural templates, ten structural editions.

All geometry uses the shared, centred Forge Pass scene schema.  No rendering or
external libraries are used here.  Branches start on exact existing vertices.
"""
from __future__ import annotations

import hashlib
import json
import math
import random
import copy
from collections import defaultdict


LATTICE_NAMES = (
    'Diamond Citadel', 'Square Matrix', 'Hexagonal Truss', 'Hourglass Span',
    'Twin Frame Bridge', 'Upright Tower', 'Offset Mesh', 'Triangular Scaffold',
    'Crosswing Fan', 'Double Cage',
)
STARBURST_NAMES = (
    'Six Point Flare', 'Octave Compass', 'Twelve Ray Corona', 'Twin Nova',
    'Radiant Fan', 'Comet Tail', 'Stacked Suns', 'Offset Sun',
    'Split Wings', 'Fractal Flare',
)


def _polar(r, angle, center=(0, 0)):
    t = math.radians(angle)
    return [center[0] + r * math.cos(t), center[1] + r * math.sin(t)]


def _lerp(a, b, t):
    return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]


class _Scene:
    def __init__(self, family, subtype, variant):
        self.v = variant
        self.data = dict(name=family, subtype_name=(LATTICE_NAMES if family == 'Lattice'
                         else STARBURST_NAMES)[subtype], description='',
                         layout='', main_assemblies=0, paths=[], tips=[], rings=[],
                         nodes=[], facets=[])

    def path(self, points, width=8, color=0, group=0, taper=.72, tip=False):
        pts = [[float(x), float(y)] for x, y in points]
        if len(pts) < 2 or any(math.dist(a, b) < 1e-6 for a, b in zip(pts, pts[1:])):
            raise ValueError('A path needs nonzero consecutive segments')
        self.data['paths'].append(dict(points=pts, width=float(width), taper=taper,
                                        color=int(color), group=int(group)))
        if tip:
            self.tip(pts[-1], max(2.7, min(5, width*.35)), 2)
        return pts

    def tip(self, pos, radius=3.4, color=2):
        self.data['tips'].append(dict(pos=list(pos), radius=radius, color=color))

    def node(self, pos, radius=13, style='junction', color=1):
        self.data['nodes'].append(dict(pos=list(pos), radius=radius, style=style, color=color))

    def ring(self, center, radius, width=2.4, segments=1, gap=0, color=1, start=0):
        self.data['rings'].append(dict(center=list(center), radius=radius, width=width,
                                      segments=segments, gap=gap, color=color, start=start))

    def frame(self, points, width=8, color=0, group=0):
        return self.path(points + [points[0]], width, color, group, .83)

    def fork(self, root, outward, span, group=0, width=5, two=True):
        """A terminal fork whose root is an actual parent path vertex."""
        vx, vy = outward
        mag = math.hypot(vx, vy)
        ux, uy = vx/mag, vy/mag
        for side in ((-1, 1) if two else (1,)):
            knee = [root[0] + ux*span*.46 - uy*side*span*.22,
                    root[1] + uy*span*.46 + ux*side*span*.22]
            end = [root[0] + ux*span*.85 - uy*side*span*.43,
                   root[1] + uy*span*.85 + ux*side*span*.43]
            self.path([root, knee, end], width, 2 if side < 0 else 1, group, .53, True)

    def finish(self):
        d = self.data
        if self.v != 9:
            _preview_architecture(d, self.v)
        # One common affine scale preserves all shared vertices exactly, including
        # high-aspect-ratio templates and their node/ring clearances.
        extent = 1.0
        for p in d['paths']:
            extent = max(extent, *(math.hypot(*q)+p['width']/2+10 for q in p['points']))
        for item in d['nodes'] + d['tips']:
            extent = max(extent, math.hypot(*item['pos'])+item['radius']+10)
        for r in d['rings']:
            extent = max(extent, math.hypot(*r['center'])+r['radius']+r['width']/2+10)
        scale = min(1., 449./extent)
        def point(p):
            return [round(p[0]*scale, 6), round(p[1]*scale, 6)]
        for p in d['paths']:
            p['points'] = [point(q) for q in p['points']]
            p['width'] = max(2., round(p['width']*scale, 6))
        for item in d['nodes'] + d['tips']:
            item['pos'] = point(item['pos'])
            item['radius'] = round(item['radius']*scale, 6)
        for r in d['rings']:
            r['center'] = point(r['center'])
            r['radius'] = round(r['radius']*scale, 6)
            r['width'] = round(r['width']*scale, 6)
        # Ownership is recovered from exact shared vertices, which also gives
        # every terminal a group without changing the public helper signature.
        groups_by_vertex = {}
        for path in d['paths']:
            for q in path['points']:
                groups_by_vertex.setdefault(tuple(q), path['group'])
        for item in d['nodes'] + d['tips']:
            item['group'] = groups_by_vertex.get(tuple(item['pos']), 0)
        hubs = [item['pos'] for item in d['nodes'] if item['style'] == 'hub']
        anchor = [round(sum(p[k] for p in hubs)/len(hubs), 6) for k in (0,1)] if hubs else [0.,0.]
        d['anchor_points'] = {str(p['group']):list(anchor) for p in d['paths']}
        if len(d['paths']) > 65:
            raise ValueError(f"Too many paths: {len(d['paths'])}")
        return d


def _map_scene(d, transform, width_scale=1., radius_scale=1.):
    """Transform every occurrence of a shared vertex through the same function."""
    for p in d['paths']:
        p['points']=[transform(q) for q in p['points']]
        p['width']*=width_scale
    for item in d['nodes']+d['tips']:
        item['pos']=transform(item['pos']);item['radius']*=radius_scale
    for r in d['rings']:
        r['center']=transform(r['center']);r['radius']*=radius_scale;r['width']*=width_scale
    for fac in d['facets']:
        fac['points']=[transform(q) for q in fac['points']]


def _connected_miniature(d,budget):
    """Keep the strongest connected rails when a composition has two/three copies."""
    hubs=[n for n in d['nodes'] if n['style']=='hub']
    anchor=list(hubs[0]['pos']) if hubs else list(d['paths'][0]['points'][0])
    reached={tuple(anchor)};remaining=list(d['paths']);selected=[]
    while remaining and len(selected)<budget:
        candidates=[p for p in remaining if any(tuple(q) in reached for q in p['points'])]
        if not candidates:break
        winner=max(candidates,key=lambda p:p['width'])
        selected.append(winner);remaining.remove(winner)
        reached.update(tuple(q) for q in winner['points'])
    out=copy.deepcopy(d);out['paths']=copy.deepcopy(selected)
    for kind in ('nodes','tips'):
        out[kind]=[copy.deepcopy(n) for n in d[kind] if tuple(n['pos']) in reached]
    return out,anchor


def _preview_architecture(d,v):
    """Nine deliberately different silhouettes per subtype.

    The former modulo-only variations produced some near-identical outlines.
    These editions alter large-scale construction in addition to local forks:
    tall, wide, leaning, top-flared, base-flared, paired, stacked, triangular
    triptych and expanded perimeter architectures.  Volumetric v9 is untouched.
    """
    labels=('Tall Spire','Broad Span','Diagonal Drift','Upper Flare','Lower Flare',
            'Paired Assemblies','Stacked Assemblies','Triad Assemblies','Outer Expansion')
    d['edition_architecture']=labels[v]
    d['description']+=' Preview architecture: '+labels[v]+'.'
    if v<=4:
        def transform(p):
            x,y=p
            if v==0:return [x*.61,y*1.11]
            if v==1:return [x*1.21,y*.59]
            if v==2:return [x*.86+y*.42,y*.96]
            if v==3:return [x*(.86-.43*y/430),y*.95]
            return [x*(.86+.43*y/430),y*.95]
        _map_scene(d,transform,.95, .87 if v<2 else .93)
        # Make top/base-flared editions structurally different as well: every
        # selected existing vertex receives a pair of attached terminal forks.
        if v in (3,4):
            candidates=[]
            for p in d['paths']:
                if p['width']>=8 and len(p['points'])>=3:
                    q=p['points'][1]
                    if math.hypot(*q)>85 and q not in candidates:candidates.append(q)
            candidates.sort(key=lambda q:q[1],reverse=v==4)
            for i,q in enumerate(candidates[:3]):
                for sign in (-1,1):
                    end=[q[0]+sign*(62+9*i),q[1]+(-70 if v==3 else 70)]
                    d['paths'].append(dict(points=[list(q),end],width=3.5,taper=.51,color=2,group=70+i))
                    d['tips'].append(dict(pos=end,radius=3.2,color=2))
            if d['name']=='Starburst':
                # Upper and lower stellar editions also have immediately
                # different circular architecture, even in the stacked-sun case.
                if v==4:
                    d['rings']=[]
                elif d['rings']:
                    keep=max(d['rings'],key=lambda r:r['radius'])
                    keep['segments']=1;keep['gap']=56;keep['start']=-62
                    d['rings']=[keep]
        return
    if v in (5,6,7):
        count=3 if v==7 else 2
        scale=.40 if count==3 else .47
        offsets=([[-210,0],[210,0]] if v==5 else
                 [[0,-211],[0,211]] if v==6 else [[0,-230],[-210,156],[210,156]])
        mini,anchor=_connected_miniature(d,(65-(count-1))//count)
        aggregate={k:[] for k in ('paths','tips','rings','nodes','facets')}
        anchors=[]
        for copy_index,off in enumerate(offsets):
            part=copy.deepcopy(mini)
            _map_scene(part,lambda p:[p[0]*scale+off[0],p[1]*scale+off[1]],scale,scale)
            for path in part['paths']:
                path['group']=int(path['group'])+copy_index*100
            anchors.append([anchor[0]*scale+off[0],anchor[1]*scale+off[1]])
            for kind in aggregate:aggregate[kind].extend(part[kind])
        for i in range(count-1):
            aggregate['paths'].append(dict(points=[anchors[i],anchors[i+1]],width=6.5,
                                           taper=.83,color=1,group=900+i))
        d.update(aggregate);d['main_assemblies']*=count
        return
    # Outer Expansion: a compact detailed interior is linked to a new prominent
    # family-appropriate perimeter assembly, changing topology and circle count.
    _map_scene(d,lambda p:[p[0]*.54,p[1]*.54],.72,.58)
    hubs=[n for n in d['nodes'] if n['style']=='hub']
    anchor=hubs[0]['pos'] if hubs else d['paths'][0]['points'][0]
    n=(3+LATTICE_NAMES.index(d['subtype_name']) if d['name']=='Lattice'
       else 5+STARBURST_NAMES.index(d['subtype_name']))
    rim=[_polar(411,-90+i*360/n) for i in range(n)]
    if d['name']=='Lattice':
        d['paths'].append(dict(points=rim+[rim[0]],width=10.5,taper=.83,color=0,group=800))
    for i,end in enumerate(rim):
        knee=_lerp(anchor,end,.70)
        d['paths'].append(dict(points=[list(anchor),knee,end],width=8.3 if i%2==0 else 5.6,
                               taper=.53,color=1 if i%2 else 0,group=801+i))
        d['nodes'].append(dict(pos=end,radius=15 if d['name']=='Lattice' else 8,
                               style='junction' if d['name']=='Lattice' else 'orb',color=2))
    if d['name']=='Starburst':
        d['rings'].append(dict(center=[0,0],radius=444,width=3.8,segments=n,gap=16,start=-90,color=0))
    d['main_assemblies']+=n


def _lattice(subtype, v, rng):
    s = _Scene('Lattice', subtype, v)
    # Editions use independent changes to frame count, aspect ratio, peripheral
    # forks, bracing, node distribution, and structure height; never rotation only.
    aspect = (.81, 1.12, .94, 1.18, .86, 1.04, .92, 1.15, .98, 1.07)[v]
    levels = 2 + (v % 3)
    core = [0, 0]
    s.data['main_assemblies'] = 4
    if subtype in (0, 1, 2, 7):
        n = {0:4, 1:4, 2:6, 7:3}[subtype]
        rotation = {0:-90, 1:-135, 2:-90, 7:-90}[subtype]
        s.data['main_assemblies'] = n
        frames = []
        reach = 330 + (v//3)*15
        for layer in range(levels):
            radius = 100 + (reach-100)*layer/(levels-1)
            vertices = [_polar(radius, rotation + i*360/n) for i in range(n)]
            # Squares keep square construction but vary aspect; diamonds become
            # tall or wide, and the triangle/hexagonal templates retain identity.
            vertices = [[p[0]*aspect, p[1]/math.sqrt(aspect)] for p in vertices]
            frames.append(vertices)
            s.frame(vertices, 6.4 + 1.4*(layer % 2), 0 if layer == levels-1 else 1, layer)
        for i in range(n):
            spine = s.path([core]+[f[i] for f in frames], 15 if n != 6 else 12, 0, i, .61)
            s.node(frames[-1][i], 14 + (v%3)*3, color=1 if i%2 else 2)
            # The exact count of forked corners is an edition feature.
            if i < min(n, 1+v):
                s.fork(spine[-1], spine[-1], 53 + 5*(v%3), i, 5.3,
                       two=(v%2 == 0 or i%2 == 0))
        for layer in range(levels-1):
            for i in range(n):
                nxt = (i+1)%n
                s.path([frames[layer][i], frames[layer+1][nxt]], 3.6, 2, i, .82)
                if (v+i+layer)%3 == 0:
                    s.path([frames[layer][nxt], frames[layer+1][i]], 2.6, 1, i, .82)
        s.node(core, 43 if n != 3 else 49, 'hub', 0)
        s.data['layout'] = {0:'nested diamond trusses', 1:'nested rectangular grid',
                            2:'hexagonal triangulated cage', 7:'triangular scaffold'}[subtype]
        if v in (3, 6, 9):
            # A small broken centre halo creates different circle counts without
            # making this ringless family dependent on an enclosing circle.
            s.ring(core, 68, 2.3, n, 18, 2, -90)

    elif subtype == 3:
        pinch = 42 + (v%3)*18
        topy = -350 + (v//3)*9
        bottomy = 350 - (v%2)*25
        upper = [[-260*aspect,topy], [0,-pinch], [260*aspect,topy]]
        lower = [[-260/aspect,bottomy], [0,pinch], [260/aspect,bottomy]]
        s.path([upper[0], upper[1], lower[2]], 19, 0, 0, .71)
        s.path([upper[2], upper[1], lower[0]], 19, 0, 1, .71)
        s.path([upper[1], core, lower[1]], 14, 2, 2, .8)
        s.path([lower[0], lower[1], lower[2]], 8, 1, 2, .83)
        s.path([upper[0], upper[2]], 8, 1, 3, .83)
        for layer in range(2+v%3):
            t = (layer+1)/(3+v%3)
            for j, tri in enumerate((upper, lower)):
                left, right = _lerp(tri[1], tri[0],t), _lerp(tri[1],tri[2],t)
                # Interpolated points are inserted into a separate attached rib,
                # rooted at the actual shared triangle apex.
                s.path([tri[1], left, right, tri[1]], 4.1, 1 if layer%2 else 2, j, .83)
        for j,p in enumerate((upper[0],upper[2],lower[0],lower[2])):
            s.node(p, 16+(v%3)*3, color=j%3)
            if j <= v%4:
                s.fork(p, [p[0]*.25,p[1]*.12], 47, j, 5.1, two=v%2==0)
        s.node(core, 38, 'hub', 0)
        s.data['layout'] = 'pinched upper and lower triangular spans'

    elif subtype == 4:
        separation = 213 + (v%3)*11
        centers = [[-separation,0], [separation,0]]
        s.path([centers[0],core,centers[1]], 21, 0, 0, .83)
        for side,c in enumerate(centers):
            rx, ry = 133/aspect, 168*aspect
            corners = [[c[0]-rx,-ry],[c[0]+rx,-ry],[c[0]+rx,ry],[c[0]-rx,ry]]
            s.frame(corners, 12, 0, side)
            s.node(c, 34, 'hub', 1)
            for j,q in enumerate(corners):
                s.path([c,q], 5.6 if j%2 else 8.5, j%3, side, .63)
                s.node(q, 9+(v%3)*3, color=2)
                if j < 1+v%4:
                    s.fork(q,[q[0]-c[0],q[1]],50,side,4.4,two=(v+j)%2==0)
            if v >= 4:
                rr = 78 + (v%3)*9
                s.ring(c, rr, 2.2, 4+(v%2)*2, 10, 2, 45)
        # Multiple rails give the bridge a clear independent structural component.
        for off in (-44,44):
            s.path([centers[0],[-separation+92,off],[separation-92,off],centers[1]],
                   4.8,1 if off<0 else 2,2,.82)
        s.node(core, 14, color=2)
        s.data['main_assemblies'] = 2
        s.data['layout'] = 'two separate framed hubs joined by a narrow bridge'

    elif subtype == 5:
        count = 4 + v%3
        rows = []
        for j in range(count):
            y = 359 - 718*j/(count-1)
            width = (145 - j*60/(count-1))*aspect
            row = [[-width,y],[width,y]]
            rows.append(row)
            s.path(row, 10, 0, j, .82)
            s.node([0,y], 12+(v%2)*3, color=2)
            s.path([row[0],[0,y],row[1]], 3.8, 2, j, .82)
        for side in (0,1):
            s.path([row[side] for row in rows],20,0,side,.63)
            for j in range(count-1):
                s.path([rows[j][side],rows[j+1][1-side]],4.6,1 if side else 2,j,.83)
        for j,row in enumerate(rows[1:-1]):
            for side,q in enumerate(row):
                if (j+side+v)%3 != 0:
                    s.fork(q,[-1 if side==0 else 1,-.3],73+v*3,j,5.4,two=v%2==0)
        s.node(rows[0][0],15,color=1);s.node(rows[0][1],15,color=1)
        s.node([0,rows[0][0][1]],43,'hub',0)
        s.data['main_assemblies'] = count
        s.data['layout'] = 'tapered upright cross-braced tower'

    elif subtype == 6:
        core = [-95,54]
        hull = [[-343,-126],[-136,-348],[151,-290],[352,-40],
                [275,240],[9,348],[-304,259]]
        # Editions change mesh topology by inserting or removing one outer bay.
        if v%3 == 1:
            hull.pop(1)
        elif v%3 == 2:
            hull.insert(3,[295,-199])
        hull = [[x*min(1.12,aspect),y/(.93+.04*(v%4))] for x,y in hull]
        s.frame(hull, 10.5,0)
        inner = []
        for i,q in enumerate(hull):
            knee = _lerp(core,q,.48+(i%2)*.10)
            inner.append(knee)
            s.path([core,knee,q],15 if i%2==0 else 10,0 if i%2==0 else 1,i,.57)
            s.node(q,10+(i+v)%3*5,color=i%3)
        s.frame(inner,4.5,2)
        for i in range(len(hull)):
            if (i+v)%3!=0:
                s.path([inner[i],hull[(i+1)%len(hull)]],3.8,1,i,.81)
            if i < 1+v%4:
                s.fork(hull[i],[hull[i][0]-core[0],hull[i][1]-core[1]],47,i,4.5,two=v%2==0)
        s.node(core,48,'hub',0)
        s.data['main_assemblies'] = len(hull)
        s.data['layout'] = 'asymmetric triangulated polygon with an offset core'

    elif subtype == 8:
        s.node(core,48,'hub',0)
        wingcount = 3+v%3
        for side in (-1,1):
            previous = None
            nodes = []
            for j in range(wingcount):
                yy = -242+484*j/(wingcount-1)
                q = [side*(343-abs(yy)*.17),yy/aspect]
                knee = [side*(125+23*(j%2)),yy*.37]
                s.path([core,knee,q],18 if j in (0,wingcount-1) else 11,0, j,.58)
                s.node(q,14+(v%2)*5,color=1)
                s.fork(q,[side,-.35 if yy<0 else .35],57,j,4.8,two=v%2==0)
                nodes.append(q)
                if previous is not None:
                    s.path([previous,q],7.5,1,j,.83)
                previous=q
            for j in range(wingcount-1):
                s.path([nodes[j],core,nodes[j+1]],3.2,2,j,.83)
        if v in (2,5,8,9):
            s.ring(core,82,2.8,4,18,2,45)
        s.data['main_assemblies'] = 2
        s.data['layout'] = 'two broad triangulated wings with forked outer edges'

    elif subtype == 9:
        sep = 184+(v%3)*14
        centers = [[0,-sep],[0,sep]]
        s.path([centers[0],core,centers[1]],19,0,0,.8)
        for side,c in enumerate(centers):
            count = 4 if v%3!=2 else 6
            points = [_polar(181 if i%2==0 else 159,-90+i*360/count,c) for i in range(count)]
            points = [[p[0]*aspect,p[1]] for p in points]
            smaller = [_lerp(c,p,.59) for p in points]
            s.frame(points,12,0,side)
            for i,p in enumerate(points):
                s.path([c,smaller[i],p] if v>=3 else [c,p],7.5,1 if i%2 else 2,side,.62)
                s.node(p,9+(v+i)%3*3,color=1)
                if i < 1+v%4:
                    s.fork(p,[p[0]-c[0],p[1]-c[1]],37,side,3.7,two=v%2==0)
            if v>=3:
                s.frame(smaller,3.7,2,side)
            s.node(c,30+(v%2)*8,'hub',0)
        s.node(core,16,color=2)
        s.data['main_assemblies'] = 2
        s.data['layout'] = 'two vertically stacked polygonal cages without an enclosing halo'
    s.data['description'] = (s.data['subtype_name'] + ': ' + s.data['layout'] +
        '; edition-specific frame depth, brace pattern, terminal forks and junction count.')
    return s.finish()


def _ray(s, center, angle, reach, group, v, width=9, branches=1, color=0):
    mid = _polar(reach*.43,angle,center)
    root = _polar(reach*.69,angle,center)
    end = _polar(reach,angle,center)
    s.path([center,mid,root,end],width,color,group,.48,True)
    for j in range(branches):
        origin = mid if j%2 else root
        direction = angle + (1 if (j+group+v)%2 else -1)*(24+8*j)
        reach2 = reach*(.19 if j else .24)
        knee = _polar(reach2*.47,direction,origin)
        target = _polar(reach2,direction,origin)
        s.path([origin,knee,target],max(2.6,width*.39),1 if color==0 else 0,
               group,.5,True)
        if branches>=3 and j==0:
            tip = _polar(reach*.11,direction+43,knee)
            s.path([knee,tip],2.5,2,group,.5,True)
    return end


def _starburst(subtype,v,rng):
    s=_Scene('Starburst',subtype,v)
    core=[0,0]
    aspect=(.95,1.10,.88,1.04,.91,1.13,.98,1.07,.86,1.02)[v]
    if subtype in (0,1,2):
        count={0:6,1:8,2:12}[subtype]
        # Twelve-point corona remains sparse; the six-point flare receives deeper
        # forks, so the templates do not collapse to changing ray count alone.
        for i in range(count):
            long=i%2==0 or subtype==0
            reach=(412 if long else 258+v*5)*(1 if i%3 else .93)
            angle=-90+i*360/count
            _ray(s,core,angle,reach,i,v,12 if subtype==0 else (9 if long else 6),
                 branches=(1+v%3 if subtype==0 else (1 if long else int((i+v)%3==0))),
                 color=0 if long else 1)
        # Interstitial needles create another major count difference per edition.
        for j in range(v%4):
            angle=-90+(j+.5)*360/count
            _ray(s,core,angle,194+v*8,count+j,v,4.4,0,2)
        s.node(core,45+v%3*4,'hub',2)
        if subtype==0:
            s.ring(core,443,4.5,6,14,0,-87)
            if v>=4:s.ring(core,118,2.1,6,18,1,-90)
        elif subtype==1:
            for rad in (172,439) if v%2==0 else (143,294,439):
                s.ring(core,rad,2.2 if rad<400 else 4.2,8,12,1 if rad<400 else 0,-90)
        else:
            for k in range(2+v%3):
                s.ring(core,145+k*(295/(1+v%3)),2.2+k*.7,12 if k%2==0 else 6,
                       13+3*k,k%3,-86)
        s.data['main_assemblies']=count+v%4
        s.data['layout']={0:'six long deeply forked stellar spears',
                         1:'eight compass rays with a long-short hierarchy',
                         2:'twelve slender rays inside layered segmented coronas'}[subtype]

    elif subtype==3:
        separation=204+v%3*13
        centers=[[-separation,-36 if v%2 else 0],[separation,36 if v%2 else 0]]
        s.path([centers[0],core,centers[1]],13,0,0,.8)
        count=6+v%3
        for star,c in enumerate(centers):
            for i in range(count):
                angle=-90+i*360/count
                reach=(187 if i%2==0 else 126)*aspect
                _ray(s,c,angle,reach,star*count+i,v,8 if i%2==0 else 5,1 if (i+v)%3==0 else 0,
                     0 if star==0 else 1)
            s.node(c,35+(v%2)*5,'hub',0 if star==0 else 2)
            s.ring(c,211,2.9,6,17,1 if star==0 else 0,-90)
            if v>=6:s.ring(c,82,2.1,4,21,2)
        s.node(core,12,color=2)
        s.data['main_assemblies']=2
        s.data['layout']='two independently framed starbursts joined by one horizontal bridge'

    elif subtype==4:
        core=[0,237]
        count=7+v%5
        for i in range(count):
            angle=-160+140*i/(count-1)
            # All ends lie on an upper fan; different tiers change opening and
            # alternating reach, rather than simply rotating a centred burst.
            reach=(603 if i%2==0 else 475)*(1-.12*abs(i-(count-1)/2)/(count/2))
            _ray(s,core,angle,reach,i,v,12 if i%2==0 else 7,
                 2 if (i+v)%3==0 else 1,0 if i%2==0 else 1)
        s.node(core,51,'hub',0)
        s.ring([0,-33],405,3.6,1,100,2,140)
        if v%3==2:s.ring(core,95,2.8,6,16,1,-90)
        s.data['main_assemblies']=count
        s.data['layout']='upright wide stellar fan rising from a low core'

    elif subtype==5:
        core=[174,-124]
        count=7+v%4
        for i in range(count):
            angle=119+101*i/(count-1)
            reach=(580 if i%2==0 else 455)*(1-.10*abs(i-count/2)/count)
            _ray(s,core,angle,reach,i,v,12 if i in (2,3,4) else 7.5,
                 2 if (i+v)%4==0 else 1,0 if i%2==0 else 1)
        for i in range(2+v%3):
            _ray(s,core,-85+i*58,123+17*(i%2),count+i,v,5.3,0,2)
        s.node(core,43,'hub',0)
        s.ring(core,87,2.3,5,17,2,-90)
        if v>=5:s.ring(core,144,2.6,3,49,1,-80)
        s.data['main_assemblies']=count+2+v%3
        s.data['layout']='off-centre bright head with a long, asymmetric forked comet tail'

    elif subtype==6:
        centers=[[0,-257],[0,0],[0,257]]
        s.path(centers,12,1,0,.82)
        for star,c in enumerate(centers):
            count=5+(v+star)%3
            for i in range(count):
                angle=-90+i*360/count
                reach=(148 if i%2==0 else 105)*(.94+.025*v)
                _ray(s,c,angle,reach,star*8+i,v,8.2 if i%2==0 else 5.2,
                     int((i+star+v)%3==0),0 if star!=1 else 1)
            s.node(c,32 if star!=1 else 43,'hub',2 if star==1 else 0)
            s.ring(c,171,2.8,6 if star!=1 else 8,16,star%3,-90)
        s.data['main_assemblies']=3
        s.data['layout']='three vertically stacked small suns with separate coronas'

    elif subtype==7:
        core=[-119,-72]
        count=9+v%4
        for i in range(count):
            angle=-90+i*360/count
            # Elliptical reach follows the shifted boundary, making a clear
            # asymmetric sun with a broad right-hand side and compact left.
            reach=260+122*(1+math.cos(math.radians(angle)))/2
            if i%2:reach*=.72+.015*(v%3)
            _ray(s,core,angle,reach,i,v,10 if i%2==0 else 6,
                 2 if (i+v)%4==0 else 1,0 if i%2==0 else 1)
        s.node(core,49,'hub',2)
        s.ring([-18,-3],424,4,9,14,0,-90)
        s.ring(core,109+v%3*19,2.2,6,20,1,-90)
        if v>=6:s.ring(core,63,2.2,3,29,2,-80)
        s.data['main_assemblies']=count
        s.data['layout']='offset hub with unequal rays and nonconcentric halos'

    elif subtype==8:
        count=4+v%4
        for wing in range(2):
            base=0 if wing==0 else 180
            for j in range(count):
                angle=base-37+74*j/(count-1)
                reach=412 if j in (0,count-1) else 338+v%3*17
                _ray(s,core,angle,reach,wing*count+j,v,12 if j%2==0 else 7,
                     2 if (j+v)%3==0 else 1,0 if j%2==0 else 1)
        if v%3:
            for angle in (-90,90):
                _ray(s,core,angle,151+v*6,2*count,v,6,0,2)
        s.node(core,51,'hub',0)
        s.ring(core,111,3,4,24,2,45)
        if v>=5:s.ring(core,444,2.1,2,88,1,44)
        s.data['main_assemblies']=2
        s.data['layout']='two opposed broad ray fans with open vertical negative space'

    elif subtype==9:
        count=5+v%3
        for i in range(count):
            angle=-90+i*360/count
            trunk=_polar(242+(i%2)*20,angle)
            knee=_polar(137,angle)
            s.path([core,knee,trunk],15,0,i,.62)
            s.node(trunk,10+(v%2)*3,color=1)
            if i < v//3:
                # Later editions have a second, distinctly visible inner tier of
                # short stellar rays rather than repeating an earlier topology.
                s.fork(knee, _polar(1,angle), 87, i, 4.8, two=(v%2==0))
            prongs=2+int((i+v)%3==0)
            for j in range(prongs):
                direction=angle + (j-(prongs-1)/2)*(32+v%3*6)
                end=_polar(158 if j%2==0 else 132,direction,trunk)
                fork_mid=_lerp(trunk,end,.57)
                s.path([trunk,fork_mid,end],7.1,0 if j%2==0 else 1,i,.49,True)
                if (i+j+v)%2==0:
                    fine=_polar(49,direction+(32 if j%2==0 else -32),fork_mid)
                    s.path([fork_mid,fine],2.8,2,i,.5,True)
        s.node(core,48,'hub',2)
        s.ring(core,439,3.7,count,19,0,-90)
        if v%3!=0:s.ring(core,184,2.2,count*2,15,1,-90)
        s.data['main_assemblies']=count
        s.data['layout']='thick stellar trunks splitting into luminous secondary ray fans'
    s.data['description']=(s.data['subtype_name']+': '+s.data['layout']+
        '; edition-specific ray hierarchy, fork topology, satellites and corona layers.')
    return s.finish()


def build(family: str, subtype: int, variant: int, seed: int):
    if family not in ('Lattice','Starburst'):
        raise ValueError(f'Unsupported family: {family}')
    if not 0 <= subtype <= 9 or not 0 <= variant <= 9:
        raise ValueError('Subtype and variant must each be in 0..9')
    rng=random.Random(int(seed))
    # Seed intentionally supplies no geometric jitter: edition construction is
    # explicit and reproducible, while every family/subtype/variant is distinct.
    return _lattice(subtype,variant,rng) if family=='Lattice' else _starburst(subtype,variant,rng)


def _self_test():
    hashes=set()
    maximum=0
    for family in ('Lattice','Starburst'):
        for subtype in range(10):
            for variant in range(10):
                d=build(family,subtype,variant,850199+subtype*100+variant)
                maximum=max(maximum,len(d['paths']))
                vertices={tuple(p) for path in d['paths'] for p in path['points']}
                adjacency=defaultdict(set)
                for path in d['paths']:
                    for a,b in zip(path['points'],path['points'][1:]):
                        a,b=tuple(a),tuple(b)
                        adjacency[a].add(b);adjacency[b].add(a)
                reached={next(iter(adjacency))}
                pending=list(reached)
                while pending:
                    for vertex in adjacency[pending.pop()]:
                        if vertex not in reached:
                            reached.add(vertex);pending.append(vertex)
                assert reached==vertices,(family,subtype,variant,'Disconnected rail graph')
                # Every terminal and circle-node lands on an actual rail vertex.
                for item in d['tips']+d['nodes']:
                    assert tuple(item['pos']) in vertices,(family,subtype,variant,item)
                for p in d['paths']:
                    assert 2 <= p['width'] <= 24,(family,subtype,variant,p['width'])
                    assert .45 <= p['taper'] <= .85
                    for a,b in zip(p['points'],p['points'][1:]):assert math.dist(a,b)>1e-5
                    for q in p['points']:
                        assert all(math.isfinite(x) for x in q)
                        assert max(abs(x) for x in q)+p['width']/2+10<470
                for item in d['tips']+d['nodes']:
                    assert max(abs(x) for x in item['pos'])+item['radius']+10<470
                for r in d['rings']:
                    assert max(abs(x) for x in r['center'])+r['radius']+r['width']/2+10<470
                    assert 360/r['segments']>r['gap']
                # Exclude labels: uniqueness must come from the actual artwork.
                fields={k:d[k] for k in ('paths','nodes','tips','rings','facets')}
                h=hashlib.sha256(json.dumps(fields,sort_keys=True).encode()).hexdigest()
                assert h not in hashes
                hashes.add(h)
    return dict(items=len(hashes),max_paths=maximum,
                Lattice=list(LATTICE_NAMES),Starburst=list(STARBURST_NAMES))


if __name__=='__main__':
    print(json.dumps(_self_test(),indent=2))
