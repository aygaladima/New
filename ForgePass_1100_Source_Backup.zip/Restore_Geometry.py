#!/usr/bin/env python3
"""Restore the source backup's gzip-compressed geometry without overwriting files."""
import gzip
from pathlib import Path

root = Path(__file__).resolve().parent
files = sorted((root / "geometry").glob("*.json.gz"))
for compressed in files:
    target = compressed.with_suffix("")
    data = gzip.decompress(compressed.read_bytes())
    if target.exists():
        if not target.is_file() or target.is_symlink() or target.read_bytes() != data:
            raise SystemExit(f"Existing geometry differs; preserving it: {target}")
    else:
        with target.open("xb") as stream:
            stream.write(data)
print(f"Restored or checked {len(files)} geometry files")
