# Forge Pass — 1,100 artworks

Forge Pass contains **990 Preview artworks and 110 Volumetric artworks** across eleven distinct design families. Each family contains ten structural subtypes; each subtype contains nine individual Preview compositions and one individual Volumetric composition.

A complete collection export contains **1,100 high-resolution PNGs and 110 animated GIFs**, or **1,210 media files**. A Volumetric artwork's PNG is a still backup of that same artwork. It is not an additional Preview artwork or an additional NFT.

## Download and view the art

Use the public [download index](https://github.com/aygaladima/New/blob/forge-pass-1100-collection/ForgePass_1100_Downloads.md) for individual family batches, or the [complete collection ZIP](https://github.com/aygaladima/New/archive/refs/heads/forge-pass-1100-collection.zip) when that delivery has been published.

1. Download the complete outer ZIP, then extract it.
2. Extract the individual art ZIPs inside into one common destination. Their `Preview` and `Volumetric` folders combine into the full collection.
3. Open PNGs in an image viewer and GIFs in a browser or image viewer that supports animation.

The individual art ZIPs also work as separate downloads. Each is an ordinary, independent ZIP, below 95 MB. They are not split-volume archives. The PNG and GIF belonging to one Volumetric artwork stay in the same ZIP. Exact archive coverage, file sizes, and SHA-256 checksums are recorded in `Package_Manifest.json`.

**No code or Blender installation is needed to view or use the delivered artwork.** The source backup is optional and is needed only to inspect or regenerate the production files.

## Families, subtypes, and IDs

| Family | Artwork IDs | Preview | Volumetric | Total artworks |
|---|---|---:|---:|---:|
| Circuit | 0001–0100 | 90 | 10 | 100 |
| Lightning | 0101–0200 | 90 | 10 | 100 |
| Coral | 0201–0300 | 90 | 10 | 100 |
| Frost | 0301–0400 | 90 | 10 | 100 |
| Roots | 0401–0500 | 90 | 10 | 100 |
| Trident | 0501–0600 | 90 | 10 | 100 |
| Crown | 0601–0700 | 90 | 10 | 100 |
| Lattice | 0701–0800 | 90 | 10 | 100 |
| Cascade | 0801–0900 | 90 | 10 | 100 |
| Bonsai | 0901–1000 | 90 | 10 | 100 |
| Starburst | 1001–1100 | 90 | 10 | 100 |
| **Total** | **0001–1100** | **990** | **110** | **1,100** |

Every family occupies a block of 100 artwork IDs. Each structural subtype occupies ten IDs inside that family. The first nine are Preview artworks; the tenth is Volumetric. For example, Circuit's Quad Relay subtype uses Preview IDs 0001–0009 and Volumetric ID 0010. Its next subtype, Six-Gate Bloom, uses Preview IDs 0011–0019 and Volumetric ID 0020.

`Families_Subtypes.csv` lists all 110 subtypes, their names, allocations, and exact artwork IDs. `Collection.json` records every artwork's name, family, subtype, variant, palette, seed, geometry reference, geometry fingerprint, and media paths. The individual compositions are distinct artwork identities; an animated piece and its PNG backup share one identity.

**These are production artwork IDs, not assigned on-chain token IDs.** A future minting workflow must explicitly map them to token IDs.

## Media and animation

| Tier | Artworks | Files per artwork | Specification |
|---|---:|---|---|
| Preview | 990 | One PNG | 2048 × 2048, RGB, static composition |
| Volumetric | 110 | One GIF and one PNG | GIF: 1000 × 1000; PNG backup: 2048 × 2048 RGB at maximum separation |

Each Volumetric animation follows a **240-frame timeline at 20 fps**, lasts **12 seconds**, and loops indefinitely. Identical adjacent poses can be coalesced into one encoded GIF frame with a longer duration; the validated timeline still lasts 12 seconds. This distinction is recorded through source-frame count, encoded-frame count, and frame durations in the per-artifact reports.

Foreground and rear structures separate and merge slowly. Their scale, angle, or offset changes according to the composition's layout, and circular elements follow their relevant depth planes. Designs with a core hub retain a fixed hub interior while their surrounding assemblies move. Different families and subtypes have their own branch construction, silhouette, circular arrangements, palettes, and compositions.

The loop starts partially separated, reaches maximum separation around three seconds, passes through partial separation around six seconds, reaches the merged pose around nine seconds, and returns smoothly to its start. The PNG backup uses the maximum-separation pose.

GIFs use a global palette with no dithering. The encoder tries 256, 192, and then 128 colours as necessary to keep each GIF **strictly below 50,000,000 bytes**. Its selected palette size and exact byte count are recorded in the artifact report. No Motion tier, MP4 export, or SVG export is part of this delivery.

## Rendering method

The final renderer uses **Python, NumPy, Pillow, and FFmpeg**. It creates procedural 2.5D artwork from explicit paths, nodes, rings, facets, shaded rails, bevel-like highlights, extrusion edges, and layered animation. Controlled lighting and restrained glow preserve clear geometry against dark backgrounds.

The name Volumetric describes this collection's visible depth-layer movement. These files are not physically simulated volume renders or a collection of Blender models. Blender, a GPU, and paid rendering software are not required by the production pipeline.

## Files and records

```text
Collection.json                 Full artwork-to-geometry/media inventory
Collection_Plan.json            Approved allocation and export specifications
Families_Subtypes.csv           Readable map of all 110 structural subtypes
Validation.json                 Final validation results, once validation completes
requirements.txt                Python package versions used for production
geometry/0001.json ...          Individual deterministic geometry definitions
artwork/Preview/                990 Preview PNGs
artwork/Volumetric/             110 Volumetric GIFs and 110 PNG backups
source/                         Geometry builders, renderer, and production tools
internal/reports/               Per-artifact render and validation records
review/                         Family, subtype, and complete overview sheets
packages/                       Immutable art ZIPs, source backup, and download index
```

`Validation.json` and `Package_Manifest.json` describe the actual exported and packaged files. Their recorded hashes are authoritative for a completed delivery. This README does not substitute for those checks or freeze a temporary production state.

The optional source backup contains the Python source, project documents, compressed geometry, final validation report, and review sheets within its size budget. It excludes temporary frame caches, vendor binaries, and the artwork media already delivered in the art ZIPs. To restore the backup's `geometry/*.json.gz` files, run the included `Restore_Geometry.py` once after extraction.

## Optional reproduction

Work in a separate extracted copy when inspecting or rebuilding the source. The finished PNGs and GIFs can be used directly without these steps.

The production environment used:

- Python **3.12.14**.
- NumPy **2.3.5**.
- Pillow **12.3.0**.
- FFmpeg **7.1.5-0+deb13u1** as an external executable on `PATH`.

Install Python packages from `requirements.txt`. Install FFmpeg separately through your operating system; it is not a Python requirement. Git and curl are needed only for the optional publishing and remote-verification helper.

From the project root:

```bash
python -m pip install -r requirements.txt
python Restore_Geometry.py
python source/produce.py stills --workers 4
python source/produce.py animations --workers 4
python source/review_collection.py
python source/validate_collection.py
```

Run `Restore_Geometry.py` only when using the extracted source backup. An existing production workspace already has its uncompressed geometry files. Reduce `--workers` to fit the available CPU and memory. Use `--ids 1,2,10` to render selected artwork IDs; animation mode automatically limits its selection to Volumetric artworks.

To regenerate geometry from the included builders instead of restoring it, run `python source/build_collection.py` before production. This writes `Collection.json` and the 1,100 geometry definitions from the builder source, deterministic seeds, and ID allocation.

Production is resumable. An existing export is reused only when its recorded geometry fingerprint and render-pipeline fingerprint match the current source and its actual media checksum matches its report. Changed geometry or renderer code invalidates the corresponding cached export. Animation frame caches are bounded by active jobs and removed after each successful encoded export and validation.

PNG production loads each generated file and checks its size and RGB mode. GIF production fully decodes the encoded animation, checks durations and looping, checks fixed hub interiors where present, compares native loop endpoints, and measures visible separation and loop continuity. Final collection validation checks ID coverage, family/subtype allocation, geometry fingerprints, graph attachment, expected files, and unique media hashes. Review sheets and silhouette comparisons support visual inspection; their numerical scores do not replace that inspection.

After production, review, and final validation, the delivery tools can prepare immutable packages:

```bash
python source/package_collection.py --plan
python source/package_collection.py
python source/deliver_collection.py --mode plan
```

The delivery plan is local and read-only by default. Publishing requires the authorized `forge-pass-1100-collection` Git worktree and an explicit publish invocation. It uploads bounded batches and then downloads the public files to verify sizes, checksums, ZIP integrity, and artwork member hashes. The helpers preserve unknown existing files and do not force-push.

## NFT publication remains a separate process

Creating or delivering this collection does **not** mint NFTs, deploy a contract, set token supply, publish items to OpenSea, or list them for sale. `Collection.json` is a production manifest, not deployed NFT metadata.

Before NFT publication, select the chain, creation method, supply, media/metadata hosting, artwork-to-token mapping, and sale settings. Verify the current creation interface and its costs. A free rendering pipeline does not establish that deployment, minting, storage, or selling will also be free.

Use a real animated test to check the individual item page and collection grid before a full release. GIF autoplay and thumbnail behavior can vary by marketplace interface, browser, device, and settings. The delivered GitHub URLs provide project downloads; stable production NFT hosting remains a separate decision.
