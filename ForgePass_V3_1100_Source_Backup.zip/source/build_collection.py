"""V3: full sculptural compositions with consistent family-specific materials."""
from pathlib import Path
import json,hashlib,colorsys,copy,importlib
import style
ROOT=Path(__file__).resolve().parents[1]
BASE_PALETTES=copy.deepcopy(style.PALETTES)
FAMILIES=['Circuit','Lightning','Coral','Frost','Roots','Trident','Crown','Lattice','Cascade','Bonsai','Starburst']
MODULE_NAMES=['family_architectural','family_energy','family_organic','family_crown','family_cascade']
def modules():
 return {f:m for name in MODULE_NAMES for m in [importlib.import_module(name)] for f in m.FAMILIES}
def fingerprint(g):
 return hashlib.sha256(json.dumps({k:g.get(k,[]) for k in ['paths','tips','rings','nodes','facets']},sort_keys=True,separators=(',',':')).encode()).hexdigest()
def write_if_changed(path,text):
 data=text.encode()
 if path.exists() and path.read_bytes()==data:return
 temp=path.with_suffix(path.suffix+'.tmp');temp.write_bytes(data);temp.replace(path)
def palette(family,subtype,variant):
 # Material roles stay stable: gold Crown, jade Bonsai, silver Cascade, etc.
 base=copy.deepcopy(BASE_PALETTES[family]);shift=[-.012,.008,0,.016,-.008,.006,-.016,.011,-.004,.0][variant]
 result=[]
 for j,c in enumerate(base):
  h,l,s=colorsys.rgb_to_hls(*(v/255 for v in c));h=(h+shift)%1
  l=min(.82,max(.20,l*[1.,1.04,.98,1.07,1.02,.95,1.05,.99,1.03,1.][variant]))
  result.append([round(v*255) for v in colorsys.hls_to_rgb(h,l,s)])
 return result
def inset(g,factor):
 for rec in g['paths']+g.get('facets',[]):
  rec['points']=[[x*factor,y*factor] for x,y in rec['points']]
  if 'width' in rec:rec['width']*=factor
 for rec in g['nodes']+g['tips']:
  rec['pos']=[v*factor for v in rec['pos']];rec['radius']*=factor
 for rec in g['rings']:
  rec['center']=[v*factor for v in rec['center']];rec['radius']*=factor;rec['width']*=factor
 return g
def sculpture_fit(g):
 # Framing rings must never set the apparent size of a small central sculpture.
 # Enlarge only undersized primary bodies, with their attached local ornaments.
 bounds=[]
 for r in g['paths']:
  for x,y in r['points']:bounds.append((x-r['width']/2,y-r['width']/2,x+r['width']/2,y+r['width']/2))
 for r in g['nodes']+g['tips']:
  x,y=r['pos'];q=r['radius'];bounds.append((x-q,y-q,x+q,y+q))
 for r in g.get('facets',[]):
  for x,y in r['points']:bounds.append((x,y,x,y))
 for r in g['rings']:
  if r['radius']<180:
   x,y=r['center'];q=r['radius']+r['width'];bounds.append((x-q,y-q,x+q,y+q))
 lo=[min(b[k] for b in bounds) for k in [0,1]];hi=[max(b[k] for b in bounds) for k in [2,3]]
 span=max(hi[k]-lo[k] for k in range(2))
 if span>=820:return g
 factor=860/span;center=[(lo[k]+hi[k])/2 for k in range(2)]
 def move(p):return [(p[k]-center[k])*factor for k in range(2)]
 for r in g['paths']+g.get('facets',[]):
  r['points']=[move(p) for p in r['points']]
  if 'width' in r:r['width']*=factor
 for r in g['nodes']+g['tips']:r['pos']=move(r['pos']);r['radius']*=factor
 for r in g['rings']:
  if r['radius']<180:r['center']=move(r['center']);r['radius']*=factor;r['width']*=factor
 def anchors(a):
  if isinstance(a,dict):return {k:anchors(v) for k,v in a.items()}
  if isinstance(a,list):
   if len(a)==2 and all(isinstance(x,(int,float)) for x in a):return move(a)
   return [anchors(v) for v in a]
  return a
 if 'anchor_points' in g:g['anchor_points']=anchors(g['anchor_points'])
 g['sculpture_fit_scale']=factor;return g
def main():
 lookup=modules();items=[];seen=set();(ROOT/'geometry').mkdir(exist_ok=True)
 for fi,family in enumerate(FAMILIES):
  for sub in range(10):
   for variant in range(10):
    ident=fi*100+sub*10+variant+1;tier='Volumetric' if variant==9 else 'Preview';seed=27002601+ident*7919
    g=sculpture_fit(lookup[family].build(family,sub,variant,seed));assert g['name']==family
    if tier=='Volumetric':g=inset(g,.94)
    gh=fingerprint(g);assert gh not in seen,('Duplicate geometry',ident);seen.add(gh)
    relative=f'geometry/{ident:04d}.json';write_if_changed(ROOT/relative,json.dumps(g,separators=(',',':'))+'\n')
    prefix=f'ForgePass_V3_{ident:04d}_{family}_{tier}'
    item={'id':ident,'name':f'Forge Pass #{ident:04d}','family':family,'subtype_index':sub,'subtype_name':g['subtype_name'],'variant':variant,'tier':tier,'seed':seed,'palette':palette(family,sub,variant),'geometry_sha256':gh,'geometry_file':relative,'layout':g.get('layout',''),'main_assemblies':g.get('main_assemblies',0),'path_count':len(g['paths']),'facet_count':len(g.get('facets',[])),'png':f'{tier}/{prefix}.png'}
    if tier=='Volumetric':item['gif']=f'{tier}/{prefix}.gif'
    items.append(item)
 manifest={'collection':'Forge Pass','art_direction_version':'V3 sculptural redesign','supersedes_artwork_branch':'forge-pass-1100-collection','edition_size':1100,'tier_counts':{'Preview':990,'Volumetric':110},'family_count':11,'structural_subtype_count':110,'per_family':{'Preview':90,'Volumetric':10},'per_subtype':{'Preview':9,'Volumetric':1},'png_size':[2048,2048],'gif_size':[1000,1000],'gif_fps':20,'volumetric_seconds':12,'artwork_ids_are_not_assigned_onchain_token_ids':True,'items':items}
 write_if_changed(ROOT/'Collection.json',json.dumps(manifest,indent=2)+'\n');print('Built',len(items),'unique V3 compositions',flush=True)
if __name__=='__main__':main()
