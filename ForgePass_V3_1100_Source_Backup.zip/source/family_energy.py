"""Dense, family-specific Lightning, Frost, and Starburst architecture.

Coordinates are centered in a logical 1024px square. Every rail component is
attached to an explicit hub, and every branch begins at a real parent vertex.
"""
from __future__ import annotations
import math, random, json, hashlib
from collections import defaultdict

FAMILIES=('Lightning','Frost','Starburst')
SUBTYPES={
 'Lightning':('Tempest Wheel','Thunder Tree','Twin Storm Fronts','Spiral Discharge','Thunderhead Fan','Crossfire Storm','Storm Vortex','Lightning Cathedral','Triad Tempest','Thunder Wings'),
 'Frost':('Imperial Snowflake','Twin Glacier Crystals','Ice Palace Fan','Prismatic Aurora','Frozen Arbor','Crystal Bastion','Glacier Curtain','Snowflake Rosette','Glacial Compass','Crystal Constellation'),
 'Starburst':('Solar Regalia','Flare Corona','Twin Supernova','Celestial Comet','Astral Mandala','Solar Cross','Triple Suns','Eclipse Radiance','Nebular Fan','Helical Supernova')}

def add(a,b):return [a[0]+b[0],a[1]+b[1]]
def mul(a,s):return [a[0]*s,a[1]*s]
def lerp(a,b,t):return [a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t]
def pol(r,a):
 t=math.radians(a);return [r*math.cos(t),r*math.sin(t)]
def unit(a,b):
 dx=b[0]-a[0];dy=b[1]-a[1];d=math.hypot(dx,dy);return [dx/d,dy/d]
def bez(a,b,c,d,n=13):
 out=[]
 for i in range(n):
  t=i/(n-1);u=1-t;out.append([u**3*a[k]+3*u*u*t*b[k]+3*u*t*t*c[k]+t**3*d[k] for k in (0,1)])
 out[0]=list(a);out[-1]=list(d);return out

class Scene:
 def __init__(self,f,st,v,seed):
  self.f=f;self.st=st;self.v=v;self.rng=random.Random(seed)
  self.g=dict(name=f,subtype_name=SUBTYPES[f][st],description='',layout='',main_assemblies=0,paths=[],tips=[],nodes=[],rings=[],facets=[],anchor_points={})
 def path(self,pts,width=12,color=0,group=0,taper=.5,tip=False):
  p=[[float(q[0]),float(q[1])] for q in pts];p=[q for i,q in enumerate(p) if i==0 or math.dist(q,p[i-1])>1e-8]
  if len(p)<2:raise ValueError('degenerate rail')
  self.g['paths'].append(dict(points=p,width=float(width),color=int(color),group=int(group),taper=float(taper)))
  self.g['anchor_points'].setdefault(str(group),p[0])
  if tip:self.tip(p[-1],max(2.6,min(5.4,width*.3)),2,group)
  return p
 def curve(self,a,b,c,d,width=12,color=0,group=0,taper=.5,tip=False):return self.path(bez(a,b,c,d),width,color,group,taper,tip)
 def tip(self,p,r=3.4,color=2,group=0):self.g['tips'].append(dict(pos=list(p),radius=float(r),color=color,group=group))
 def node(self,p,r=45,style='hub',color=0,group=0):self.g['nodes'].append(dict(pos=list(p),radius=float(r),style=style,color=color,group=group))
 def ring(self,c,r,w=2,segments=1,gap=0,start=0,color=1):self.g['rings'].append(dict(center=list(c),radius=float(r),width=float(w),segments=segments,gap=gap,start=start,color=color))
 def facet(self,pts,color=0,group=0):self.g['facets'].append(dict(points=[list(p) for p in pts],color=color,group=group))
 def diamond(self,p,angle,length=25,width=9,color=2,group=0):
  a=pol(1,angle);n=[-a[1],a[0]]
  self.facet([add(p,mul(a,length*.5)),add(p,mul(n,width)),add(p,mul(a,-length*.5)),add(p,mul(n,-width))],color,group)
 def finish(self,layout,assemblies):
  g=self.g;g['layout']=layout;g['main_assemblies']=assemblies
  g['description']=f"{g['subtype_name']}: substantial connected {self.f.lower()} sculpture, articulated branches, nested ornament, and faceted terminals."
  # Three structural finish plans supplement the subtype's changing arm counts.
  # These are attached local branches and gem/shard settings, not seed noise.
  band=self.v//3
  candidates=[]
  for rail in list(g['paths']):
   if rail['width']<12 or len(rail['points'])<3:continue
   ix=max(1,min(len(rail['points'])-2,len(rail['points'])//2));q=rail['points'][ix]
   if math.hypot(*q)<100:continue
   candidates.append((rail,ix,q))
  limit=(0,6,11,8)[band]
  for j,(rail,ix,q) in enumerate(candidates[::max(1,len(candidates)//max(1,limit))][:limit]):
   a=unit(rail['points'][ix-1],rail['points'][ix+1]);normal=[-a[1],a[0]]
   reach=26+(j%3)*6;group=rail['group']
   for hand in (-1,1):
    knee=add(q,add(mul(a,reach*.3),mul(normal,hand*reach*.6)))
    end=add(q,add(mul(a,reach*.95),mul(normal,hand*reach)))
    child=self.path([q,knee,end],4.7 if band==1 else 5.8,1,group,.38,True)
    if band==2:self.path([knee,add(knee,add(mul(a,reach*.45),mul(normal,-hand*reach*.4)))],2.7,2,group,.35,True)
   if self.f=='Frost':self.diamond(q,math.degrees(math.atan2(a[1],a[0])),28,8.5,2,group)
   else:self.node(q,7.3+(j%2)*2,'junction',2,group)
  sx,sy=[(1,1),(1.05,.98),(.98,1.04),(.96,1.07),(1.08,.96),(.98,1.1),(1.10,.93),(.95,1.08),(1.1,1.0),(1.02,1.03)][self.v]
  for rec in g['paths']+g['facets']:rec['points']=[[x*sx,y*sy] for x,y in rec['points']]
  for rec in g['nodes']+g['tips']:rec['pos']=[rec['pos'][0]*sx,rec['pos'][1]*sy]
  for key,p in g['anchor_points'].items():g['anchor_points'][key]=[p[0]*sx,p[1]*sy]
  for rec in g['rings']:rec['center']=[rec['center'][0]*sx,rec['center'][1]*sy]
  extent=1
  for p in g['paths']:extent=max(extent,max(max(map(abs,q)) for q in p['points'])+p['width']*.55+7)
  for p in g['nodes']+g['tips']:extent=max(extent,max(map(abs,p['pos']))+p['radius']+7)
  for p in g['facets']:extent=max(extent,max(max(map(abs,q)) for q in p['points'])+5)
  # Decorative halos never cause otherwise substantial sculpture to shrink.
  factor=min(1.,450/extent)
  for rec in g['paths']+g['facets']:
   rec['points']=[[x*factor,y*factor] for x,y in rec['points']]
   if 'width' in rec:rec['width']*=factor
  for rec in g['nodes']+g['tips']:rec['pos']=[x*factor for x in rec['pos']];rec['radius']*=factor
  for key,p in g['anchor_points'].items():g['anchor_points'][key]=[x*factor for x in p]
  for r in g['rings']:
   r['center']=[x*factor for x in r['center']];r['radius']*=factor;r['width']*=factor
   room=455-max(map(abs,r['center']))-r['width']-4;r['radius']=min(r['radius'],max(12,room))
  return g

# Six vertices give parent channels four exact fork attachment points.
def bolt(s,root,end,width,group,forks=4,intensity=1.,color=0):
 axis=unit(root,end);norm=[-axis[1],axis[0]];length=math.dist(root,end)
 pts=[list(root)]
 for j,t in enumerate((.19,.37,.56,.76)):
  q=lerp(root,end,t);amp=min(36,length*.12)*intensity*(1 if j%2 else -1)
  pts.append(add(q,mul(norm,amp)))
 pts.append(list(end));spine=s.path(pts,width,color,group,.38,True)
 for k,q in enumerate(spine[1:-1]):
  if k>=forks:break
  remaining=1-(k+1)/6;span=min(106,length*.39)*remaining*intensity
  for hand in (-1,1):
   reach=span*(.72+.12*((group+k+s.v)%3))
   e=add(q,add(mul(axis,span*.62),mul(norm,hand*reach)))
   knee=add(q,add(mul(axis,span*.25),mul(norm,hand*reach*.55)))
   fork=s.path([q,knee,add(knee,mul(axis,-span*.13)),e],max(4.3,width*.45-k*.48),1 if hand<0 else color,group,.35,True)
   if (k+group+s.v)%2==0:
    at=fork[1];e2=add(at,add(mul(axis,span*.44),mul(norm,-hand*span*.34)))
    s.path([at,add(at,mul(norm,-hand*span*.18)),e2],3.2,2,group,.4,True)
   if k==1 and (group+s.v)%3==0:s.node(knee,7.7,'junction',2,group)
 return spine

# Straight hexagonal ice fork grammar is deliberately different from lightning.
def ice(s,root,end,width,group,pairs=4,span=66,color=0):
 a=unit(root,end);n=[-a[1],a[0]];length=math.dist(root,end)
 fractions=([.26,.43,.60,.77] if pairs>=4 else [.31,.53,.74])
 if pairs>=5:fractions=[.23,.36,.49,.63,.77]
 points=[list(root)]+[lerp(root,end,t) for t in fractions]+[list(end)]
 # Broad faceted ice blade body under the raised rail; visible even at 200px.
 shoulder=lerp(root,end,.53);blade=max(9.,width*1.02)
 s.facet([lerp(root,end,.13),add(shoulder,mul(n,blade)),end,add(shoulder,mul(n,-blade))],1,group)
 s.path(points,width,color,group,.4,True)
 for j,q in enumerate(points[1:-1]):
  lateral=min(span,length*.3)*(1-j*.12)
  forward=lateral*.62
  for hand in (-1,1):
   e=add(q,add(mul(a,forward),mul(n,hand*lateral)))
   knee=add(q,add(mul(a,forward*.45),mul(n,hand*lateral*.55)))
   f=s.path([q,knee,e],max(4.1,width*.45-j*.32),1 if j%2 else color,group,.38,True)
   if j%2==0:
    q2=f[1];e2=add(q2,add(mul(a,lateral*.50),mul(n,-hand*lateral*.25)))
    s.path([q2,e2],2.8,2,group,.4,True)
    e3=add(q2,add(mul(a,lateral*.28),mul(n,hand*lateral*.33)))
    s.path([q2,e3],3.2,0,group,.35,True)
    s.diamond(q2,math.degrees(math.atan2(a[1],a[0]))+hand*34,26,6.1,1,group)
  if j in (0,2):s.diamond(q,math.degrees(math.atan2(a[1],a[0])),20,5.6,1,group)
 s.diamond(end,math.degrees(math.atan2(a[1],a[0])),25,8,2,group)
 return points

def ice_bracing(s,center,spines,radius,groupbase=60,outer=True):
 """Star-shaped crystal buttresses attach to existing arm vertices at both ends."""
 count=len(spines)
 for i,spine in enumerate(spines):
  next_spine=spines[(i+1)%count]
  for tier in range(2 if outer else 1):
   ix=2 if tier==0 else len(spine)-2
   q=spine[ix];nq=next_spine[min(ix,len(next_spine)-2)]
   direction=unit(center,lerp(q,nq,.5));rr=radius*(.59 if tier==0 else .88)
   corner=add(center,mul(direction,rr));group=groupbase+i
   s.path([q,lerp(q,corner,.48),corner,lerp(corner,nq,.52),nq],9.4 if tier==0 else 7.4,1,group,.85)
   inward=add(center,mul(direction,rr-(28 if tier==0 else 21)))
   s.facet([q,corner,nq,inward],1 if tier==0 else 0,group)
   s.diamond(corner,math.degrees(math.atan2(direction[1],direction[0])),33,9,2,group)

def sunray(s,root,end,width,group,v,bladed=True):
 a=unit(root,end);n=[-a[1],a[0]];length=math.dist(root,end)
 pts=[list(root),lerp(root,end,.28),lerp(root,end,.55),lerp(root,end,.79),list(end)]
 s.path(pts,width,0 if group%3 else 1,group,.28,True)
 if bladed:
  # A split taper inlay makes each ray a solid sculpted spike, not a wire.
  q=pts[1];b=pts[3];half=max(4,min(11,width*.75))
  s.facet([q,add(b,mul(n,half)),end,add(b,mul(n,-half))],2 if group%3==0 else 0,group)
 for j,q in enumerate(pts[1:-1]):
  span=min(42,length*.18)*(1-j*.15)
  for hand in (-1,1):
   if j==2 and (group+v)%2:continue
   e=add(q,add(mul(a,span*.78),mul(n,hand*span)))
   f=s.path([q,add(q,add(mul(a,span*.15),mul(n,hand*span*.57))),e],max(3.1,width*.38-j*.4),1 if hand<0 else 2,group,.33,True)
   if j==0 and (group+v)%3==0:
    q2=f[1];e2=add(q2,add(mul(a,span*.50),mul(n,-hand*span*.35)))
    s.path([q2,e2],2.5,2,group,.3,True)
 if group%3==0:s.node(pts[2],6.8,'junction',1,group)
 return pts


def solar_spark(s,root,end,group,width=5.7):
 a=unit(root,end);n=[-a[1],a[0]];q=lerp(root,end,.55)
 s.path([root,q,end],width,1,group,.28,True)
 s.facet([root,add(q,mul(n,width)),end,add(q,mul(n,-width))],0,group)
 for hand in (-1,1):s.path([q,add(q,add(mul(a,13),mul(n,hand*12)))],2.7,2,group,.3,True)

def _lightning(st,v,seed):
 s=Scene('Lightning',st,v,seed);n=[7,9,11,8,10,12,8,10,12,10][v];forks=4
 if st in (0,5,6):
  core=[0,0];s.node(core,61,color=0)
  count=n if st!=5 else 8+(v%3)*2
  for i in range(count):
   angle=-90+i*360/count+(11 if st==6 else 0)
   radius=387+(20 if (i+v)%2 else -10)
   if st==5:radius*=1.0 if i%2==0 else .77
   end=add(core,pol(radius,angle));bolt(s,core,end,21 if i%2==0 else 15,i,4,1.03,0)
  if st==6:
   # Each storm arm curls into a neighboring arc of forked lightning.
   for i in range(6):
    angle=-90+i*60;q=pol(224,angle);s.path([core,q],8,1,100+i,.65)
    bolt(s,q,pol(360,angle+36),8,100+i,2,.56,1)
  s.ring(core,424,2.8,6,18,-84,1)
  return s.finish('radial jagged storm wheel' if st==0 else 'radial crossfire vortex',count)
 if st in (1,7):
  core=[0,315];tiers=4+(v%3)
  joints=[[(-1 if j%2 else 1)*28,209-j*443/(tiers-1)] for j in range(tiers)]
  trunk=s.path([core]+joints+[[0,-373]],29,0,0,.5,True);s.node(core,53)
  for j in range(1,len(trunk)-1):
   q=trunk[j]
   for hand in (-1,1):
    reach=365-(j-1)*20 if st==1 else 310+(j%2)*48
    end=[hand*reach,q[1]-110-(v%3)*14]
    bolt(s,q,end,19-j*1.1,2*j+(hand==1),4,.9,0)
  if st==7:
   for side in (-1,1):
    q=trunk[2];bolt(s,q,[side*220,360],13,30+(side==1),4,.65,1)
  s.ring([0,0],424,2.3,2,73,-31,1)
  return s.finish('upright branching lightning cathedral',9)
 if st==2:
  centers=[[-188,12],[188,12]]
  s.path([centers[0],[-65,-34],[44,32],centers[1]],23,1,0,.8)
  for side,c in enumerate(centers):
   s.node(c,49,color=side)
   for i in range(5+(v%3)):
    angle=(-160+140*i/(4+v%3)) if side==0 else (-20+140*i/(4+v%3))
    # The outer fans include both upward and downward jagged discharges.
    angle=(-100+200*i/(4+v%3))+(180 if side==0 else 0)
    extension=pol(337+(i%2)*13,angle)
    bolt(s,c,add(c,[extension[0]*.73,extension[1]]),18,side*10+i,4,.92,side)
  s.ring([0,0],427,2.4,4,38,4,1)
  return s.finish('twin storm fronts connected by a broken energy bridge',12)
 if st==3:
  core=[0,0];s.node(core,62)
  for arm in range(3+(v%3)):
   points=[core]
   for j in range(1,7):points.append(pol(60+j*49,-90+arm*360/(3+v%3)+j*31))
   s.path(points,22,arm%2,arm,.48,True)
   for j,q in enumerate(points[1:-1]):
    a=-90+arm*360/(3+v%3)+(j+1)*31+60
    bolt(s,q,add(q,pol(99+(j%2)*25,a)),8.3,arm,3,.62,1)
  s.ring(core,427,2.5,3,33,-80,1)
  return s.finish('radial spiral branching discharge',4)
 if st==4:
  core=[0,294];s.node(core,59)
  count=9+(v%3)*2
  for i in range(count):
   angle=-161+142*i/(count-1);radius=510-120*abs(i/(count-1)-.5)*2
   e=add(core,pol(radius,angle));bolt(s,core,e,21-i%3*2,i,4,.95,0)
  # Lower roots keep the fan sculptural rather than a sparse comb.
  for i in range(4):bolt(s,core,[-220+i*145,401],11,40+i,2,.5,1)
  return s.finish('upright thunderhead branching fan',count)
 if st==8:
  centers=[pol(210,-90+i*120) for i in range(3)]
  edge_centers=[lerp(centers[i],centers[(i+1)%3],.5) for i in range(3)]
  triangle=[]
  for i,c in enumerate(centers):triangle.extend([c,edge_centers[i]])
  s.path(triangle+[centers[0]],20,1,0,.8)
  for i,c in enumerate(centers):
   s.node(c,45,color=i%2)
   for j in range(5+(v%3)):
    angle=-90+i*120-85+j*170/(4+v%3)
    bolt(s,c,add(c,pol(210,angle)),15,i*10+j,4,.73,i%2)
  heart=[0,0];s.node(heart,52,color=0)
  for i,c in enumerate(centers):bolt(s,heart,c,19,70+i,4,.95,0)
  # The heart feeds the mid-edge storm channels as well as the three outer
  # cores. This fills the triangle with an attached six-channel discharge
  # instead of leaving three small bursts around a bare geometric frame.
  for i,q in enumerate(edge_centers):
   channel=bolt(s,heart,q,15,80+i,3,.94,1)
   s.node(q,11,'junction',2,80+i)
   for hand in (-1,1):
    at=channel[2 if hand<0 else 3]
    axis=unit(heart,q);normal=[-axis[1],axis[0]]
    end=add(at,add(mul(axis,27),mul(normal,hand*(43+(v%3)*6))))
    bolt(s,at,end,7.5,90+i,2,.72,0)
  return s.finish('triangular storm cores with branching outer discharges',3)
 # st9: a single large hub supports two fully articulated storm wings.
 core=[0,27];s.node(core,62)
 for side in (-1,1):
  for j in range(6+(v%3)):
   y=-345+j*690/(5+v%3);end=[side*(345+41*math.sin(j)),y]
   bolt(s,core,end,20-j%3*2,10*(side==1)+j,4,.88,0)
 s.ring(core,426,2.4,2,74,-58,1)
 return s.finish('horizontal full branching thunder wings',14)


def _frost(st,v,seed):
 s=Scene('Frost',st,v,seed);mode=v%3
 if st in (0,3,7,8):
  core=[0,0];s.node(core,60,color=0)
  count={0:6,3:12,7:6,8:8}[st]
  crystal_spines=[]
  for i in range(count):
   angle=-90+i*360/count+(15 if st==3 else 0);r=389 if st!=8 or i%2==0 else 310
   crystal_spines.append(ice(s,core,pol(r,angle),23 if i%2==0 else 18,i,3+mode,106 if count==6 else 63,i%2))
  ice_bracing(s,core,crystal_spines,390,60,True)
  if st==7:
   for i in range(6):
    q=pol(184,-60+i*60);s.path([core,q],10,1,40+i,.7);s.node(q,18,'junction',2,40+i)
    ice(s,q,pol(359,-60+i*60),11,40+i,3,46,1)
  if st==3:
   for i in range(12):
    a=-90+i*30;p=pol(224,a);s.diamond(p,a,69,15,1 if i%2 else 2,i)
  for radius,segments,gap in [(431,6,29),(314,6,43)]:s.ring(core,radius,1.8,segments,gap,-84,1)
  return s.finish('radial sixfold faceted ice crystal' if count==6 else 'radial prismatic crystalline compass',count)
 if st==1:
  centers=[[-177,0],[177,0]];s.path([centers[0],centers[1]],20,1,0,.85)
  for side,c in enumerate(centers):
   s.node(c,44,color=side)
   spines=[]
   for i in range(6):
    a=-90+i*60;radius=237 if i%3 else 333
    e=add(c,pol(radius,a));spines.append(ice(s,c,e,17,side*10+i,3+mode,67,side))
   ice_bracing(s,c,spines,250,60+side*10,False)
  s.ring([0,0],429,1.8,6,35,-85,1)
  return s.finish('twin full crystalline snowflakes joined by an ice bridge',12)
 if st==2:
  core=[0,290];s.node(core,59)
  count=(9,11,13)[mode]
  for i in range(count):
   t=i/(count-1);end=[-368+736*t,-248-135*math.sin(math.pi*t)]
   ice(s,core,end,22-i%3*2,i,4,65,0)
  return s.finish('upright palace fan of branching ice blades',count)
 if st==5:
  core=[0,303];s.node(core,59)
  count=3+mode;roots=[[-263+526*i/(count-1),134+31*abs(-263+526*i/(count-1))/263] for i in range(count)]
  s.path([core]+roots,22,1,0,.8);s.path([core,roots[-1]],25,0,1,.8)
  pillars=[]
  for i,q in enumerate(roots):
   end=[q[0],-372+abs(q[0])*.35]
   pillars.append(ice(s,q,end,32-i%2*3,10+i,4+mode,101,0));s.node(q,30,'junction',1,10+i)
  for i in range(count-1):
   left,right=pillars[i],pillars[i+1]
   # Interlocking icy diamonds and oblique needle branches occupy the large
   # bays between towers, while every buttress joins exact pillar vertices.
   for tier,ix in enumerate((1,3,len(left)-2)):
    a=left[ix];b=right[min(ix,len(right)-2)];middle=lerp(a,b,.5)
    rise=69 if tier%2==0 else 46
    peak=add(middle,[0,-rise]);foot=add(middle,[0,rise*.75])
    group=30+i*4+tier
    s.path([a,peak,b,foot,a],12.5-tier,1,group,.9)
    s.path([peak,middle,foot],10,0,group,.65)
    s.facet([a,peak,b,middle],1,group)
    s.diamond(peak,-90,40,12,2,group)
    for hand,anchor in [(-1,a),(1,b)]:
     ice(s,anchor,add(anchor,[hand*49,-67]),9,group,3,27,1)
  for side in (-1,1):ice(s,core,[side*328,357],14,40+(side==1),3,58,1)
  return s.finish('upright multi-tower crystalline bastion',count)
 if st==4:
  core=[0,320];levels=3+mode;joints=[[0,197-j*394/(levels-1)] for j in range(levels)]
  spine=s.path([core]+joints+[[0,-365]],27,0,0,.5,True);s.node(core,57)
  for j,q in enumerate(spine[1:-1]):
   for side in (-1,1):
    end=[side*(358-j*20),q[1]-157]
    ice(s,q,end,max(12,18-j),2*j+(side==1),3+mode,68,0)
  ice(s,core,[0,-365],21,20,5,108,1)
  for side in (-1,1):ice(s,core,[side*275,349],12,30+(side==1),3,46,1)
  s.ring([0,0],428,1.8,6,29,-83,1)
  return s.finish('upright branching frozen arbor with crystal roots',9)
 if st==6:
  core=[0,-292];s.node(core,55)
  count=(7,9,11)[mode];roots=[[-340+680*i/(count-1),-235+58*abs(i/(count-1)-.5)*2] for i in range(count)]
  center=min(range(count),key=lambda i:abs(roots[i][0]))
  s.path([core]+roots[center::-1],15,1,0,.8);s.path([core]+roots[center:],15,1,1,.8)
  spines=[]
  for i,q in enumerate(roots):
   # Broad, staggered icicle bodies carry clustered needle fans; they remain
   # clearly crystalline rather than seven unarticulated hanging wires.
   end=[q[0]+(24 if i%2 else -24),330+34*(i%2)]
   spines.append(ice(s,q,end,24-i%3*2,i+2,5,66,0))
  for i in range(count-1):
   left,right=spines[i],spines[i+1]
   for tier,ix in enumerate((2,4)):
    a=left[ix];b=right[ix];middle=lerp(a,b,.5)
    peak=add(middle,[0,-37]);foot=add(middle,[0,48]);group=60+i*2+tier
    s.path([a,peak,b,foot,a],8.5,1,group,.88)
    s.facet([a,peak,b,middle],1,group)
    s.path([peak,middle,foot],6.2,0,group,.65)
    s.diamond(foot,90,30,9,2,group)
   for ix in (1,3):
    anchor=left[ix]
    ice(s,anchor,add(anchor,[38,-52]),6.8,85+i,3,22,2)
  return s.finish('vertical glacier curtain of faceted branching icicles',count)
 # st9: large triangular crystalline constellation, all three stars fill space.
 centers=[[-189,141],[189,141],[0,-190]];s.path(centers+[centers[0]],17,1,0,.85)
 s.node([0,0],41);s.path([[0,0],centers[2]],17,1,70,.8)
 for k,c in enumerate(centers):
  s.node(c,40,color=k%2)
  if k<2:ice(s,[0,0],c,16,71+k,3,55,1)
  spines=[]
  for i in range(6):
   a=-90+i*60;spines.append(ice(s,c,add(c,pol(210,a)),16,k*10+i,3+mode,55,0))
  ice_bracing(s,c,spines,210,80+k*10,False)
 return s.finish('triangular full crystal constellation',18)


def _sun(s,c,rays,radius,groupbase=0,ell=(1.,1.),phase=-90,width=14):
 s.node(c,63 if radius>300 else 44,color=0,group=groupbase)
 for i in range(rays):
  angle=phase+i*360/rays;r=radius*(1 if i%2==0 else .79)
  d=pol(r,angle);e=add(c,[d[0]*ell[0],d[1]*ell[1]])
  sunray(s,c,e,width+(3 if i%2==0 else -2),groupbase+i,s.v,True)
 # Layered solar shell and diamond plasma rim are anchored to the core by rays.
 shell=min(129,radius*.36)
 s.ring(c,shell,6,1,0,0,0);s.ring(c,shell*.78,2.3,12,12,-83,2)
 for i in range(12):
  a=-90+i*30;p=add(c,pol(shell,a));s.diamond(p,a,23,6.8,2,groupbase+i%rays)


def _starburst(st,v,seed):
 s=Scene('Starburst',st,v,seed);mode=v%3;n=(18,22,26)[mode]
 if st==1:
  core=[0,51];_sun(s,core,18+mode*2,294,0,(1.12,.95),-90,16)
  for i in range(10+mode*2):
   a=-167+154*i/(9+mode*2);r=470-83*abs(i/(9+mode*2)-.5)*2
   end=add(core,pol(r,a));q=add(core,pol(105,a))
   s.path([core,q],14,0,60+i,.8)
   curve=s.curve(q,add(core,pol(238,a+19)),add(core,pol(r*.78,a+12)),end,14.5,0 if i%2 else 1,60+i,.28,True)
   for j in (4,8):
    at=curve[j];solar_spark(s,at,add(at,pol(56,a-36)),60+i,5.9)
  return s.finish('upright flaring solar corona with long upper plasma feathers',10)
 if st==7:
  core=[-105,0];_sun(s,core,18+mode*2,297,0,(1.,1.1),-90,15)
  for i in range(11+mode*2):
   a=-81+162*i/(10+mode*2);radius=496-67*abs(i/(10+mode*2)-.5)*2
   end=add(core,pol(radius,a));q=add(core,pol(107,a))
   s.path([core,q],12,1,60+i,.8)
   arc=s.curve(q,add(core,pol(239,a-17)),add(core,pol(radius*.79,a-12)),end,12.5,0,60+i,.25,True)
   for j in (4,8):solar_spark(s,arc[j],add(arc[j],pol(51,a+37)),60+i,5.8)
  return s.finish('asymmetric eclipse sun with a broad rightward corona',12)
 if st==9:
  core=[0,0];_sun(s,core,12,148,0,(1,1),-90,15)
  arms=3+mode
  for arm in range(arms):
   points=[core]+[pol(82+j*57,-90+arm*360/arms+j*26) for j in range(1,7)]
   s.path(points,25-mode*2,0,40+arm,.40,True)
   for j,q in enumerate(points[1:-1]):
    a=-90+arm*360/arms+(j+1)*26+41
    end=add(q,pol(93+(j%2)*18,a));sunray(s,q,end,11.8,40+arm,v,True)
    if j%2==0:sunray(s,q,add(q,pol(68,a-96)),8.7,50+arm,v,True)
   s.node(points[3],17,'junction',2,40+arm)
  return s.finish('radial helical supernova with branched solar blades',arms)
 if st in (0,4,5):
  core=[0,0]
  if st==5:n=20+mode*4
  _sun(s,core,n,299 if st==5 else 394,0,(1,1),-90+(7 if st==4 else 0),16 if st in (0,5) else 14)
  if st==4:
   for i in range(8+mode*2):
    a=-90+i*360/(8+mode*2)
    # Between major rays, substantial flares establish a second corona layer.
    q=pol(127,a);s.path([core,q],7,1,100+i,.8)
    e=pol(366,a+10)
    pts=s.curve(q,pol(240,a+25),pol(319,a+19),e,8.3,1,100+i,.35,True)
    for ix in (4,8):
     q2=pts[ix];s.path([q2,add(q2,pol(32,a-45))],3.1,2,100+i,.35,True)
  if st==5:
   for i in range(4):
    a=-90+i*90;s.path([core,pol(236,a),pol(424,a)],25,0,70+i,.3,True)
    s.diamond(pol(298,a),a,87,16,2,70+i)
  if st==4:
   for i in range(8):
    a=-90+i*45;p=pol(228,a);s.path([core,p],9,1,80+i,.7);s.node(p,19,'junction',2,80+i)
  s.ring(core,431,2.5,12,9,-84,1)
  if st==4:s.ring(core,338,2.1,8,21,-81,2)
  return s.finish('radial ornate solar corona',n)
 if st==2:
  centers=[[-186,-24],[186,24]];s.path(centers,22,0,0,.8)
  for i,c in enumerate(centers):_sun(s,c,14+mode*2,231,30*i,(1.,1.43),-90,12)
  return s.finish('horizontal twin supernova with full solar coronas',2)
 if st==3:
  c=[154,-136];_sun(s,c,16+mode*2,247,0,(1,1),-90,14)
  for i in range(11+mode*2):
   t=i/(10+mode*2);end=[-399+297*t,22+380*t]
   pts=s.curve(c,[-162+210*t,-112+93*t],[-308+281*t,103+182*t],end,15-i%3*2,0 if i%2 else 1,60+i,.28,True)
   for j in (5,8,10):
    q=pts[j];a=150+30*i/(8+mode*2)
    s.path([q,add(q,pol(47,a-45)),add(q,pol(77,a))],4.5,2,60+i,.35,True)
  return s.finish('diagonal comet sun with a broad branching stellar tail',10)
 if st==6:
  centers=[pol(199,-90+120*i) for i in range(3)];s.path(centers+[centers[0]],19,1,0,.85)
  for k,c in enumerate(centers):_sun(s,c,12+mode*2,214,40*k,(1,1),-90+k*15,11.5)
  return s.finish('triangular three full solar coronas',3)
 # st8: a broad nebular fan still reads as a sun through its large shell/core.
 c=[0,230];s.node(c,70)
 count=19+mode*4
 for i in range(count):
  a=-173+166*i/(count-1);end=add(c,pol(530-91*abs(i/(count-1)-.5)*2,a))
  sunray(s,c,end,15-i%3*1.3,i,v,True)
 for i in range(6):sunray(s,c,[(-1 if i<3 else 1)*(92+(i%3)*72),397],10,60+i,v,True)
 s.ring(c,119,5.8,1,0,0,0);s.ring([0,0],428,2.2,7,18,-80,1)
 return s.finish('upright full nebular solar fan',count)


def build(family,subtype,variant,seed):
 if family not in FAMILIES:raise ValueError(family)
 if not 0<=subtype<10 or not 0<=variant<10:raise ValueError('subtype and variant must be 0..9')
 return {'Lightning':_lightning,'Frost':_frost,'Starburst':_starburst}[family](subtype,variant,seed)


def _validate(g):
 adj=defaultdict(set)
 for rec in g['paths']:
  pts=[tuple(p) for p in rec['points']]
  assert rec['width']>0
  for a,b in zip(pts,pts[1:]):
   assert math.dist(a,b)>1e-8
   adj[a].add(b);adj[b].add(a)
  for p in pts:assert all(math.isfinite(v) for v in p) and max(map(abs,p))<461
 hubs=[n for n in g['nodes'] if n['style']=='hub'];remaining=set(adj)
 while remaining:
  seen={next(iter(remaining))};q=list(seen)
  while q:
   for p in adj[q.pop()]:
    if p not in seen:seen.add(p);q.append(p)
  remaining-=seen
  assert any(math.dist(p,n['pos'])<n['radius']+1 for p in seen for n in hubs),'unanchored component'
 for tip in g['tips']:assert tuple(tip['pos']) in adj,'detached terminal'
 for n in g['nodes']+g['tips']:assert max(map(abs,n['pos']))+n['radius']<461
 for p in g['paths']:assert max(max(map(abs,q)) for q in p['points'])+p['width']*.55<461
 for r in g['rings']:assert max(map(abs,r['center']))+r['radius']+r['width']<461


def selftest():
 hashes=set();summary={}
 for fi,f in enumerate(FAMILIES):
  counts=[]
  for st in range(10):
   for v in range(10):
    g=build(f,st,v,850199+(fi*100+st*10+v+1)*7919);_validate(g)
    fingerprint=hashlib.sha256(json.dumps({k:g[k] for k in ('paths','tips','nodes','rings','facets')},sort_keys=True).encode()).hexdigest()
    assert fingerprint not in hashes,(f,st,v,'duplicate');hashes.add(fingerprint);counts.append(len(g['paths']))
  summary[f]={'count':100,'paths_min':min(counts),'paths_max':max(counts)}
 return summary

if __name__=='__main__':print(json.dumps(selftest(),indent=2))
