"""Forge Pass organic edition: rich sea fans, exposed roots and leafy bonsai.

Geometry is deliberately built as connected sculptures.  Every secondary fork
starts at a stored vertex of its parent.  All ten architectures and every
Preview variation have substantial primary forms and developed branch crowns.
"""
from __future__ import annotations
import hashlib
import json
import math
import random

FAMILIES = ("Coral", "Roots", "Bonsai")
SUBTYPES = {
    "Coral": ("Gorgonian Cathedral", "Twin Reef Thrones", "Anemone Rosette",
              "Reef Arch", "Three Reef Crowns", "Coral Pillars", "Hanging Reef",
              "Crescent Colony", "Coral Bowl", "Living Reef Bridge"),
    "Roots": ("Ancient Root Citadel", "Twin Root Gates", "Root Fan Sanctuary",
              "Braided Root Throne", "Mangrove Vault", "Root Terraces",
              "Crescent Rootwood", "Root Wings", "Three Source Confluence",
              "Root Labyrinth"),
    "Bonsai": ("Imperial Canopy", "Twin Trunk Grove", "Windswept Crown",
               "Cascade Bonsai", "Umbrella Pavilion", "Seven Tier Pagoda",
               "Living Arch", "Three Tree Forest", "Literati Spiral",
               "Root Over Rock"),
}

def add(a,b): return [a[0]+b[0],a[1]+b[1]]
def mul(a,k): return [a[0]*k,a[1]*k]
def clamp(p, margin=410): return [max(-margin,min(margin,p[0])),max(-margin,min(margin,p[1]))]
def polar(r,a):
    t=math.radians(a)
    return [r*math.cos(t),r*math.sin(t)]
def unit(a,b):
    d=[b[0]-a[0],b[1]-a[1]];m=math.hypot(*d)
    return [d[0]/m,d[1]/m]
def bez(a,b,c,e,n=13):
    out=[]
    for i in range(n):
        t=i/(n-1);u=1-t
        out.append([u**3*a[k]+3*u*u*t*b[k]+3*u*t*t*c[k]+t**3*e[k] for k in (0,1)])
    out[0]=list(a);out[-1]=list(e)
    return out

class Scene:
    def __init__(self,family,st,v,seed):
        self.family=family;self.st=st;self.v=v;self.rng=random.Random(seed)
        self.mode=v%3;self.band=min(2,v//3)
        self.s=dict(name=family,subtype_name=SUBTYPES[family][st],description="",
                    layout="",main_assemblies=0,paths=[],tips=[],nodes=[],rings=[],
                    facets=[],anchor_points={},variant=v)
    def path(self,ps,w=10,color=0,group=0,taper=.55,tip=False,r=3.6):
        out=[[float(x),float(y)] for x,y in ps]
        out=[p for i,p in enumerate(out) if not i or math.dist(p,out[i-1])>1e-8]
        assert len(out)>=2
        self.s['paths'].append(dict(points=out,width=float(w),color=color,group=group,taper=taper))
        if tip:self.tip(out[-1],r,color if color==2 else 2,group)
        return out
    def curve(self,a,b,c,e,w=10,color=0,group=0,taper=.55,tip=False,r=3.6,n=13):
        return self.path(bez(a,clamp(b),clamp(c),e,n),w,color,group,taper,tip,r)
    def tip(self,p,r=3.6,color=2,group=0):
        self.s['tips'].append(dict(pos=list(p),radius=float(r),color=color,group=group))
    def node(self,p,r=32,style='hub',color=0,group=0):
        self.s['nodes'].append(dict(pos=list(p),radius=float(r),style=style,color=color,group=group))
    def ring(self,c,r,w=2,segments=2,gap=65,start=25,color=1):
        self.s['rings'].append(dict(center=list(c),radius=float(r),width=float(w),
                                    segments=segments,gap=float(gap),start=float(start),color=color))
    def leaf(self,p,angle,length=25,width=13,color=1,group=0):
        a=polar(1,angle);n=[-a[1],a[0]]
        def q(f,s):return add(p,add(mul(a,length*f),mul(n,width*s)))
        shape=[p,q(.28,.70),q(.63,.80),q(1,0),q(.63,-.80),q(.28,-.70)]
        self.s['facets'].append(dict(points=shape,color=color,group=group,kind='leaf'))
    def canopy(self,p,halfwidth=76,height=29,group=0,hand=1):
        """A broad jade foliage pad, visibly supported by its woody bough."""
        width=halfwidth
        cx=max(-420+width,min(420-width,p[0]+hand*12))
        cy=p[1]-height*.66
        shape=[]
        for i in range(24):
            a=2*math.pi*i/24
            ripple=1+.08*math.sin(5*a+.47*group)
            shape.append([cx+width*math.cos(a)*(1+.035*math.sin(3*a)),
                          cy+height*math.sin(a)*ripple])
        self.s['facets'].append(dict(points=shape,color=1,group=group,kind='canopy'))
    def knot(self,p,color=2,group=0,r=7):
        self.node(p,r,'orb',color,group)
    def finish(self,layout,assemblies):
        self.s['layout']=layout;self.s['main_assemblies']=assemblies
        self.s['description']=(f"Dense {self.family.lower()} sculpture with purposeful hierarchy, "
                               "developed secondary and tertiary growth, connected terminals and dimensional surfaces.")
        # Separate silhouette axes accompany discrete primary/secondary counts.
        sx,sy,lean=[(1.,1.,0),(1.055,.94,-.035),(.93,1.06,.025),
                    (1.02,1.,.065),(.97,1.03,-.07),(.94,1.06,.045),
                    (1.06,.94,.018),(.94,1.06,-.05),(1.,1.02,.035),(1.,1.,0)][self.v]
        if self.family=='Bonsai' and self.st in (2,3,4,5,6,8):
            # Three clearly different silhouette plans accompany the primary
            # bough-count axis. Every plan keeps developed jade canopy masses.
            sx,sy,lean=[(.90,1.10,0),(1.22,.80,.01),(1.03,1.02,.22)][self.band]
        def move(p):return [p[0]*sx+p[1]*lean,p[1]*sy]
        for rec in self.s['paths']+self.s['facets']:rec['points']=[move(p) for p in rec['points']]
        for rec in self.s['tips']+self.s['nodes']:rec['pos']=move(rec['pos'])
        for rec in self.s['rings']:rec['center']=move(rec['center'])
        extent=1.
        for rec in self.s['paths']:
            extent=max(extent,*(max(map(abs,p))+rec['width']*.6+7 for p in rec['points']))
        for rec in self.s['facets']:extent=max(extent,*(max(map(abs,p))+5 for p in rec['points']))
        for rec in self.s['nodes']+self.s['tips']:extent=max(extent,max(map(abs,rec['pos']))+rec['radius']+7)
        for rec in self.s['rings']:extent=max(extent,max(map(abs,rec['center']))+rec['radius']+rec['width']+7)
        f=min(1.,451/extent)
        if f<1:
            for rec in self.s['paths']+self.s['facets']:
                rec['points']=[[x*f,y*f] for x,y in rec['points']]
                if 'width' in rec:rec['width']*=f
            for rec in self.s['tips']+self.s['nodes']:
                rec['pos']=[p*f for p in rec['pos']];rec['radius']*=f
            for rec in self.s['rings']:
                rec['center']=[p*f for p in rec['center']];rec['radius']*=f;rec['width']*=f
        hubs=[n['pos'] for n in self.s['nodes'] if n['style']=='hub']
        for rec in self.s['paths']:
            group=str(rec['group'])
            self.s['anchor_points'].setdefault(group,list(min(hubs,key=lambda h:math.dist(h,rec['points'][0]))))
        return self.s

def coral_frond(d,root,end,group,width=23,bend=0,levels=3):
    """A broad fleshy coral frond, bifurcating into polyp-bearing branches."""
    dx=end[0]-root[0];dy=end[1]-root[1]
    stem=d.curve(root,[root[0]+dx*.22+bend,root[1]+dy*.25],
                 [root[0]+dx*.73-bend*.35,root[1]+dy*.75],end,width,0,group,.48,True,5.4)
    indexes=(3+group%2,6+(group+d.v)%2,9+(group%3==1)) if levels==3 else (3,5,8,10)
    for level,ix in enumerate(indexes):
        q=stem[ix];t=unit(stem[ix-1],stem[ix+1]);n=[-t[1],t[0]]
        span=(103-13*level)*(1+.08*(d.mode-1))*(.88+.08*((group+level+d.band)%4))
        for side in (-1,1):
            side_span=span*(1.12 if (group+level)%2==(side==1) else .82)
            e=clamp(add(q,add(mul(t,span*.76),mul(n,side*side_span*.72))))
            branch=d.curve(q,add(q,mul(t,span*.48)),add(e,mul(n,-side*span*.25)),e,
                           max(6.5,12.5-level*1.7),1 if (level+group)%2 else 0,group,.48,True,4.5,n=9)
            for k,jx in enumerate((4,6)):
                p=branch[jx];bt=unit(branch[jx-1],branch[min(jx+1,8)]);bn=[-bt[1],bt[0]]
                hand=side if k==0 else -side
                reach=34+8*((d.mode+k)%3)
                tip=clamp(add(p,add(mul(bt,reach*.55),mul(bn,hand*reach))))
                twig=d.curve(p,add(p,mul(bt,reach*.4)),add(tip,mul(bn,-hand*reach*.2)),tip,
                             4.8 if k==0 else 3.5,2 if k else 1,group,.42,True,3.8,n=5)
                if (group+level+k+d.v)%4==0:d.knot(twig[-1],2,group,5.6)
    return stem

def _coral(st,v,seed):
    d=Scene('Coral',st,v,seed);m=d.mode;b=d.band;n=(7,9,11)[m]
    root=[0,300];cores=[root];assemblies=0
    if st==0:
        for i in range(n):
            x=-355+710*i/(n-1)
            y=-355+305*(abs(x)/355)**1.6
            coral_frond(d,root,[x,y],i,25-i%2*2,bend=(b-1)*17)
        assemblies=n
    elif st==8:
        # An actual open cup: high side colonies rise from a heavy U-shaped
        # reef rim while the central living fronds stay substantially lower.
        rim=d.curve([-335,-120],[-280,400],[280,400],[335,-120],31,0,0,.82)
        root=rim[6];cores=[root]
        for i in range(n):
            ix=1+round(i*10/(n-1));q=rim[ix]
            x=-335+670*i/(n-1)
            y=-355+340*(1-abs(x)/335)**1.5
            coral_frond(d,q,[x,y],i+10,23-i%2*2,bend=(b-1)*18)
        for side,ix in [(-1,0),(1,12)]:
            q=rim[ix]
            coral_frond(d,q,[side*355,-342],40+(side==1),23,bend=side*22)
        assemblies=n+2
    elif st==1:
        cores=[[-177,281],[177,281]];d.curve(cores[0],[-100,360],[100,360],cores[1],25,0,0,.8)
        for side,c in enumerate(cores):
            count=(5,6,7)[m]
            for i in range(count):
                x=c[0]-220+440*i/(count-1);y=-330+115*abs(i/(count-1)-.5)*2
                coral_frond(d,c,clamp([x,y]),side*10+i,22,bend=(-1 if side==0 else 1)*24)
        assemblies=count*2
    elif st==2:
        cores=[[0,30]];root=cores[0]
        count=(8,10,12)[m]
        for i in range(count):
            a=-90+i*360/count+6*b;end=add(root,[360*math.cos(math.radians(a)),355*math.sin(math.radians(a))])
            coral_frond(d,root,end,i,24,bend=30*(-1 if b==1 else 1))
        assemblies=count
    elif st==3:
        root=[-275,300];cores=[root]
        arch=d.curve(root,[-405,-370],[400,-390],[275,300],31,0,0,.65,True,6,n=13)
        for i,ix in enumerate((2,3,4,5,6,7,8,9,10)):
            q=arch[ix];side=-1 if ix<6 else 1
            end=clamp([q[0]+side*(80+20*m),q[1]-(105+12*(i%3))])
            if ix>=8:end=clamp([q[0]-80,q[1]-170])
            coral_frond(d,q,end,i+1,18,bend=side*13,levels=3)
        # The arch supports a living suspended reef inside its aperture.
        for j,ix in enumerate((3,5,7,9)):
            q=arch[ix];end=[q[0]*.46,225-26*(j%2)]
            coral_frond(d,q,end,40+j,16.5,bend=18*(j%2*2-1),levels=3)
        assemblies=14
    elif st==4:
        cores=[[-260,275],[0,315],[260,275]]
        d.curve(cores[0],[-130,355],[130,355],cores[-1],25,0,0,.8)
        d.path([cores[1],[0,355]],18,0,0)
        # Exact connection from middle colony to the shared lower bridge.
        d.path([cores[1],cores[0]],16,0,0)
        for j,c in enumerate(cores):
            count=(3,4,5)[m]
            for i in range(count):
                x=c[0]-150+300*i/(count-1);y=-330+70*j%2+80*abs(i/(count-1)-.5)
                coral_frond(d,c,clamp([x,y]),j*10+i,21,bend=(j-1)*20)
        assemblies=count*3
    elif st==5:
        root=[0,310];cores=[root]
        count=(4,5,6)[m]
        pillars=[]
        for i in range(count):
            x=-300+600*i/(count-1);base=[x,230]
            d.curve(root,[x*.4,320],[x,290],base,25,0,i,.7)
            top=[x+34*(i%2*2-1),-350+35*(i%3)]
            pillars.append(coral_frond(d,base,top,i+10,26,bend=(b-1)*28,levels=4))
        for i in range(len(pillars)-1):
            a=pillars[i][5];z=pillars[i+1][7]
            d.curve(a,[a[0]+55,a[1]-48],[z[0]-40,z[1]+36],z,8,1,70+i,.65,n=9)
        assemblies=count
    elif st==6:
        root=[0,-292];cores=[root]
        for i in range(n):
            x=-365+730*i/(n-1);y=340-75*(abs(x)/365)
            coral_frond(d,root,[x,y],i,24,bend=(b-1)*23)
        assemblies=n
    elif st==7:
        root=[-263,272];cores=[root]
        crescent=d.curve(root,[-410,-45],[-280,-400],[170,-340],31,0,0,.63,True,6)
        for i,ix in enumerate((2,3,4,5,6,7,8,9,10,11)):
            q=crescent[ix];end=clamp([q[0]+190+26*m,q[1]+(-20 if ix<7 else 110)])
            coral_frond(d,q,end,i+1,19,bend=-20,levels=3)
        lower=d.curve(root,[-130,295],[-20,256],[155,183],24,0,30,.58)
        for j,ix in enumerate((4,7,10)):
            q=lower[ix];coral_frond(d,q,clamp([q[0]+110,20+75*j]),31+j,16,13,3)
        assemblies=15
    else:
        cores=[[-290,285],[290,285]]
        bridge=d.curve(cores[0],[-275,-240],[275,-240],cores[1],32,0,0,.82)
        for i,ix in enumerate((1,2,3,4,5,6,7,8,9,10,11)):
            q=bridge[ix];end=clamp([q[0]+(i-5)*15,-350+40*abs(i-5)])
            coral_frond(d,q,end,i+1,19,bend=12*(b-1),levels=3)
        for j,ix in enumerate((3,6,9)):
            q=bridge[ix];coral_frond(d,q,[q[0]*.55,260-35*(j%2)],40+j,17,12,3)
        assemblies=15
    for j,c in enumerate(cores):d.node(c,39 if len(cores)<3 else 31,'hub',0,j)
    if v%3==1:d.ring([0,5],431,1.6,3,75,17,1)
    elif v%3==2:d.ring([0,5],431,1.5,2,83,8,2)
    return d.finish('coral '+('hanging' if st==6 else 'branching reef sculpture'),assemblies)

def root_branch(d,root,end,group,width=27,bend=0,levels=3):
    dx=end[0]-root[0];dy=end[1]-root[1]
    stem=d.curve(root,[root[0]+dx*.15+bend,root[1]+dy*.25],
                 [root[0]+dx*.76-bend*.25,root[1]+dy*.75],end,width,0,group,.35,True,3.7)
    indexes=(3+(group%2),6+((group+d.v)%2),9+(group%3==1)) if levels==3 else (3,5,8,10)
    for level,ix in enumerate(indexes):
        q=stem[ix];t=unit(stem[ix-1],stem[ix+1]);normal=[-t[1],t[0]]
        for side in (-1,1):
            reach=(85-level*12+6*d.mode)*(.78+.12*((group+level+d.band)%4))
            handed=1.28 if (group+level)%2==(side==1) else .61
            e=clamp(add(q,add(mul(t,reach*(1.10+.13*(group%3))),mul(normal,side*reach*handed))))
            fork=d.curve(q,add(q,mul(t,reach*.4)),add(e,mul(normal,-side*reach*.27)),e,
                         12.5-level*1.8,1,group,.29,True,2.7,n=9)
            for k,at in enumerate((4,6)):
                p=fork[at];ft=unit(fork[at-1],fork[at+1]);fn=[-ft[1],ft[0]]
                hand=side if k==0 else -side
                target=clamp(add(p,add(mul(ft,45+6*((group+k)%3)),mul(fn,hand*(24+9*k)))))
                d.curve(p,add(p,mul(ft,19)),add(target,mul(fn,-hand*12)),target,
                        4.2-k*.8,2 if k==0 else 1,group,.3,True,2.5,n=5)
        if (level+group+d.v)%7==0:d.node(q,7.5,'junction',2,group)
    return stem

def bare_crown(d,root,sideways=0,spread=260,height=220,group=100):
    """Small upper woody crown; the large exposed lower roots remain dominant."""
    trunk=d.curve(root,[root[0]-17+sideways,root[1]-58],
                  [root[0]+sideways*.7,root[1]-height*.70],
                  clamp([root[0]+sideways,root[1]-height]),28,0,group,.55,True,4.5)
    for j,ix in enumerate((3,6,9)):
        q=trunk[ix]
        for side in (-1,1):
            start=trunk[ix+(1 if side==1 else 0)]
            e=clamp([start[0]+side*spread*(1-j*.19)*(.89 if side==1 else 1.06),start[1]-80-j*11])
            branch=d.curve(start,[start[0]+side*65,start[1]-12],[e[0]-side*42,e[1]+31],e,
                           14-j*1.7,0,group+j+1,.46,True,4.0,n=9)
            for k,at in enumerate((4,6)):
                p=branch[at];target=clamp([p[0]+side*(35+12*k),p[1]-54])
                d.curve(p,[p[0]+side*14,p[1]-14],[target[0]-side*10,target[1]+21],target,
                        5.7-k*.7,1,group+j+1,.42,True,2.9,n=5)
    return trunk

def _roots(st,v,seed):
    d=Scene('Roots',st,v,seed);m=d.mode;b=d.band;count=(7,9,11)[m]
    core=[0,-122];cores=[core];root_sources=[];supports=[]
    if st==0:
        bare_crown(d,core,(-18,18,0)[b],260,216)
        ends=[[(-385+770*i/(count-1)),345-48*abs(i/(count-1)-.5)*2] for i in range(count)]
        heart=d.curve(core,[-91,-37],[92,69],[-12,170],44,0,0,.51)
        root_sources=[heart[min(10,max(0,round(10*(1-abs(end[0])/405))+(i%3-1)))] for i,end in enumerate(ends)]
    elif st==1:
        cores=[[-155,-111],[155,-111]]
        d.curve(cores[0],[-100,-190],[100,-190],cores[1],29,0,0,.8)
        bare_crown(d,cores[0],-52,190,205,100);bare_crown(d,cores[1],52,190,205,120)
        ends=[]
        for side,c in enumerate(cores):
            for i in range((4,5,6)[m]):
                ends.append(clamp([c[0]-240+480*i/((4,5,6)[m]-1),345-25*(i%2)]));root_sources.append(c)
    elif st==2:
        core=[0,-195];cores=[core];bare_crown(d,core,12,195,148)
        root_sources=[core]*count
        ends=[[-402+804*i/(count-1),330-145*(abs(-402+804*i/(count-1))/402)**1.5] for i in range(count)]
    elif st==3:
        cores=[[-78,-144],[78,-144]]
        bare_crown(d,cores[0],-76,220,195,100);bare_crown(d,cores[1],76,220,195,120)
        braid=[]
        for side,c in enumerate(cores):
            braid.append(d.curve(c,[185*(-1 if side==0 else 1),-40],[-165*(-1 if side==0 else 1),155],[(-38 if side==0 else 38),246],32,0,side,.65))
        d.path([cores[0],cores[1]],18,0,0)
        for i in range(count):
            origin=braid[i%2][7+i%3];root_sources.append(origin)
        ends=[[-390+780*i/(count-1),355-25*(i%2)] for i in range(count)]
        for side,branch in enumerate(braid):
            sign=-1 if side==0 else 1
            for j,ix in enumerate((3,5)):
                root_sources.append(branch[ix]);ends.append([sign*(370-j*55),100+j*115])
    elif st==4:
        cores=[[-250,-150],[0,-210],[250,-150]]
        d.path([cores[0],cores[1],cores[2]],29,0,0,.8)
        for j,c in enumerate(cores):bare_crown(d,c,(j-1)*22,150,145,100+j*20)
        n=(3,4,5)[m];ends=[]
        for j,c in enumerate(cores):
            for i in range(n):
                root_sources.append(c);ends.append(clamp([c[0]-145+290*i/(n-1),343-21*(i%2)]))
    elif st==5:
        core=[0,-217];cores=[core];bare_crown(d,core,0,235,126)
        spine=d.path([core,[0,-55],[0,100],[0,235]],31,0,0,.70)
        ends=[]
        for j,q in enumerate(spine[1:]):
            for i in range((3,4,5)[m]):
                root_sources.append(q);x=-375+750*i/((3,4,5)[m]-1)
                ends.append([x,100+j*116-35*abs(x)/375])
    elif st==6:
        core=[-265,-70];cores=[core];bare_crown(d,core,75,210,240)
        arch=d.curve(core,[-390,250],[160,395],[323,187],33,0,0,.6)
        ends=[]
        for i in range(count):
            q=arch[1+i%7];root_sources.append(q)
            x=-160+550*i/(count-1)
            ends.append([x,225+130*(1-abs(x-100)/360)])
    elif st==7:
        cores=[[-103,-158],[103,-158]]
        d.path([cores[0],[0,-95],cores[1]],27,0,0,.8)
        bare_crown(d,cores[0],-115,225,165,100);bare_crown(d,cores[1],115,225,165,120)
        ends=[]
        for side,c in enumerate(cores):
            n=(4,5,6)[m]
            for i in range(n):
                root_sources.append(c);ends.append([(-1 if side==0 else 1)*(170+210*i/(n-1)),310-55*(i%3)])
    elif st==8:
        cores=[[-270,-172],[0,-205],[270,-172]]
        merge=[0,53]
        links=[]
        for j,c in enumerate(cores):
            links.append(d.curve(c,[c[0]*1.03,-35],[c[0]*.30,35],merge,27,0,j,.7))
            bare_crown(d,c,(j-1)*30,130,150,100+j*20)
        root_sources=[merge]*count
        ends=[[-395+790*i/(count-1),353-35*(i%2)] for i in range(count)]
        for side,j in enumerate((0,2)):
            sign=-1 if side==0 else 1
            for k,ix in enumerate((4,7)):
                root_sources.append(links[j][ix]);ends.append([sign*(365-k*40),135+k*105])
    else:
        core=[0,-168];cores=[core];bare_crown(d,core,0,280,185)
        root_sources=[core]*count
        ends=[[-390+780*i/(count-1),345-24*(i%2)] for i in range(count)]
    for i,(origin,end) in enumerate(zip(root_sources,ends)):
        supports.append(root_branch(d,origin,end,i,29-(i%3)*2,bend=(1 if i%2 else -1)*(28+9*b),levels=3))
    # Root webs have actual shared vertices, not detached decorative spaghetti.
    for i in range(len(supports)-1):
        if (i+b)%3==1 and st!=9:continue
        a=supports[i][7 if i%2 else 9];z=supports[i+1][9 if i%2 else 7]
        if math.dist(a,z)>15:
            d.curve(a,[a[0],a[1]+33],[z[0],z[1]-25],z,5.6,1,300+i,.7,n=7)
    for j,c in enumerate(cores):d.node(c,38 if len(cores)<3 else 31,'hub',0,j)
    if v in (2,5,8,9):d.ring([0,9],431,1.5,3,74,22,1)
    return d.finish('exposed rootwood '+('crescent' if st==6 else 'vertical sanctuary'),len(supports))

def bonsai_bough(d,root,end,group,width=18,flat=False):
    side=1 if end[0]>root[0] else -1
    main=d.curve(root,[root[0]+side*abs(end[0]-root[0])*.36,root[1]+(0 if flat else 12)],
                 [end[0]-side*34,end[1]+(0 if flat else 25)],end,width,0,group,.50,True,3.8)
    # Canopy masses carry the family silhouette even at marketplace thumbnail
    # scale; individual leaf sprays add fine detail instead of replacing mass.
    halfwidth=min(87,max(43,math.dist(root,end)*.28))
    d.canopy(main[5],halfwidth,27+2*d.mode,group,side)
    d.canopy(main[9],halfwidth*.83,25+2*d.band,group,side)
    for j,at in enumerate((4,7,10)):
        q=main[at]
        reach=(50,63,72)[(d.mode+j)%3]
        target=clamp([q[0]+side*reach*.70,q[1]-reach])
        spray=d.curve(q,[q[0]+side*21,q[1]-9],[target[0]-side*18,target[1]+23],target,
                      7.7-j*.6,1,group,.48,True,2.8,n=7)
        d.leaf(target,-105+side*25,26+4*d.band,13+2*d.mode,1,group)
        for k,(point,hand) in enumerate(((spray[3],-1),(spray[5],1))):
            end2=clamp([point[0]+hand*(24+6*d.mode),point[1]-30-5*j])
            twig=d.curve(point,[point[0]+hand*12,point[1]-7],
                         [end2[0]-hand*8,end2[1]+13],end2,4.4,1,group,.40,True,2.2,n=5)
            d.leaf(twig[-1],-90+hand*(34+8*d.band),24+3*d.mode,13+2*d.band,1,group)
            if (group+j+k+d.v)%7==0:d.knot(twig[-1],2,group,6.6)
    d.leaf(main[-1],-38 if side>0 else -142,27+3*d.mode,14,1,group)
    return main

def bonsai_trunk(d,root,top,group,boughs=10,spread=285,bend=35,straight=False):
    height=root[1]-top[1]
    bend=0 if straight else math.copysign(max(90,abs(bend)*1.6),bend or 1)
    joints=[root,clamp([root[0]-bend*.75,root[1]-height*.29]),
            clamp([top[0]+bend*.65,root[1]-height*.66]),top]
    points=[]
    for j,(a,z) in enumerate(zip(joints,joints[1:])):
        dx=z[0]-a[0];dy=z[1]-a[1]
        segment=bez(a,[a[0]+dx*.05,a[1]+dy*.38],
                    [z[0]-dx*.05,z[1]-dy*.38],z,7)
        points.extend(segment if not points else segment[1:])
    trunk=d.path(points,39,0,group,.51,True,4.5)
    # Broad woody buttress roots visibly tie the tree to its base.
    for j,side in enumerate((-1,1)):
        end=clamp([root[0]+side*104,root[1]+40])
        rootpath=d.curve(root,[root[0]+side*32,root[1]+13],[end[0]-side*27,end[1]-10],end,
                         22,0,group,.32,True,3.4,n=7)
        d.path([rootpath[3],clamp([end[0]+side*37,end[1]+15])],5.0,2,group,.4,True,2.5)
    # Every canopy tier is developed, even in the least dense Preview profile.
    level_count=(6+d.mode) if straight else max(4,boughs//2+d.band-1)
    levels=sorted(set(round(3+i*13/(level_count-1)) for i in range(level_count)))
    for j,ix in enumerate(levels):
        level_ratio=j/max(1,len(levels)-1)
        span=spread*(1-.42*level_ratio)
        for side in (-1,1):
            q=trunk[ix if straight else min(17,ix+(1 if side==1 else 0))]
            drift=25*(d.band-1)*side
            handed=1 if straight else (1.08 if (j+d.band)%2==(side==1) else .79)
            end=clamp([q[0]+side*span*handed,q[1]+(-16 if straight else -53-16*(j%2)+drift)])
            bonsai_bough(d,q,end,group*20+j*2+(side==1),18-j*.7,flat=straight)
    # A compact apex pad finishes the silhouette, rather than a bare stick.
    for side in (-1,1):
        end=clamp([top[0]+side*118,top[1]-21])
        bonsai_bough(d,trunk[-1],end,group*20+18+(side==1),11.5)
    return trunk

def canopy_attachments(d,start=2,end=11,counts=(6,8,10)):
    """Discrete primary branch plans; fine leaf movement is supplemental."""
    count=counts[d.mode]
    return sorted(set(round(start+i*(end-start)/(count-1)) for i in range(count)))

def _bonsai(st,v,seed):
    d=Scene('Bonsai',st,v,seed);m=d.mode;b=d.band
    base=[0,312];cores=[base];assemblies=0
    if st==0:
        bonsai_trunk(d,base,[-27+27*b,-292],1,10+2*m,285,bend=65*(1 if b!=1 else -1));assemblies=1
    elif st==1:
        cores=[[-115,309],[115,309]]
        d.curve(cores[0],[-40,350],[40,350],cores[1],28,0,0,.8)
        bonsai_trunk(d,cores[0],[-173,-310],1,8+2*m,205,-43)
        bonsai_trunk(d,cores[1],[147,-285],2,8+2*m,205,48);assemblies=2
    elif st==2:
        base=[-168,310];cores=[base]
        trunk=d.curve(base,[-286,93],[-112,-236],[180,-305],41,0,0,.55,True,4.6)
        for j,ix in enumerate(canopy_attachments(d)):
            q=trunk[ix];side=-1 if j%3==0 else 1
            target=clamp([q[0]+side*(200-j*7),q[1]-50+16*(j%2)])
            bonsai_bough(d,q,target,j+1,18-j*.4)
        for side in (-1,1):bonsai_bough(d,trunk[-1],clamp([180+side*170,-330]),20+(side==1),13)
        assemblies=1
    elif st==3:
        base=[-205,260];cores=[base]
        trunk=d.curve(base,[-340,-281],[185,-400],[310,155],40,0,0,.52,True,5,n=13)
        for j,ix in enumerate(canopy_attachments(d,1,11)):
            q=trunk[ix];side=-1 if j%2==0 else 1
            target=clamp([q[0]+side*(160+14*m),q[1]-48+(60 if ix>8 else 0)])
            bonsai_bough(d,q,target,j+1,18-j*.45)
        for j,ix in enumerate((1,2)):
            q=trunk[ix];bonsai_bough(d,q,[-310+245*j,165-30*j],30+j,18)
        assemblies=1
    elif st==4:
        trunk=d.curve(base,[-60,120],[25,-100],[0,-205],42,0,0,.60,True,4)
        for j,ix in enumerate(canopy_attachments(d,2,12,(4,6,8))):
            q=trunk[ix]
            for side in (-1,1):
                target=clamp([side*(335-20*j),q[1]-135+(40 if j%2 else 0)])
                bonsai_bough(d,q,target,j*2+(side==1)+1,20-j)
        assemblies=1
    elif st==5:
        bonsai_trunk(d,base,[0,-320],1,12+2*m,310,bend=0,straight=True);assemblies=1
    elif st==6:
        cores=[[-232,300],[232,300]]
        arch=d.curve(cores[0],[-334,-360],[334,-360],cores[1],40,0,0,.82)
        for j,ix in enumerate(canopy_attachments(d,1,11,(7,9,11))):
            q=arch[ix];side=-1 if ix<6 else 1
            target=clamp([q[0]+side*(100+12*m),q[1]-85])
            bonsai_bough(d,q,target,j+1,17.5)
        for j,ix in enumerate((3,6,9)):
            q=arch[ix];bonsai_bough(d,q,[q[0]*.25,100+32*(j%2)],30+j,16)
        d.curve(cores[0],[-90,348],[90,348],cores[1],20,0,0,.8);assemblies=2
    elif st==7:
        cores=[[-245,315],[0,315],[245,315]]
        d.path([cores[0],cores[1],cores[2]],27,0,0,.9)
        for j,c in enumerate(cores):
            bonsai_trunk(d,c,[c[0]+(j-1)*17,-280-45*(j==1)],j+1,8+2*m,156,bend=(j-1)*24)
        assemblies=3
    elif st==8:
        base=[-43,315];cores=[base]
        trunk=d.curve(base,[270,90],[-260,-152],[44,-318],41,0,0,.48,True,5)
        for j,ix in enumerate(canopy_attachments(d)):
            q=trunk[ix];side=1 if j%2==0 else -1
            target=clamp([q[0]+side*(238-j*7),q[1]-72])
            bonsai_bough(d,q,target,j+1,20-j*.55)
        assemblies=1
    else:
        base=[0,178];cores=[base]
        # A faceted rock and exposed buttresses unmistakably support a living tree.
        d.s['facets'].append(dict(points=[[-158,346],[-122,235],[-51,190],[84,208],[164,344]],color=0,group=0,kind='rock'))
        for j,x in enumerate((-141,-85,-35,35,85,141)):
            d.curve(base,[x*.3,215],[x*.8,284],[x,344],17-j%2*2,0,j+30,.30,True,3.2)
        bonsai_trunk(d,base,[-38,-318],1,10+2*m,320,bend=35*(b-1));assemblies=1
    for j,c in enumerate(cores):d.node(c,34 if len(cores)<3 else 26,'hub',0,j)
    # Bonsai retain their own visual grammar: broad foliage and a subtle base,
    # not the full universal halo that previously made unrelated families alike.
    if v%3==2:d.ring([0,-7],431,1.5,2,96,31,2)
    return d.finish('bonsai '+('cascade' if st==3 else 'leafy tree pavilion'),assemblies)

def build(family,subtype,variant,seed):
    if family not in FAMILIES or subtype not in range(10) or variant not in range(10):
        raise ValueError('Unknown organic family, subtype or variant')
    return {'Coral':_coral,'Roots':_roots,'Bonsai':_bonsai}[family](subtype,variant,int(seed))

def _fingerprint(g):
    return hashlib.sha256(json.dumps({k:g[k] for k in ('paths','tips','nodes','rings','facets')},sort_keys=True,separators=(',',':')).encode()).hexdigest()

def _selftest():
    seen=set();stats={}
    for family in FAMILIES:
        counts=[]
        for st in range(10):
            for v in range(10):
                g=build(family,st,v,850199+(FAMILIES.index(family)*100+st*10+v+1)*7919)
                fingerprint=_fingerprint(g);assert fingerprint not in seen;seen.add(fingerprint)
                assert all(math.isfinite(x) for p in g['paths'] for q in p['points'] for x in q)
                assert all(math.dist(a,b)>1e-7 for p in g['paths'] for a,b in zip(p['points'],p['points'][1:]))
                assert all(max(map(abs,q))+p['width']*.5<457 for p in g['paths'] for q in p['points'])
                assert all(max(map(abs,n['pos']))+n['radius']<457 for n in g['tips']+g['nodes'])
                assert all(max(map(abs,q))<457 for p in g['facets'] for q in p['points'])
                adjacency={}
                for p in g['paths']:
                    for a,b in zip(p['points'],p['points'][1:]):
                        a=tuple(a);b=tuple(b);adjacency.setdefault(a,set()).add(b);adjacency.setdefault(b,set()).add(a)
                remaining=set(adjacency);hubs=[x for x in g['nodes'] if x['style']=='hub']
                while remaining:
                    s=next(iter(remaining));reached={s};queue=[s]
                    while queue:
                        for b in adjacency[queue.pop()]:
                            if b not in reached:reached.add(b);queue.append(b)
                    remaining-=reached
                    assert any(math.dist(p,n['pos'])<=n['radius'] for p in reached for n in hubs),(family,st,v,'ungrounded')
                vertices=set(adjacency)
                assert all(tuple(n['pos']) in vertices for n in g['tips']),(family,st,v,'tip detached')
                counts.append(len(g['paths']))
        stats[family]={'count':100,'min_paths':min(counts),'max_paths':max(counts)}
    print(json.dumps(stats,indent=2))
    return stats

if __name__=='__main__':_selftest()
