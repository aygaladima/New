#!/usr/bin/env python3
"""Generate V3 delivery documentation from the final production inventory.

This command never builds geometry, changes media, creates ZIPs, or contacts Git.
Run it after the family builders and Collection.json are final, before packaging.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import io
import json
from pathlib import Path
import platform
import subprocess

import numpy
import PIL

ROOT = Path(__file__).resolve().parents[1]
BRANCH = "forge-pass-1100-v3-collection"
EXPECTED_FAMILIES = ["Circuit", "Lightning", "Coral", "Frost", "Roots", "Trident",
                     "Crown", "Lattice", "Cascade", "Bonsai", "Starburst"]
TIER_COUNTS = {"Preview": 990, "Volumetric": 110}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def write_owned(path, text):
    require(not path.is_symlink(), f"Refusing symlinked documentation: {path}")
    if path.exists() and path.read_text(encoding="utf-8") == text:
        return
    path.write_text(text, encoding="utf-8")


def runtime_versions():
    result = subprocess.run(["ffmpeg", "-version"], capture_output=True, text=True, check=True)
    line = result.stdout.splitlines()[0]
    return {"python": platform.python_version(), "numpy": numpy.__version__,
            "pillow": PIL.__version__, "ffmpeg": line.split(" Copyright", 1)[0]}


def load_inventory(root):
    path = root / "Collection.json"
    require(path.is_file(), "Run the final source/build_collection.py before generating V3 documents")
    collection = json.loads(path.read_text(encoding="utf-8"))
    require(str(collection.get("art_direction_version", "")).startswith("V3"), "Expected a V3 collection inventory")
    items = collection["items"]
    require(len(items) == 1100 and [item["id"] for item in items] == list(range(1, 1101)), "Artwork IDs must cover 1–1100 in order")
    require(Counter(item["tier"] for item in items) == Counter(TIER_COUNTS), "Incorrect tier counts")
    families = defaultdict(list)
    for item in items:
        families[item["family"]].append(item)
        require(item["png"].startswith(item["tier"] + "/ForgePass_V3_"), "Unexpected V3 PNG association")
        require((item["tier"] == "Volumetric") == bool(item.get("gif")), "Incorrect GIF association")
    require(list(families) == EXPECTED_FAMILIES, "Unexpected family identities or order")
    subtypes = []
    for family, group in families.items():
        require(len(group) == 100 and Counter(i["tier"] for i in group) == Counter({"Preview": 90, "Volumetric": 10}), "Incorrect family allocation")
        for index in range(10):
            selected = [i for i in group if i["subtype_index"] == index]
            require(len(selected) == 10 and Counter(i["tier"] for i in selected) == Counter({"Preview": 9, "Volumetric": 1}), "Incorrect subtype allocation")
            require(len({i["subtype_name"] for i in selected}) == 1, "Inconsistent subtype names")
            preview = [i["id"] for i in selected if i["tier"] == "Preview"]
            volumetric = next(i["id"] for i in selected if i["tier"] == "Volumetric")
            require(preview == list(range(selected[0]["id"], selected[-1]["id"])) and volumetric == selected[-1]["id"], "Unexpected subtype ID layout")
            subtypes.append({"family": family, "subtype_index": index, "subtype_name": selected[0]["subtype_name"],
                             "preview_ids": preview, "volumetric_id": volumetric,
                             "artwork_id_first": selected[0]["id"], "artwork_id_last": selected[-1]["id"]})
    return collection, families, subtypes


def csv_text(subtypes):
    stream = io.StringIO(newline="")
    columns = ["family", "subtype_index", "subtype_name", "preview_count", "volumetric_count", "total_artworks",
               "preview_ids", "volumetric_id", "artwork_id_first", "artwork_id_last"]
    writer = csv.DictWriter(stream, fieldnames=columns, lineterminator="\n")
    writer.writeheader()
    for row in subtypes:
        writer.writerow({**row, "preview_count": 9, "volumetric_count": 1, "total_artworks": 10,
                         "preview_ids": " ".join(f"{ident:04d}" for ident in row["preview_ids"]),
                         "volumetric_id": f"{row['volumetric_id']:04d}",
                         "artwork_id_first": f"{row['artwork_id_first']:04d}", "artwork_id_last": f"{row['artwork_id_last']:04d}"})
    return stream.getvalue()


def generate(root=ROOT):
    root = Path(root).resolve()
    collection, families, subtypes = load_inventory(root)
    versions = runtime_versions()
    plan = {
        "schema": "forge-pass-v3-collection-plan-v1", "project": "Forge Pass",
        "art_direction_version": collection["art_direction_version"],
        "supersedes_artwork_branch": collection.get("supersedes_artwork_branch", "forge-pass-1100-collection"),
        "publication_branch": BRANCH, "artwork_count": 1100, "tier_counts": TIER_COUNTS,
        "family_count": 11, "subtypes_per_family": 10, "structural_subtype_count": 110,
        "per_family": {"Preview": 90, "Volumetric": 10}, "per_subtype": {"Preview": 9, "Volumetric": 1},
        "media_counts": {"png": 1100, "gif": 110, "total": 1210},
        "animated_png_is_backup_of_same_artwork": True,
        "artwork_ids": {"first": 1, "last": 1100, "family_block": 100, "subtype_block": 10,
                        "volumetric_is_last_id_in_each_subtype_block": True, "onchain_token_ids_assigned": False},
        "tiers": {"Preview": {"format": "PNG", "size": [2048, 2048], "mode": "RGB", "animation": False},
                  "Volumetric": {"format": "GIF", "size": [1000, 1000], "fps": 20,
                                 "source_timeline_frames": 240, "duration_ms": 12000, "loop": 0,
                                 "file_size_limit_exclusive": 50_000_000,
                                 "png_backup_size": [2048, 2048], "png_backup_pose": "maximum separation",
                                 "palette_policy": "Adaptive global palette; actual exported palette size is recorded in Validation.json"}},
        "visual_design": {"method": "Procedural Python 2.5D shaded sculpture and coherent depth layers",
                          "requirements": ["Recognizable family silhouette and construction at thumbnail size",
                                           "Substantial body and connected branch hierarchy, not halo-only occupancy",
                                           "Purposeful open channels within fuller compositions",
                                           "Distinct structural subtype and variant compositions",
                                           "Stable family material/palette roles",
                                           "Slow visible Volumetric separation and merging while the sculpture remains substantial"],
                          "acceptance_reference": "Art_Direction.md"},
        "production_environment": versions,
        "source_files": ["family_architectural.py", "family_energy.py", "family_organic.py", "family_crown.py", "family_cascade.py",
                         "build_collection.py", "style.py", "render_art.py", "produce.py", "review_collection.py",
                         "validate_collection.py", "generate_docs.py", "package_collection.py", "deliver_collection.py"],
        "reproduction": {"restore_backup_geometry": "python Restore_Geometry.py",
                         "or_regenerate_geometry": "python source/build_collection.py",
                         "render_pngs": "python source/produce.py stills --workers 4",
                         "render_gifs": "python source/produce.py animations --workers 4",
                         "review_sheets": "python source/review_collection.py",
                         "validate": "python source/validate_collection.py",
                         "generate_docs": "python source/generate_docs.py"},
        "delivery": {"archive_prefix": "ForgePass_V3_1100", "independent_zip_files": True,
                     "gif_and_matching_png_stay_together": True, "art_zip_limit_exclusive": 95_000_000,
                     "source_backup_limit_exclusive": 80_000_000,
                     "full_download": f"https://github.com/aygaladima/New/archive/refs/heads/{BRANCH}.zip"},
        "budget": {"user_target": "$0 out-of-pocket", "nft_launch_costs_verified": False},
        "nft_launch": {"minted": False, "listed": False, "contract_deployed": False,
                       "metadata_status": "Collection.json is a production inventory, not deployed NFT metadata",
                       "hosting_selected": False},
        "families": [{"name": family, "artwork_id_first": group[0]["id"], "artwork_id_last": group[-1]["id"],
                      "Preview": 90, "Volumetric": 10, "subtypes": [s for s in subtypes if s["family"] == family]}
                     for family, group in families.items()],
    }
    rows = ["| Family | Artwork IDs | Preview | Volumetric |", "|---|---|---:|---:|"]
    for family, group in families.items():
        rows.append(f"| {family} | {group[0]['id']:04d}–{group[-1]['id']:04d} | 90 | 10 |")
    readme = f"""# Forge Pass V3 — sculptural redesign

Forge Pass V3 contains **990 Preview artworks and 110 Volumetric artworks**. Its eleven families each contain ten structural subtypes; each subtype contains nine Preview compositions and one Volumetric composition.

The complete export contains **1,100 PNGs and 110 animated GIFs: 1,210 media files**. A Volumetric artwork's PNG is its still backup, not another artwork or another Preview edition.

V3 responds to the request for fuller branch design and unmistakable family identity. It rebuilds the subjects with stronger silhouettes, substantial primary structures, distributed secondary branches, sculptural panels/canopies/filigree, and richer finish. Outer rings are framing, not a substitute for a resolved subject. See `Art_Direction.md` for the review criteria. The earlier `forge-pass-1100-collection` delivery remains a separate archive.

## Download and view

Use the [V3 family download index](https://github.com/aygaladima/New/blob/{BRANCH}/ForgePass_V3_1100_Downloads.md) or [complete V3 outer ZIP](https://github.com/aygaladima/New/archive/refs/heads/{BRANCH}.zip) after publication.

1. Extract the complete outer ZIP.
2. Extract its individual artwork ZIPs into one common destination. Their Preview and Volumetric folders combine into the collection.
3. Open PNGs in an image viewer. Open GIFs in a browser or viewer that supports animation.

Each family ZIP also works as an independent download below 95 MB. These are ordinary ZIPs, not split-volume archives. An animated artwork's PNG and GIF stay together. `Package_Manifest.json` records exact artwork coverage, file sizes, and SHA-256 checksums.

The finished artwork can be used directly. The optional source backup supports inspection and reproduction; no Blender installation or code execution is required to view the media.

## Collection map

{chr(10).join(rows)}

Each family occupies 100 consecutive artwork IDs. Each subtype occupies ten: its first nine IDs are Preview and its final ID is Volumetric. For example, IDs 0001–0009 and 0010 form Circuit's first subtype. `Families_Subtypes.csv` lists all 110 current subtype names and exact allocations; its `subtype_index` is the source's zero-based 0–9 index.

`Collection.json` is the per-artwork production inventory, including family, subtype, variant, tier, palette, seed, geometry fingerprint and media association. Artwork IDs are not assigned on-chain token IDs. A later minting workflow must map them explicitly.

## Export specifications

- Preview: finished static 2048 × 2048 RGB PNG.
- Volumetric: 1000 × 1000 GIF, 20 fps, a 240-frame source timeline, 12-second infinite loop, below 50,000,000 bytes.
- Each Volumetric artwork also has a 2048 × 2048 RGB PNG backup at maximum separation.
- The encoder uses an adaptive global palette when necessary to stay within the size limit. Actual palette sizes, encoded-frame counts and timing are recorded in the validation data. Adjacent identical poses may coalesce into longer encoded GIF frame durations while preserving the 12-second timeline.

Volumetric foreground/rear structures separate and merge slowly through coordinated scale, angle and offset changes. The sculpture keeps substantial frame coverage throughout the cycle. Where a core hub is present, its interior stays fixed while connected assemblies move.

The production method is procedural Python **2.5D** shading and depth-layer animation. It is not a Blender/Cycles render or a physically simulated participating-volume effect. Beveled rails, shaded facets, inlays and material highlights create the sculptural appearance.

## Source and reproducibility

The backup contains source, project documents, compressed geometry, final validation and review evidence within its 80 MB budget. Media are delivered separately in the artwork ZIPs. Temporary frame caches, vendor binaries and credentials are excluded.

Recorded production environment:

- Python {versions['python']}.
- NumPy {versions['numpy']}.
- Pillow {versions['pillow']}.
- {versions['ffmpeg']} as an external executable on PATH.

In a separate extracted source-backup copy:

```bash
python -m pip install -r requirements.txt
python Restore_Geometry.py
python source/produce.py stills --workers 4
python source/produce.py animations --workers 4
python source/review_collection.py
python source/validate_collection.py
python source/generate_docs.py
```

Install FFmpeg separately through the operating system. Run `Restore_Geometry.py` only for the extracted backup. An existing production workspace already has uncompressed geometry. To regenerate geometry from the builders instead, run `python source/build_collection.py` before production.

Reduce worker count to fit available CPU and memory. `--ids 3,10` selects individual artwork IDs. The PNG and GIF jobs reuse exports only when recorded geometry and pipeline fingerprints and actual media checksums match. Active frame caches are removed after successful GIF export checks.

The five family builders are `family_architectural.py` (Circuit/Lattice/Trident), `family_energy.py` (Lightning/Frost/Starburst), `family_organic.py` (Coral/Roots/Bonsai), `family_crown.py` and `family_cascade.py`. They preserve a deterministic source definition for every artwork.

## Validation and packaging

Per-export reports check PNG dimensions/mode and fully decode GIFs to inspect timing, looping, fixed hubs, endpoint continuity and visible movement. Final validation checks complete allocation, geometry and media hashes, graph attachment and exact file coverage. Review sheets support visual inspection of family/subtype/variant identity and fullness; numerical density scores alone do not establish visual quality.

After final media validation, visual review and documentation:

```bash
python source/package_collection.py --plan
python source/package_collection.py
python source/deliver_collection.py --mode plan
```

Packages are immutable once created. If the art or documentation changes afterward, use a new delivery directory/version rather than overwriting a package with different contents under the same filename.

The delivery plan is local and read-only by default. Publishing requires an explicitly prepared repository on `{BRANCH}` with the initial repository commit available and an authorized publish invocation. The helper uses bounded uploads, preserves unknown files, avoids force-pushes and checks public downloads afterward. Git and curl are needed only for optional delivery, not artwork viewing.

## NFT launch scope

This delivery creates art and production records. It does not deploy a contract, mint NFTs, freeze token metadata, publish items to OpenSea or list anything for sale. No Motion or Signature Forge tier is part of this edition.

The user's target remains $0 out-of-pocket. Mainnet costs, hosting allowance and retention, and marketplace presentation must be verified when a launch method is chosen. GitHub download backups do not by themselves establish permanent NFT media hosting or current OpenSea autoplay behavior.
"""
    write_owned(root / "README.md", readme)
    write_owned(root / "Collection_Plan.json", json.dumps(plan, indent=2, ensure_ascii=False) + "\n")
    write_owned(root / "Families_Subtypes.csv", csv_text(subtypes))
    write_owned(root / "requirements.txt", f"# Production Python {versions['python']}\nnumpy=={versions['numpy']}\nPillow=={versions['pillow']}\n\n# External executable, installed separately on PATH:\n# {versions['ffmpeg']}\n# Git and curl are needed only for optional delivery.\n")
    print(json.dumps({"documentation_generated": True, "artwork_count": len(collection["items"]),
                      "subtype_rows": len(subtypes), "tier_counts": TIER_COUNTS,
                      "branch": BRANCH, "runtime_versions": versions}, indent=2))
    return plan


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    args = parser.parse_args()
    generate(args.root)


if __name__ == "__main__":
    main()
