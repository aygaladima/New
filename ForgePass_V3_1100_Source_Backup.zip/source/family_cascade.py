"""Forge Pass V3: broad, richly articulated waterfalls and silver spillways.

Every composition has substantial water ribbons, connected tributaries and
pool/terrace bands. The primary subject is descending water, never a sparse
wire curtain or an ornamental circle. Standard-library geometry only.
"""
from __future__ import annotations

import hashlib
import json
import math
import random
from collections import defaultdict

FAMILIES = ['Cascade']
SUBTYPES = {'Cascade': ['Grand Terraced Falls', 'Horseshoe Cascade', 'Twin Torrent',
                       'Triple Spillway', 'Serpentine Gorge', 'Converging Rapids',
                       'Stepped Cataract', 'Braided Silver Falls', 'Rain Dome',
                       'Ocean Gate']}


def lerp(a, b, t):
    return [a[0]+(b[0]-a[0])*t, a[1]+(b[1]-a[1])*t]


def bez(a, b, c, e, n=13):
    out=[]
    for i in range(n):
        t=i/(n-1); u=1-t
        out.append([u*u*u*a[k]+3*u*u*t*b[k]+3*u*t*t*c[k]+t*t*t*e[k] for k in (0,1)])
    out[0]=list(a);out[-1]=list(e)
    return out


class Design:
    def __init__(self, subtype, variant, seed):
        self.v=variant;self.rng=random.Random(seed)
        self.s=dict(name='Cascade',subtype_name=SUBTYPES['Cascade'][subtype],
                    description='',layout='vertical waterfall cascade',main_assemblies=0,
                    paths=[],tips=[],nodes=[],rings=[],facets=[],anchor_points={})
        self.main_count=0
        self.flows=[]

    def path(self, pts, width=12, color=0, group=0, taper=.54, tip=False, radius=3.6):
        points=[]
        for q in pts:
            q=[float(q[0]),float(q[1])]
            if not points or math.dist(q,points[-1])>1e-7:points.append(q)
        if len(points)<2:raise ValueError('Degenerate water ribbon')
        self.s['paths'].append(dict(points=points,width=float(width),taper=float(taper),color=int(color),group=int(group)))
        if tip:self.tip(points[-1],radius,color,group)
        return points

    def curve(self, a,b,c,e,width=12,color=0,group=0,taper=.54,tip=False,radius=3.6,n=13):
        return self.path(bez(a,b,c,e,n),width,color,group,taper,tip,radius)

    def tip(self,p,r=3.6,color=2,group=0):
        self.s['tips'].append(dict(pos=list(p),radius=float(r),color=int(color),group=int(group)))

    def node(self,p,r=37,style='hub',color=0,group=0):
        self.s['nodes'].append(dict(pos=list(p),radius=float(r),style=style,color=int(color),group=int(group)))
        if style=='hub':self.s['anchor_points'][str(group)]=list(p)

    def tear(self,q,r=6,color=1,group=0):
        # The droplet starts exactly on its water ribbon, rather than floating.
        x,y=q
        self.s['facets'].append(dict(points=[[x,y-r*.45],[x+r*.70,y+r*.30],
                                             [x+r*.44,y+r*1.25],[x,y+r*1.70],
                                             [x-r*.44,y+r*1.25],[x-r*.70,y+r*.30]],
                                       color=int(color),group=int(group)))

    def band(self,pts,width=20,color=1,group=0):
        p=self.path(pts,width,color,group,.86)
        # Thin attached inlay faces give ledges visible body without closing
        # the clean channels between individual falling streams.
        for a,b in zip(p[:-1],p[1:]):
            delta=[b[0]-a[0],b[1]-a[1]];length=math.hypot(*delta)
            n=[-delta[1]/length*width*.25,delta[0]/length*width*.25]
            self.s['facets'].append(dict(points=[[a[0]+n[0],a[1]+n[1]],
                                                 [b[0]+n[0],b[1]+n[1]],
                                                 [b[0]-n[0],b[1]-n[1]],
                                                 [a[0]-n[0],a[1]-n[1]]],color=color,group=group))
        return p

    def fall(self,a,e,group,width=21,lean=1,rich=2,phase=0):
        """One bold descent with tributaries, fine rills, pearls and splash."""
        dy=e[1]-a[1];dx=e[0]-a[0]
        bow=min(66+10*((self.v+phase)%4),max(20,dy*.16))*lean
        p=self.curve(a,[a[0]+dx*.23+bow,a[1]+dy*.28],
                     [e[0]-dx*.10+bow*.30,e[1]-dy*.31],e,
                     width,0 if group%3 else 1,group,.40,True,4.4,n=13)
        self.main_count+=1
        self.flows.append(p)
        indices=(2+(group+self.v)%4,6+group%3,10-(group+self.v)%2) if rich>=2 else (3+group%2,8+group%2)
        for j,ix in enumerate(indices):
            q=p[ix];side=(-1 if (group+j+self.v)%2 else 1)
            reach=(19+6*((group+j+self.v)%3))*(.74 if rich==0 else 1)
            end=[q[0]+side*reach,min(395,q[1]+max(32,min(107,dy*.21+group%3*11)))]
            fork=self.curve(q,[q[0]+side*reach*.17,q[1]+30],
                            [end[0],end[1]-28],end,
                            7.5-j*.7,1 if j%2 else 0,group,.36,True,2.8,n=9)
            if rich>=2:
                at=fork[4];end2=[at[0]-side*reach*.42,min(404,at[1]+38)]
                self.curve(at,[at[0]-side*8,at[1]+8],
                           [end2[0],end2[1]-15],end2,3.5,2,group,.42,True,2.2,n=7)
            self.tear(fork[-1],4.0,1 if j%2 else 0,group)
        # Every stream has an attached lower splash, which helps it read as
        # falling water even when the family is viewed in monochrome.
        q=p[-1]
        for side in ((-1,1) if rich else ((-1 if group%2 else 1),)):
            end=[e[0]+side*(24+5*(group%3)),e[1]-34-7*(group%3)]
            self.curve(q,[q[0]+side*14,q[1]-35],[end[0],end[1]-18],end,
                       5.1,1 if side<0 else 0,group,.37,True,2.7,n=7)
        self.tear(e,6.0+(group%3)*.4,0,group)
        return p

    def pool(self,ends,group=90,tiers=2):
        points=sorted((list(p) for p in ends),key=lambda p:p[0])
        # Some compositions send several streams to the same receiving point.
        points=[p for i,p in enumerate(points) if not i or math.dist(p,points[i-1])>1e-6]
        if len(points)<2:return
        first=self.band(points,16,1,group)
        for tier in range(1,tiers+1):
            down=14*tier
            rim=[[p[0]*(1-.018*tier),min(430,p[1]+down)] for p in first]
            self.path([first[0],rim[0]],7,0,group,.8)
            self.band(rim,6.0 if tier==1 else 3.8,0 if tier%2 else 2,group)
            self.path([first[-1],rim[-1]],7,0,group,.8)

    def crest(self,points,group=0,core=True,width=27):
        p=self.band(points,width,0,group)
        if core:self.node(p[len(p)//2],40,'hub',1,group)
        # Short upward feeder rills remain attached to the crest. They finish
        # below the top margin and are distinct from the falling water body.
        for i in range(1,len(p)-1,max(3,len(p)//5)):
            q=p[i];side=-1 if q[0]<0 else 1
            end=[q[0]+side*14,max(-416,q[1]-34-8*(i%3))]
            self.curve(q,[q[0]+side*9,q[1]-8],
                       [end[0],end[1]+13],end,6.4,1,group,.48,True,3.3,n=7)
        return p

    def finish(self,description):
        # Three explicit construction bands distinguish the nine Preview
        # compositions: uninterrupted torrents, one receiving terrace, or
        # two receiving terraces. These are substantial connected ledges,
        # not just seed/colour/aspect changes.
        targets=[] if self.v<3 else ([45] if self.v<6 else [-110,145])
        for row,target in enumerate(targets):
            candidates=[]
            for flow in self.flows:
                if min(p[1] for p in flow)<target<max(p[1] for p in flow):
                    candidates.append(min(flow,key=lambda q:abs(q[1]-target)))
            candidates=sorted(candidates,key=lambda q:q[0])
            points=[]
            for q in candidates:
                if not points or math.dist(q,points[-1])>12:points.append(q)
            if len(points)>2:
                self.band(points,16.5,1,95+row)
                low=[[q[0],q[1]+9] for q in points]
                self.path([points[0],low[0]],5,0,95+row,.8)
                self.band(low,4.7,0,95+row)
                self.path([points[-1],low[-1]],5,0,95+row,.8)
        self.s['description']=description
        self.s['main_assemblies']=self.main_count
        self.s['variant_composition']=['Broad silver veil','Many-rill rapids',
            'Pearl torrent','Split-stream channel','Deep terraced current',
            'Braided tributaries','Three-channel cataract','Fanned delta',
            'Luminous spillway','Layered volumetric torrent'][self.v]
        extent=1.
        for p in self.s['paths']:
            extent=max(extent,max(max(map(abs,q)) for q in p['points'])+p['width']*.5+7)
        for p in self.s['nodes']+self.s['tips']:
            extent=max(extent,max(map(abs,p['pos']))+p['radius']+7)
        for p in self.s['facets']:
            extent=max(extent,max(max(map(abs,q)) for q in p['points'])+5)
        # Flow itself determines framing; no large decorative outer circle can
        # force a rich waterfall to become a small object inside an empty ring.
        fit=min(1.,451/extent)
        if fit<1:
            for p in self.s['paths']+self.s['facets']:
                p['points']=[[x*fit,y*fit] for x,y in p['points']]
                if 'width' in p:p['width']*=fit
            for p in self.s['nodes']+self.s['tips']:
                p['pos']=[v*fit for v in p['pos']];p['radius']*=fit
            self.s['anchor_points']={k:[v*fit for v in q] for k,q in self.s['anchor_points'].items()}
        return self.s


def build(family,subtype,variant,seed):
    if family!='Cascade' or subtype not in range(10) or variant not in range(10):
        raise ValueError('Cascade subtype and variant must be in 0..9')
    d=Design(subtype,variant,seed);v=variant
    n=[15,19,23,13,21,17,17,23,19,21][v]
    sway=[0,24,-21,46,-36,16,-49,31,-17,22][v]
    spread=[1,.95,.98,.90,1,.94,.98,1,.92,.97][v]
    mode=v%3;tiers=2+int(v in (2,4,7,8,9));ends=[]
    if subtype==0:  # full-width monumental water curtain
        points=[[(i/(n-1)*2-1)*380*spread,
                 -326-42*math.sin(i/(n-1)*math.pi)] for i in range(n)]
        crest=d.crest(points)
        for i,q in enumerate(crest):
            t=i/(n-1);x=(t*2-1)*370
            if v in (3,6):x=math.copysign(abs(x)**.86*370**.14,x)
            e=[x+sway*.3,345+35*math.sin(t*math.pi)]
            d.fall(q,e,i+1,23.5-i%3,(-1 if i<n/2 else 1),2,i)
            ends.append(e)
        d.pool(ends,tiers=tiers)
        return d.finish('Monumental silver waterfall with a broad feeder crest, substantial individual ribbons, many attached rills and layered receiving pool.')

    if subtype==1:  # an arch feeding waterfalls at a range of heights
        core=[0,-371];d.node(core,43,'hub',0,0)
        per=7+mode*2
        for side in (-1,1):
            arc=d.curve(core,[side*225,-390],[side*421,-124],
                        [side*380,90],29,0,int(side>0),.70,n=2*per+1)
            for j,ix in enumerate(range(1,len(arc),2)):
                q=arc[ix];t=j/(per-1)
                e=[side*(35+345*t)+sway*.2,348+27*math.sin(t*math.pi)]
                d.fall(q,e,2+j+int(side>0)*per,21.5-j%3,side,2,j)
                ends.append(e)
            for ix in (per//2,per,per+per//2):d.node(arc[ix],7,'orb',1,int(side>0))
        d.pool(ends,tiers=tiers)
        return d.finish('A broad horseshoe aqueduct descends into densely articulated silver waterfalls and a wide rippled basin.')

    if subtype==2:  # two visibly separated torrent masses and a central gorge
        per=7+mode*2;centers=[-220,220]
        top=[]
        for side,cx in enumerate(centers):
            points=[[cx-132+264*i/(per-1),-334-33*math.sin(i/(per-1)*math.pi)] for i in range(per)]
            crest=d.crest(points,side+1)
            top.append(crest[len(crest)//2])
            for i,q in enumerate(crest):
                e=[cx-123+246*i/(per-1)+sway*.10,350+25*math.sin(i/(per-1)*math.pi)]
                d.fall(q,e,5+side*per+i,23-i%2,(-1 if side==0 else 1),2,i)
                ends.append(e)
        d.curve(top[0],[top[0][0]+55,-414],[top[1][0]-55,-414],top[1],18,1,0,.82,n=13)
        d.pool(ends,tiers=tiers)
        return d.finish('Twin full-height torrents with separate ornate water crests, many tributaries and one shared receiving basin.')

    if subtype==3:  # three deliberate large water terraces
        cols=9+mode*4
        levels=[-326,-105,121,349]
        banks=[]
        for level,y in enumerate(levels):
            width=(377-12*level)*spread
            pts=[[-width+2*width*i/(cols-1),y+17*math.cos(i/(cols-1)*2*math.pi+level*.4)] for i in range(cols)]
            banks.append(d.band(pts,25-level*2,0 if level%2 else 1,level))
        d.node(banks[0][cols//2],42,'hub',0,0)
        for level in range(3):
            for i,(a,e) in enumerate(zip(banks[level],banks[level+1])):
                d.fall(a,e,5+level*cols+i,22-level-i%2,(-1 if i%2 else 1),0,i+level)
        d.pool(banks[-1],tiers=tiers)
        return d.finish('Three full-width sculpted spillway levels with heavy silver ledges, connected falling sheets and ornamental splashwork.')

    if subtype==4:  # a commanding S gorge with three lower flow fans
        core=[-281,-364];d.node(core,44,'hub',0,0)
        a=d.curve(core,[-400,-220],[261,-240],[202,-49],36,0,0,.89,n=17)
        b=d.curve(a[-1],[145,89],[-288,68],[-196,251],32,1,0,.78,n=17)
        spine=a+b[1:]
        count=15+mode*3
        indices=[round(2+(len(spine)-5)*i/(count-1)) for i in range(count)]
        for i,ix in enumerate(indices):
            q=spine[ix]
            side=-1 if i%2 else 1
            e=[max(-377,min(377,q[0]+side*(118+mode*17))),min(369,q[1]+265)]
            d.fall(q,e,i+1,20.5-i%3,side,2,i)
            ends.append(e)
        lower=[p[-1] for p in [d.curve(b[-1],[-148,319],[-302,355],[-345,370],23,0,40,.4,n=13),
                              d.curve(b[-1],[-94,310],[112,337],[193,372],23,0,41,.4,n=13),
                              d.curve(b[-1],[-23,269],[277,304],[366,356],23,1,42,.4,n=13)]]
        ends.extend(lower);d.pool(sorted(lower,key=lambda q:q[0]),tiers=tiers)
        return d.finish('A substantial serpentine silver gorge, densely furnished with falling tributaries, divides into a broad lower delta.')

    if subtype==5:  # converging upper gorge, spreading lower rapids
        left=[-306,-340];right=[306,-340];merge=[0,-12]
        d.node(left,43,'hub',0,0);d.node(right,43,'hub',1,1)
        d.node(merge,29,'junction',0,2)
        top_per=6+mode
        for side,core in enumerate((left,right)):
            for j in range(top_per):
                # Each bundle joins its large source and a shared actual vertex.
                bend=(j-(top_per-1)/2)*42
                p=d.curve(core,[core[0]*.94+bend*.4,-190],
                          [merge[0]+bend,-85],merge,21-j%3,side,j+3,.50,n=13)
                d.main_count+=1
                d.flows.append(p)
                for k,ix in enumerate((3,6,9)):
                    q=p[ix];sign=-1 if side==0 else 1
                    e=[q[0]+sign*(37+5*j%15),q[1]+66]
                    fork=d.curve(q,[q[0]+sign*27,q[1]+6],[e[0],e[1]-20],e,6.4,1,j+3,.35,True,3,n=9)
                    d.tear(fork[-1],5,0,j+3)
        fan=11+mode*4
        for i in range(fan):
            e=[-371+742*i/(fan-1),342+40*math.sin(i/(fan-1)*math.pi)]
            d.fall(merge,e,20+i,21-i%3,(-1 if i<fan/2 else 1),2,i)
            ends.append(e)
        d.pool(ends,tiers=tiers)
        return d.finish('Twin mountain sources converge through broad silver rapids, then open into a richly branched lower waterfall fan.')

    if subtype==6:  # diagonal stair of broad overflow terraces
        levels=4+mode
        spinepts=[[-318+30*i,-351+675*i/(levels-1)] for i in range(levels)]
        spine=d.band(spinepts,30,0,0);d.node(spine[0],42,'hub',1,0)
        per=7+mode*2
        for level,q in enumerate(spine):
            width=595-level*28
            ledgepts=[[q[0]+width*j/(per-1),q[1]+18*math.sin(j/(per-1)*math.pi)] for j in range(per)]
            ledge=d.band(ledgepts,21-level,1,level+1)
            for j,p in enumerate(ledge):
                end=[p[0]+26+8*(j%2),min(379,p[1]+145-level*8)]
                d.fall(p,end,10+level*per+j,18.5-j%3,1,0,j)
                if level==levels-1:ends.append(end)
        d.pool(ends,tiers=tiers)
        return d.finish('A broad staircase of sculpted water ledges pours in many short, richly forked overflows toward a receiving pool.')

    if subtype==7:  # three broad, interlaced water lanes
        per=5+mode;lane_centers=[-245,0,245]
        roots=[]
        for lane,cx in enumerate(lane_centers):
            for i in range(per):
                offset=(i-(per-1)/2)*(20 if per<7 else 17)
                pts=[]
                for j in range(17):
                    t=j/16
                    x=cx+offset+(67+mode*8)*math.sin(t*2*math.pi+lane*.90)*math.sin(t*math.pi)
                    y=-339+702*t
                    pts.append([x,y])
                p=d.path(pts,21-i%3,lane%2,3+lane*per+i,.42,True,4.5)
                d.main_count+=1;roots.append(p[0]);ends.append(p[-1])
                d.flows.append(p)
                for k,ix in enumerate((4,8,12)):
                    q=p[ix];side=-1 if (lane+i+k)%2 else 1
                    e=[q[0]+side*(29+k*5),min(393,q[1]+87)]
                    fork=d.curve(q,[q[0]+side*24,q[1]+13],[e[0],e[1]-20],e,6.4-k*.5,1,3+lane*per+i,.40,True,3,n=9)
                    d.tear(fork[-1],4.9,0,3+lane*per+i)
                    at=fork[5];d.curve(at,[at[0]-side*7,at[1]+8],[at[0]-side*15,at[1]+20],
                                      [at[0]-side*12,at[1]+35],3.4,2,3+lane*per+i,.38,True,2.4,n=7)
        roots=sorted(roots,key=lambda q:q[0]);d.crest(roots,0)
        d.pool(ends,tiers=tiers)
        return d.finish('Three thick braided silver-water lanes, each built from parallel falling ribbons and detailed tributary splashwork.')

    if subtype==8:  # full dome shaped waterfall, not a sparse umbrella
        points=[]
        for i in range(n):
            t=i/(n-1);x=-379+758*t
            points.append([x,-43-322*math.sin(t*math.pi)])
        crest=d.crest(points,width=30)
        # Attached outer rim follows the same dome and includes real cross ties.
        rim=[[x*1.018,y-22] for x,y in crest]
        d.path([crest[0],rim[0]],9,1,0,.9);d.band(rim,7,1,0)
        for i in range(2,len(crest)-1,3):d.path([crest[i],rim[i]],7,1,0,.9)
        for i,q in enumerate(crest):
            e=[q[0]*.99+sway*.12,344+33*math.sin(i/(n-1)*math.pi)]
            d.fall(q,e,i+1,22.5-i%3,(-1 if i<n/2 else 1),2,i)
            ends.append(e)
        d.pool(ends,tiers=tiers)
        return d.finish('A monumental silver rain dome sends dense, broad descending water ribbons into a fully articulated lower pool.')

    # An aquatic gateway: two substantial side torrents and a central curtain.
    core=[0,-365];d.node(core,41,'hub',0,0)
    per=5+mode;center_count=7+mode*2
    for side in (-1,1):
        source=[side*303,-310]
        d.curve(core,[side*120,-404],[side*279,-382],source,27,0,0,.8,n=13)
        d.node(source,31,'junction',1,0)
        for j in range(per):
            e=[side*(281+(j-(per-1)/2)*22),353+19*math.sin(j/(per-1)*math.pi)]
            d.fall(source,e,4+j+int(side>0)*per,23-j%3,side,2,j)
            ends.append(e)
    center_roots=[[-208+416*i/(center_count-1),-307-34*math.sin(i/(center_count-1)*math.pi)] for i in range(center_count)]
    center_crest=d.band(center_roots,20,1,40)
    d.path([core,center_crest[len(center_crest)//2]],20,0,40,.9)
    for i,q in enumerate(center_crest):
        e=[q[0]*1.04+sway*.15,323+30*math.sin(i/(center_count-1)*math.pi)]
        d.fall(q,e,41+i,20-i%3,-1 if i%2 else 1,2,i)
        ends.append(e)
    d.pool(ends,tiers=tiers)
    return d.finish('A grand aquatic gate with two thick silver side torrents, an arched water bridge and a detailed central cascade curtain.')


def _selftest():
    hashes=set();maximum=0;minimum=10000;span=[]
    for st in range(10):
        for v in range(10):
            g=build('Cascade',st,v,913004+st*1009+v*71)
            assert 100<=len(g['paths'])<=300,(st,v,len(g['paths']))
            maximum=max(maximum,len(g['paths']));minimum=min(minimum,len(g['paths']))
            hubs=[n for n in g['nodes'] if n['style']=='hub'];assert hubs
            graph=defaultdict(set);vertices=set()
            for p in g['paths']:
                assert p['width']>0 and 0<p['taper']<=1
                pts=[tuple(round(x,6) for x in q) for q in p['points']]
                for a,b in zip(pts,pts[1:]):
                    assert math.dist(a,b)>1e-7
                    assert all(math.isfinite(x) and abs(x)<455 for x in a+b)
                    graph[a].add(b);graph[b].add(a)
                vertices.update(pts)
            remaining=set(graph)
            while remaining:
                seen={next(iter(remaining))};queue=list(seen)
                while queue:
                    for q in graph[queue.pop()]:
                        if q not in seen:seen.add(q);queue.append(q)
                remaining-=seen
                assert any(math.dist(p,h['pos'])<=h['radius'] for p in seen for h in hubs),(st,v,'unanchored')
            for p in g['tips']+g['nodes']:
                assert max(map(abs,p['pos']))+p['radius']<455
                assert any(math.dist(q,p['pos'])<1e-4 for q in vertices),(st,v,'detached terminal')
            for p in g['facets']:
                assert all(all(math.isfinite(x) and abs(x)<455 for x in q) for q in p['points'])
            finger=hashlib.sha256(json.dumps({k:g[k] for k in ['paths','tips','nodes','rings','facets']},sort_keys=True).encode()).hexdigest()
            assert finger not in hashes;(hashes.add(finger))
            xs=[p[0] for x in g['paths'] for p in x['points']];ys=[p[1] for x in g['paths'] for p in x['points']]
            span.append([max(xs)-min(xs),max(ys)-min(ys)])
    return {'count':100,'all_unique':True,'all_rail_components_anchored':True,
            'all_terminals_attached':True,'paths_min':minimum,'paths_max':maximum,
            'minimum_rail_span':[min(p[0] for p in span),min(p[1] for p in span)]}


if __name__=='__main__':print(json.dumps(_selftest(),indent=2))
