"""Coherent depth planes, fixed hubs, and shaded vector geometry for Forge Pass."""
from pathlib import Path
import math,copy
import numpy as np
from PIL import Image,ImageChops,ImageFilter
import style
COUNT=240

def canonical(frame):
 f=frame%COUNT
 return f if f<=60 else (120-f if f<=180 else f-240)
def opening(frame):return round(.5+.5*math.sin(2*math.pi*canonical(frame)/COUNT),12)

class Renderer:
 def __init__(self,g,item):
  self.g=g;self.item=item;self.palette=[tuple(c) for c in item['palette']]
  style._cache.clear();style.PALETTES[item['family']]=self.palette
  self.hubs=[n for n in g['nodes'] if n['style']=='hub']
  self.center=np.mean([n['pos'] for n in self.hubs],axis=0) if self.hubs else np.array([0.,0.])
  layout=g.get('layout','').lower();name=item['family']
  self.mode='radial'
  if any(w in layout for w in ['vertical','tower','curtain','hanging','cascade','column','pagoda','upright','pinnacle']):self.mode='vertical'
  elif any(w in layout for w in ['bridge','horizontal','wings','span']):self.mode='bridge'
  elif any(w in layout for w in ['asym','offset','slant','fan','crest','comet','windswept','crescent']):self.mode='hinged'
  self.sign=-1 if item['subtype_index']%2 else 1
 def pose(self,frame,layer):
  o=opening(frame);c=self.center
  if layer=='front':scale=.96+.055*o;angle=self.sign*(2.4 if self.mode!='vertical' else 1.7)*o
  else:scale=.96-.095*o;angle=-self.sign*2.0*o
  shift=np.array([0.,0.])
  if self.mode=='bridge':shift[1]=(-8 if layer=='front' else 13)*o
  elif self.mode=='vertical':shift[0]=(-6 if layer=='front' else 13)*self.sign*o
  else:shift=np.array([(-4 if layer=='front' else 9)*self.sign,(-4 if layer=='front' else 9)])*o
  if self.mode=='hinged':angle*=1.25
  a=math.radians(angle);co,si=math.cos(a),math.sin(a)
  mat=np.array([[co,-si],[si,co]])*scale
  def move(points):return ((np.array(points,dtype=float)-c)@mat.T+c+shift).tolist()
  return move,scale,o
 def render(self,frame=60,size=1000,supersample=2):
  if self.item['tier']=='Preview':return style.render(self.g,size,supersample)
  scale=size*supersample/1024;im=style.background(round(size*supersample),self.palette);p=style.Painter(im,scale)
  rear,rear_scale,o=self.pose(frame,'rear');front,front_scale,_=self.pose(frame,'front')
  back=style.colour(self.palette[1],.80,.10)
  if self.g['rings']:
   source=self.g['rings'][0];r=copy.deepcopy(source);r['center']=rear([r['center']])[0];r['radius']*=rear_scale;r['width']=max(1.,source['width']*.28);r['color']=1
   style.ring(p,r,self.palette)
  for rec in self.g['paths']:
   pts=rear(rec['points']);width=max(1.1,rec['width']*.24)
   p.line(pts,style.colour(back,.16),width+2,(1.4,2.4));p.line(pts,style.colour(back,.72),width+1);p.line(pts,back,max(.7,width*.58))
  for hub in self.hubs:
   q=rear([hub['pos']])[0]
   if math.dist(q,hub['pos'])>hub['radius']*.20:
    p.line([hub['pos'],q],back,max(1.3,hub['radius']*.10))
  for fac in self.g.get('facets',[]):
   pts=rear(fac['points']);p.polygon(pts,style.colour(back,.3));p.line(pts+[pts[0]],back,.65)
  for tip in self.g['tips']:
   q=rear([tip['pos']])[0];style.orb(p,q,max(1.6,tip.get('radius',3)*.62),back)
  for r0 in self.g['rings']:
   r=copy.deepcopy(r0);r['center']=front([r0['center']])[0];r['radius']*=.96+.045*o;style.ring(p,r,self.palette)
  for fac in self.g.get('facets',[]):
   moved_facet=dict(fac);moved_facet['points']=front(fac['points']);style.facet(p,moved_facet,self.palette)
  moved=[]
  for rec in self.g['paths']:
   r=dict(rec);r['points']=front(rec['points']);moved.append(r)
  for hub in self.hubs:
   origin=hub['pos'];q=front([origin])[0]
   if math.dist(origin,q)>hub['radius']*.24:moved.append({'points':[origin,q],'width':min(13.,hub['radius']*.36),'taper':.8,'color':hub.get('color',0)})
  for rec in sorted(moved,key=lambda r:-r['width']):style.rail(p,rec,self.palette)
  for tip in self.g['tips']:style.orb(p,front([tip['pos']])[0],tip.get('radius',3),self.palette[tip.get('color',2)])
  for node in self.g['nodes']:
   if node['style']=='hub':continue
   n=dict(node);n['pos']=front([node['pos']])[0];style.hub(p,n,self.palette,self.item['family'])
  for hub in self.hubs:style.hub(p,hub,self.palette,self.item['family'])
  emission=im.point([max(0,round((v-140)*.12)) for v in range(256)]*3)
  im=ImageChops.add(im,emission.filter(ImageFilter.GaussianBlur(scale*1.5)))
  return im.resize((size,size),Image.Resampling.LANCZOS)
