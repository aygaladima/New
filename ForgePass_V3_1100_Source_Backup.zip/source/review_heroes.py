from pathlib import Path
import importlib,json,sys,math,argparse
from PIL import Image,ImageDraw
import style
from render_art import Renderer
from build_collection import FAMILIES,MODULE_NAMES,palette,inset,fingerprint,sculpture_fit
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('--families',default='');args=p.parse_args()
 requested=args.families.split(',') if args.families else FAMILIES
 module_families={'family_architectural':['Circuit','Lattice','Trident'],'family_energy':['Lightning','Frost','Starburst'],'family_organic':['Coral','Roots','Bonsai'],'family_crown':['Crown'],'family_cascade':['Cascade']}
 lookup={}
 for name in MODULE_NAMES:
  if not (ROOT/'source'/f'{name}.py').exists() or not set(module_families[name])&set(requested):continue
  m=importlib.import_module(name)
  for f in m.FAMILIES:lookup[f]=m
 out=ROOT/'internal/heroes';out.mkdir(parents=True,exist_ok=True);records=[]
 for family in requested:
  if family not in lookup:continue
  for variant in [2,9]:
   ident=FAMILIES.index(family)*100+variant+1;tier='Preview' if variant==2 else 'Volumetric';seed=27002601+ident*7919
   g=sculpture_fit(lookup[family].build(family,0,variant,seed))
   if tier=='Volumetric':g=inset(g,.94)
   item={'id':ident,'family':family,'tier':tier,'subtype_index':0,'palette':palette(family,0,variant),'subtype_name':g['subtype_name']}
   r=Renderer(g,item);im=r.render(60,2048,2)
   name=f'{family}_{tier}.png';im.save(out/name,compress_level=4)
   rec={**item,'paths':len(g['paths']),'facets':len(g.get('facets',[])),'geometry_sha256':fingerprint(g),'file':name};records.append(rec)
   (out/f'{family}_{tier}.json').write_text(json.dumps(g)+'\n')
   print('HERO',family,tier,len(g['paths']),len(g.get('facets',[])),flush=True)
 # Rebuild from existing finished hero files so later runs extend the board.
 available=[f for f in FAMILIES if all((out/f'{f}_{tier}.png').exists() for tier in ['Preview','Volumetric'])]
 tile=320;rows=math.ceil(len(available)/2);cellh=tile+86
 board=Image.new('RGB',(tile*4,rows*cellh+90),(4,8,14));draw=ImageDraw.Draw(board)
 draw.text((20,12),'FORGE PASS V3 / SCULPTURAL FAMILY REDESIGN',font=style.font(27,True),fill='#e4edf7')
 draw.text((20,52),'Preview sculpture + Volumetric open-pose poster per family. Motion exports follow visual review.',font=style.font(15),fill='#a7bdcf')
 for index,family in enumerate(available):
  x=index%2*tile*2;y=90+index//2*cellh
  draw.text((x+12,y+3),family.upper(),font=style.font(20,True),fill='#ddebf5')
  for col,tier in enumerate(['Preview','Volumetric']):
   with Image.open(out/f'{family}_{tier}.png') as im:board.paste(im.resize((tile,tile),Image.Resampling.LANCZOS),(x+col*tile,y+33))
   draw.text((x+col*tile+10,y+tile+40),tier,font=style.font(17),fill='#d0e4f1')
 board.save(ROOT/'review/V3_Family_Direction.jpg',quality=95)
 (out/'Latest_Hero_Records.json').write_text(json.dumps(records,indent=2)+'\n')
if __name__=='__main__':main()
