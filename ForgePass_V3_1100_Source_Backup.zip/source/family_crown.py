"""Sculptural Crown family: jewelled bands, major points, and joined filigree.

All crown variants retain the recognisable band-and-points silhouette.  The
construction is deliberately substantial: a complete jewelled band, metal/enamel
point panels, connected major tines and tiered smaller ornamental branches.
"""
from __future__ import annotations

import math
import random
import hashlib
import json
from collections import defaultdict

FAMILIES = ["Crown"]
SUBTYPES = {"Crown": [
    "Imperial Diadem", "Gothic Sovereign", "Solar Regalia", "Fleur-de-Lis Crown",
    "Baroque Tiara", "Palatine Vault", "Battlement Coronet", "Winged Diadem",
    "Triple Crest Crown", "Diamond Coronet",
]}


def add(a, b):
    return [a[0]+b[0], a[1]+b[1]]


def mul(a, s):
    return [a[0]*s, a[1]*s]


def lerp(a, b, t):
    return [a[0]+(b[0]-a[0])*t, a[1]+(b[1]-a[1])*t]


def bezier(a, b, c, e, n=13):
    out = []
    for i in range(n):
        t = i/(n-1); u = 1-t
        out.append([u*u*u*a[k]+3*u*u*t*b[k]+3*u*t*t*c[k]+t*t*t*e[k] for k in (0, 1)])
    out[0], out[-1] = list(a), list(e)
    return out


class Crown:
    def __init__(self, st, variant, seed):
        self.st = st; self.v = variant; self.rng = random.Random(seed)
        self.g = {"name": "Crown", "subtype_name": SUBTYPES['Crown'][st],
                  "description": "A full regal crown with a broad jewelled band, monumental points, enamel panels and attached branching filigree.",
                  "layout": "regal crown", "main_assemblies": 0,
                  "paths": [], "tips": [], "nodes": [], "rings": [], "facets": [],
                  "anchor_points": {}}

    def path(self, pts, width=10, color=0, group=0, taper=.72, tip=False, radius=3.4):
        pts = [[float(x), float(y)] for x, y in pts]
        pts = [p for i, p in enumerate(pts) if not i or math.dist(p, pts[i-1]) > 1e-7]
        if len(pts) < 2:
            raise ValueError('Degenerate Crown rail')
        self.g['paths'].append(dict(points=pts, width=float(width), color=int(color),
                                    group=int(group), taper=float(taper)))
        self.g['anchor_points'].setdefault(str(group), list(pts[0]))
        if tip:
            self.g['tips'].append(dict(pos=list(pts[-1]), radius=float(radius), color=2, group=int(group)))
        return pts

    def curve(self, a, b, c, e, width=10, color=0, group=0, taper=.72, tip=False, radius=3.4):
        return self.path(bezier(a, b, c, e), width, color, group, taper, tip, radius)

    def node(self, pos, radius=10, style='orb', color=2, group=0):
        self.g['nodes'].append(dict(pos=list(pos), radius=float(radius), style=style,
                                    color=int(color), group=int(group)))

    def facet(self, pts, color=0, group=0, material='metal'):
        self.g['facets'].append(dict(points=[list(p) for p in pts], color=int(color),
                                     group=int(group), material=material))

    def gem(self, center, width, height, color=1, group=0):
        x, y = center
        top=[x,y-height];right=[x+width,y];bottom=[x,y+height];left=[x-width,y]
        # The gem centre is always an existing rail vertex. Its four facets sit
        # on that support, and the outline returns to the support to remain joined.
        self.facet([center, top, right], color, group, 'gem')
        self.facet([center, right, bottom], 0, group, 'gem')
        self.facet([center, bottom, left], color, group, 'gem')
        self.facet([center, left, top], 2, group, 'gem')
        self.path([center, top, right, bottom, left, top], 2.5, 2, group, .85)

    def scroll(self, origin, axis, reach, hand, group, color=0, branching=True):
        """An ornamental fork with a smaller exact-attached inner shoot."""
        normal=[-axis[1]*hand,axis[0]*hand]
        e=add(origin,add(mul(axis,reach*.83),mul(normal,reach*.66)))
        branch=self.curve(origin, add(origin,add(mul(axis,reach*.48),mul(normal,reach*.13))),
                          add(e,add(mul(axis,-reach*.18),mul(normal,reach*.20))), e,
                          max(3.4, reach*.105), color, group, .48, True, 3.1)
        # Broad acanthus leaf bodies make the ornament visible at thumbnail
        # scale. Their centre veins remain the exact attached branch rails.
        middle=branch[6]
        self.facet([origin,add(middle,mul(normal,reach*.23)),e,
                    add(middle,mul(normal,-reach*.14))],0,group)
        self.facet([origin,add(middle,mul(normal,reach*.12)),e,
                    add(middle,mul(normal,-reach*.07))],1,group,'enamel')
        q=branch[7]
        if branching:
            end=add(q,add(mul(axis,reach*.53),mul(normal,-reach*.12)))
            self.curve(q,add(q,mul(axis,reach*.22)),add(end,mul(normal,reach*.12)),end,
                       2.6, 2, group, .45, True, 2.7)
        # A slender enamel leaf is attached along the branch itself; it is not
        # an independent floating shape or scatter particle.
        q2=branch[10]
        shoulder=add(lerp(q,q2,.55),mul(normal,reach*.12))
        self.facet([q,shoulder,q2,lerp(q,q2,.6)],1,group,'enamel')
        return branch

    def finish(self):
        # Preserve a generous margin for the depth-plane animation. The full
        # crown remains much larger than the abandoned staff-like examples.
        extent=0.0
        for p in self.g['paths']:
            extent=max(extent,*(max(map(abs,q))+p['width']*.65+6 for q in p['points']))
        for n in self.g['nodes']+self.g['tips']:
            extent=max(extent,max(map(abs,n['pos']))+n['radius']+6)
        for f in self.g['facets']:
            extent=max(extent,*(max(map(abs,q))+4 for q in f['points']))
        factor=min(1.,452/max(1,extent))
        if factor<1:
            for p in self.g['paths']+self.g['facets']:
                p['points']=[[x*factor,y*factor] for x,y in p['points']]
                if 'width' in p:p['width']*=factor
            for n in self.g['nodes']+self.g['tips']:
                n['pos']=[x*factor for x in n['pos']];n['radius']*=factor
            for key,p in self.g['anchor_points'].items():self.g['anchor_points'][key]=[x*factor for x in p]
        self.g['geometry_features']={
            'family_signature':'broad jewelled crown band + monumental crown points + branching gold filigree',
            'crown_points':self.points,'band_tiers':self.tiers,
            'composition':self.g['variant_composition']}
        return self.g


def _profile(st, u, j, n, variant):
    """The ten outlines change architecture, while always reading as crowns."""
    t=abs(u)
    if st==0:return -370+146*t**1.25+(48 if j%2 else 0)
    if st==1:return -399+105*t+(116 if j%2 else 0)
    if st==2:return -350+43*t+(38 if j%2 else -18)
    if st==3:return -356+125*t**.75
    if st==4:return -329+105*t+46*math.cos(j*math.pi)
    if st==5:return -186+93*t**1.9
    if st==6:return -342+round(t*3)*44+(67 if j%2 else 0)
    if st==7:return -337+90*(1-t)-24*t**2
    if st==8:return -359+100*t+(102 if j%2 else 0)
    return -348+124*t+(51 if j%2 else 0)


def _decorated_link(d, root, end, group, width=16, bend=0, reach=42):
    """A joined structural bough with exact-attached ornamental shoots."""
    stem=d.curve(root,[root[0]+bend,root[1]-(root[1]-end[1])*.34],
                 [end[0]-bend*.35,end[1]+(root[1]-end[1])*.24],end,
                 width,0,group,.69)
    for k,ix in enumerate((3,6,9)):
        axis=[stem[ix+1][a]-stem[ix-1][a] for a in (0,1)]
        length=math.hypot(*axis);axis=[x/length for x in axis]
        for hand in (-1,1):d.scroll(stem[ix],axis,reach*(1-.12*k),hand,group,2 if k%2==0 else 0)
    return stem


def _ellipse(d, anchor, center, rx, ry, group, color=0, filled=True):
    bottom=[center[0],center[1]+ry]
    if math.dist(anchor,bottom)>1e-7:d.path([anchor,bottom],15,0,group,.85)
    pts=[]
    for j in range(25):
        a=math.pi/2+2*math.pi*j/24
        pts.append([center[0]+rx*math.cos(a),center[1]+ry*math.sin(a)])
    pts[0]=list(bottom);pts[-1]=list(bottom)
    if filled:
        d.facet(pts[:-1],0,group)
        d.facet([[center[0]+(p[0]-center[0])*.78,center[1]+(p[1]-center[1])*.79] for p in pts[:-1]],1,group,'enamel')
    d.path(pts,14,color,group,.97)
    d.path([bottom,center,pts[12]],11,0,group,.7)
    return pts


def _crown_lace(d, stems, group=70):
    """Royal enamel backing and joined garland filigree between supports.

    An open-work crown still needs a designed body. This fills the former bare
    stem bays with a substantial enamel surface and three readable gold scales.
    """
    for j,(left,right) in enumerate(zip(stems,stems[1:])):
        d.facet([left[0],left[3],left[6],left[9],right[9],right[6],right[3],right[0]],
                1,group+j,'enamel')
        for k,ix in enumerate((3,6,9)):
            a,b=left[ix],right[ix];span=abs(b[0]-a[0])
            if math.dist(a,b)<1e-4:continue
            fall=min(28,span*.12)
            vine=d.curve(a,[a[0]+span*.28,a[1]+fall],
                         [b[0]-span*.28,b[1]+fall],b,6.8,0,group+j,.9)
            q=vine[6]
            for hand in (-1,1):
                d.scroll(q,[0,-1],min(66,span*.34)*(1-.10*k),hand,
                         group+j,2 if k==1 else 0,branching=False)
            d.node(q,4.4,'orb',2,group+j)


def _special_upper(d, st, mode, band, top, core, band_width, top0, rise):
    """Different crown constructions, not cosmetic changes to one petal row."""
    count=3;lace_stems=[]
    crest=None
    choose=lambda j,m:top[round(j*(len(top)-1)/(m-1))] if m>1 else top[len(top)//2]
    if st==2:
        # An upper half-sun ray fan above a complete royal band.
        center=[0.,-12.-band*12];count=(11,15,19)[mode]
        d.path([top[len(top)//2],center],27,0,20,.88)
        tips=[]
        for j in range(count):
            a=math.radians(-170+160*j/(count-1));r=(326 if j%2 else 390)*rise
            end=[math.cos(a)*r,center[1]+math.sin(a)*r]
            axis=[math.cos(a),math.sin(a)];normal=[-axis[1],axis[0]]
            mid=add(center,mul(axis,r*.55));near=add(center,mul(axis,56))
            d.path([center,near,mid,end],17 if j%2 else 24,0,j+1,.48)
            d.facet([near,add(mid,mul(normal,11)),end,add(mid,mul(normal,-11))],0,j+1)
            for hand in (-1,1):d.scroll(mid,axis,29 if mode<2 else 23,hand,j+1,2)
            d.node(end,6.3,'orb',2,j+1);tips.append(end)
        d.node(center,45,'junction',0,20);d.gem(center,26,37,1,20)
        for j in range(0,count-1,2):d.path([tips[j],tips[j+1],tips[j+2]],4,2,j+1,.9)
        # Five broad rising supports fill the lower sun-crown instead of
        # presenting a detached fan on one empty central stick.
        for j in range(5):
            root=choose(j,5);tip=tips[round(j*(count-1)/4)]
            target=lerp(center,tip,.73)
            d.path([center,target,tip],10,0,40+j,.8)
            lace_stems.append(_decorated_link(d,root,target,40+j,18,bend=26*(j-2),reach=70))
        crest=tips[count//2]
    elif st==3:
        # Literal fleur-de-lis: central lance plus broad outward curled lobes.
        count=(3,5,7)[mode];centers=[]
        for j in range(count):
            root=choose(j,count);u=(j/(count-1)-.5)*2
            center=[root[0]*.93,-86.-40*(1-abs(u))]
            stem=_decorated_link(d,root,center,j+1,19,bend=18*u,
                                 reach=min(105,band_width/count*.88))
            lace_stems.append(stem)
            wide=min(112,band_width/count*.84);tall=(180-11*mode)*rise
            tip=[center[0],center[1]-tall];centers.append(center)
            for hand in (-1,1):
                shoulder=[center[0]+hand*wide,center[1]-53]
                rim=d.curve(center,[center[0]+hand*wide*.75,center[1]+16],
                            [shoulder[0]+hand*26,shoulder[1]-30],shoulder,15,0,j+1,.75)
                back=d.curve(shoulder,[shoulder[0]-hand*10,shoulder[1]+51],
                             [center[0]+hand*wide*.22,center[1]+26],center,12,0,j+1,.8)
                d.facet(rim+back[1:],0,j+1)
                d.scroll(rim[6],[0,-1],wide*.60,-hand,j+1,2)
                d.node(shoulder,6,'orb',2,j+1)
            left=[center[0]-wide*.42,center[1]-tall*.48]
            right=[center[0]+wide*.42,center[1]-tall*.48]
            d.facet([center,left,tip,right],0,j+1)
            d.path([center,left,tip,right,center],13,0,j+1,.87)
            d.path([center,tip],8,2,j+1,.6)
            d.gem(center,13,23,1,j+1);d.node(tip,6.8,'orb',2,j+1)
            if j==count//2:crest=tip
        for j,(a,b) in enumerate(zip(centers,centers[1:])):
            d.curve(a,[a[0]+24,a[1]+75],[b[0]-24,b[1]+75],b,8,0,j+1,.8)
    elif st==4:
        # A low, broad baroque tiara, with scalloped scrolls and hanging gems.
        left,right=top[0],top[-1];crest=[0.,-298*rise]
        la=d.curve(left,[-392,-90],[-160,-321*rise],crest,23,0,1,.84)
        ra=d.curve(crest,[160,-321*rise],[392,-90],right,23,0,2,.84)
        arch=la+ra[1:];count=(5,7,9)[mode]
        for j in range(count):
            ix=2+round(j*(len(arch)-5)/(count-1));q=arch[ix]
            root=choose(j,count);stem=_decorated_link(d,root,q,j+3,17,bend=(-1 if j%2 else 1)*30,
                                                    reach=min(90,band_width/count*1.18))
            lace_stems.append(stem)
            rx=30 if mode!=2 else 22;ry=43 if mode!=2 else 58
            crownlet=[q[0],q[1]-30]
            loop=_ellipse(d,q,crownlet,rx,ry,j+3,filled=False)
            d.gem(stem[7],10,19,1,j+3)
            d.node(loop[12],7,'orb',2,j+3)
        # Broad central arabesque, rather than a spear-like middle tine.
        d.node(crest,22,'junction',0,2)
    elif st==6:
        # Short square battlements form a castellated royal coronet.
        count=(7,9,11)[mode]
        for j in range(count):
            root=choose(j,count);u=(j/(count-1)-.5)*2
            x=root[0]*.96;y=(12-38*(1-abs(u))-(19 if j%2==0 else 0))*rise
            w=band_width/count*.90
            lo=[x-w,root[1]-12];ro=[x+w,root[1]-12]
            lt=[x-w,y];rt=[x+w,y];mid=[x,y]
            d.path([root,lo,lt,mid,rt,ro,root],17,0,j+1,.9)
            d.facet([lo,lt,rt,ro],0,j+1)
            d.facet([[x-w*.55,root[1]-20],[x-w*.55,y+35],[x+w*.55,y+35],[x+w*.55,root[1]-20]],1,j+1,'enamel')
            stem=_decorated_link(d,root,mid,j+1,13,reach=min(34,w*.85))
            for hand in (-1,1):
                e=[x+hand*w*.58,y-30]
                d.path([mid,e],7,0,j+1,.65,True,4)
            d.gem(stem[6],10,21,1,j+1)
            if j==count//2:
                crest=[x,-258*rise]
                left=[x-64,y-69];right=[x+64,y-69]
                d.facet([mid,left,crest,right],0,j+1)
                d.path([mid,left,crest,right,mid],13,0,j+1,.86)
                d.path([mid,crest],11,0,j+1,.8)
                _decorated_link(d,mid,crest,j+1,12,reach=45)
        d.node(crest,15,'junction',0,1)
    elif st==7:
        # Dominant upward-swept side wings flank a smaller central diadem.
        count=(3,5,7)[mode]
        for j in range(count):
            idx=round((len(top)-1)*(.27+.46*j/(count-1)));root=top[idx]
            u=(j/(count-1)-.5)*2;tip=[u*207,(-348+118*abs(u))*rise]
            stem=_decorated_link(d,root,tip,j+1,18,bend=22*u,reach=36)
            lace_stems.append(stem)
            sl=[tip[0]-42,tip[1]+100];sr=[tip[0]+42,tip[1]+100]
            d.facet([root,sl,tip,sr],0,j+1)
            d.path([root,sl,tip,sr,root],11,0,j+1,.8)
            d.gem(stem[8],12,28,1,j+1)
            if j==count//2:crest=tip
        for hand,root in [(-1,top[0]),(1,top[-1])]:
            tip=[hand*432,-283*rise];inside=[hand*211,-74]
            wing=d.curve(root,[hand*435,root[1]-30],[hand*455,-201],tip,24,0,30+(hand==1),.7)
            d.facet([root,wing[4],wing[8],tip,inside],0,30+(hand==1))
            d.path([tip,inside,root],12,0,30+(hand==1),.8)
            for k,ix in enumerate((3,5,7,9,11)):
                q=wing[ix];end=[q[0]-hand*(74+8*k),q[1]-49+8*k]
                feather=d.curve(q,[q[0]-hand*32,q[1]-8],[end[0]+hand*12,end[1]-10],end,10,2,30+(hand==1),.5)
                d.facet([q,feather[6],end,lerp(q,end,.55)],1,30+(hand==1),'enamel')
                d.scroll(feather[6],[-hand*.7,-.7],26,hand,30+(hand==1),0)
    elif st==8:
        # Three enormous oval / diamond / clover crests, never a petal row.
        count=3
        for j,x in enumerate((-242.,0.,242.)):
            root=choose(j,3);center=[x,(-122 if j==1 else -63)*rise]
            rx=(99,111,101)[mode];ry=(182,177,172)[mode]*rise
            if mode==1:
                bottom=[x,center[1]+ry];tip=[x,center[1]-ry]
                d.path([root,bottom,center,tip],18,0,j+1,.8)
                diamond=[bottom,[x-rx,center[1]],tip,[x+rx,center[1]],bottom]
                d.facet(diamond[:-1],0,j+1);d.path(diamond,17,0,j+1,.94)
                rim=diamond
            else:
                rim=_ellipse(d,root,center,rx,ry,j+1,filled=True)
                if mode==2:
                    for hand in (-1,1):
                        side=[x+hand*55,center[1]-33]
                        _ellipse(d,center,side,rx*.60,ry*.57,j+1,filled=True)
            bottom=[x,center[1]+ry]
            lace_stems.append(_decorated_link(d,root,bottom,40+j,17,bend=(-1 if j==0 else 1)*40,reach=76))
            d.gem(center,rx*.52,ry*.57,1,j+1)
            for k in range(8):
                angle=2*math.pi*k/8
                end=[x+rx*.78*math.cos(angle),center[1]+ry*.78*math.sin(angle)]
                d.path([center,end],6,2,j+1,.6)
                d.scroll(end,[math.cos(angle),math.sin(angle)],25,-1,j+1,0)
            d.node(center,16,'junction',0,j+1)
            if j==1:crest=[x,center[1]-ry]
    elif st==9:
        # A linked row of large diamond crests creates the entire upper edge.
        count=(5,7,9)[mode];diamonds=[]
        for j in range(count):
            root=choose(j,count);u=(j/(count-1)-.5)*2
            center=[root[0]*.95,(-173+64*abs(u))*rise]
            rx=min(100,band_width/(count-1)*.92);ry=(157+(22 if j%2==0 else 0))*rise
            bottom=[center[0],center[1]+ry];tip=[center[0],center[1]-ry]
            left=[center[0]-rx,center[1]];right=[center[0]+rx,center[1]]
            d.path([root,bottom,center,tip],18,0,j+1,.74)
            d.facet([bottom,left,tip,right],0,j+1)
            d.facet([lerp(center,bottom,.73),lerp(center,left,.72),lerp(center,tip,.73),lerp(center,right,.72)],1,j+1,'enamel')
            d.path([bottom,left,tip,right,bottom],16,0,j+1,.92)
            d.gem(center,rx*.38,ry*.47,1,j+1)
            lace_stems.append(_decorated_link(d,root,bottom,j+1,10,bend=12*u,reach=28))
            for q in (left,right):
                d.node(q,7,'orb',2,j+1)
                d.scroll(q,[0,-1],30,-1 if q is left else 1,j+1,2)
            diamonds.append((left,right,tip))
            if j==count//2:crest=tip
        for j,(a,b) in enumerate(zip(diamonds,diamonds[1:])):d.path([a[1],b[0]],10,0,j+1,.9)
    else:
        return False
    if lace_stems:_crown_lace(d,lace_stems)
    d.node(core,37,'hub',0,0)
    # Finish at an existing construction vertex; avoid disconnected floating logos.
    if crest is not None:
        topgem=[crest[0],crest[1]-24]
        d.path([crest,topgem],8,0,1,.72);d.node(topgem,8,'orb',2,1)
    d.points=count;d.g['main_assemblies']=count
    form=['upright','broad layered','high ornate'][min(2,band)]
    d.g['variant_composition']=f'{count}-motif {SUBTYPES["Crown"][st]} / {form}'
    return True


def build(family, subtype, variant, seed):
    if family!='Crown' or subtype not in range(10) or variant not in range(10):
        raise ValueError('Crown family/subtype/variant out of range')
    st=subtype;v=variant;d=Crown(st,v,seed)
    # Clear 3 × 3 construction grid: point counts and silhouette/band hierarchy.
    mode=v%3;band=v//3
    n=(3,5,7)[mode] if v<9 else (7 if st in (1,2,6,9) else 5)
    d.points=n;d.tiers=2+(band%3)
    band_width=(396,426,385,410)[band]
    # Nine Preview compositions combine point/crest construction with three
    # genuinely different band architectures: balanced, narrow ceremonial, and
    # a deep jewelled frontal band. The latter is not a slight aspect stretch.
    top0=(148,205,65,147)[band]
    bottom0=(257,279,279,262)[band]
    rise=(1.00,.84,1.09,1.02)[band]
    xlist=[-band_width+2*band_width*i/(2*n) for i in range(2*n+1)]
    top=[[x,top0+40*(1-(x/band_width)**2)] for x in xlist]
    bottom=[[x,bottom0+38*(1-(x/band_width)**2)] for x in xlist]
    core=[0.,(top[n][1]+bottom[n][1])/2]
    d.path([top[n],core,bottom[n]],25,0,0,.95)
    d.path(top,25,0,0,.95);d.path(bottom,26,0,0,.95)
    # Continuous filled metal body and inset enamel panels form a real band.
    for i in range(2*n):
        d.facet([top[i],top[i+1],bottom[i+1],bottom[i]],0,0)
        a=lerp(top[i],bottom[i],.26);b=lerp(top[i+1],bottom[i+1],.26)
        c=lerp(top[i+1],bottom[i+1],.72);e=lerp(top[i],bottom[i],.72)
        d.facet([a,b,c,e],1,0,'enamel')
    rows=[]
    for tier in range(1,d.tiers+1):
        t=tier/(d.tiers+1)
        pts=[lerp(a,b,t) for a,b in zip(top,bottom)]
        d.path([core,pts[n]],6.0,0,0,.95) if math.dist(core,pts[n])>1e-6 else None
        d.path(pts,4.4 if tier%2 else 6.5,2 if tier%2 else 0,0,.95)
        rows.append(pts)
    # Jewels and straps are explicitly joined to the band edges and rows.
    gemcenters=[]
    for i in range(0,2*n+1,2):
        mid=lerp(top[i],bottom[i],.5)
        d.path([top[i],mid,bottom[i]],8.5,0,0,.93)
        gemcenters.append(mid)
        if i!=n:
            jewel_scale=(1.,.85,1.65,1.2)[band]
            d.gem(mid,(10+(i%3)*2)*jewel_scale,(16+(i%2)*3)*jewel_scale,1,0)
        for rowpts in rows:
            if i%4==0:d.node(rowpts[i],3.1,'orb',2,0)
    # Connected lower pearl scallops enrich the whole lower perimeter.
    for i in range(0,2*n,2):
        a=bottom[i];b=bottom[i+2];mid=bottom[i+1]
        q=[mid[0],mid[1]+22+(st%3)*3]
        d.curve(a,[a[0]+16,a[1]+20],[q[0]-15,q[1]+3],q,5.2,0,0,.74)
        d.curve(q,[q[0]+16,q[1]+3],[b[0]-16,b[1]+20],b,5.2,0,0,.74)
        d.node(q,4.5,'orb',2,0)

    if _special_upper(d,st,mode,band,top,core,band_width,top0,rise):
        return d.finish()

    peaks=[];roots=[];shafts=[]
    for j in range(n):
        index=2*j+1;root=top[index];u=(2*j/(n-1)-1) if n>1 else 0
        peakx=u*(355 if st not in (2,4,7) else 396)
        peaky=_profile(st,u,j,n,v)*rise
        if v<9 and band==2:peakx+=math.copysign(18*abs(u),u) if u else 0
        peak=[peakx,peaky];peaks.append(peak);roots.append(root)
        left=top[index-1];right=top[index+1]
        width=(22 if st not in (1,6,9) else 25)-(2 if j%2 else 0)
        group=j+1
        # Broad royal point shoulders, unlike the abandoned narrow conical rods.
        spacing=(right[0]-left[0])
        broad=spacing*(.57 if mode!=1 else .48)
        shoulder_y=peak[1]+(112 if st not in (3,4,9) else 87)
        sl=[peak[0]-broad,shoulder_y];sr=[peak[0]+broad,shoulder_y]
        chest=lerp(root,peak,.39)
        d.facet([left,sl,peak,sr,right,root],0,group)
        insetleft=lerp(sl,chest,.30);insetright=lerp(sr,chest,.30)
        d.facet([root,insetleft,lerp(peak,chest,.30),insetright],1,group,'enamel')
        if st in (1,6,9):
            knee=[root[0]*.75+peak[0]*.25,top0-75-abs(u)*18]
            shaft=d.path([root,knee,[peakx,peaky+65],peak],width,0,group,.57,True,4.0)
            # Sample the angular shaft explicitly for rich attached decoration.
            decorated=[root,lerp(root,knee,.5),knee,lerp(knee,shaft[-2],.38),
                       lerp(knee,shaft[-2],.66),shaft[-2],peak]
            d.g['paths'][-1]['points']=decorated;shaft=decorated
        else:
            bow=(36 if st in (3,4,7) else 16)*math.copysign(1,u or (-1 if j%2 else 1))
            shaft=d.curve(root,[root[0]+bow,top0-99],
                          [peak[0]-bow*.4,peak[1]+116],peak,width,0,group,.57,True,4.1)
        shafts.append(shaft)
        if st in (1,6,9):
            d.path([left,sl,peak,sr,right],13.5 if st!=9 else 17,0,group,.84)
        else:
            d.curve(left,lerp(left,sl,.50),[sl[0],sl[1]+35],sl,13.5,0,group,.86)
            d.curve(sl,[sl[0],sl[1]-38],[peak[0]-23,peak[1]+18],peak,13.5,0,group,.86)
            d.curve(peak,[peak[0]+23,peak[1]+18],[sr[0],sr[1]-38],sr,13.5,0,group,.86)
            d.curve(sr,[sr[0],sr[1]+35],lerp(right,sr,.50),right,13.5,0,group,.86)
        # Enamel liner shares both endpoints with its main shaft.
        mid=shaft[len(shaft)//2]
        d.curve(root,[root[0]+18,root[1]-91],[mid[0]+13,mid[1]-26],peak,
                4.0,2,group,.55)
        # Two acanthus branch tiers, without repetitive U-shaped collars.
        if len(shaft)==7:indices=(1,3)
        else:indices=(3,7)
        for k,ix in enumerate(indices):
            q=shaft[ix]
            tangent=[shaft[min(ix+1,len(shaft)-1)][a]-shaft[max(0,ix-1)][a] for a in (0,1)]
            length=math.hypot(*tangent);axis=[x/length for x in tangent]
            reach=min(66,band_width/n*.87)*(1-.14*k)*(1+.07*(v%3))
            for hand in (-1,1):
                d.scroll(q,axis,reach,hand,group,0 if k%2 else 2,True)
            if (j+k+v)%3==0:d.node(q,5.5,'junction',1,group)
        # The centre and alternating tines carry substantial faceted jewels.
        d.node(peak,9.5 if j!=n//2 else 13.5,'orb',2,group)
        if j==n//2 or (j+st+mode)%3==0:
            q=shaft[-2]
            d.gem(q,12 if j==n//2 else 8.5,22 if j==n//2 else 15,1,group)
        if st in (3,4,8) or mode==2:
            # Fleur/scroll finials are attached to the existing peak itself.
            for hand in (-1,1):
                span=38 if st==3 or mode==2 else 29
                e=[peak[0]+hand*span,peak[1]+30]
                fin=d.curve(peak,[peak[0]+hand*span*.70,peak[1]-24],
                            [e[0]+hand*13,e[1]+11],e,9.2,0,group,.45,True,3.7)
                d.facet([peak,fin[5],e],0,group)
        elif st==2:
            for hand in (-1,1):
                e=[peak[0]+hand*21,peak[1]+43]
                d.path([peak,e],6.4,2,group,.4,True,3.3)
    # The sawtooth crown crest is a recognisable large-scale feature. It joins
    # neighbouring tines instead of leaving unrelated rods beside one another.
    for j,(a,b) in enumerate(zip(peaks,peaks[1:])):
        q=[(a[0]+b[0])/2,min(a[1],b[1])+150+(24 if st in (4,7) else 0)]
        if st in (1,5):
            d.curve(a,[a[0]+25,a[1]+100],[q[0]-21,q[1]-37],q,10,0,j+1,.7)
            d.curve(q,[q[0]+21,q[1]-37],[b[0]-25,b[1]+100],b,10,0,j+2,.7)
        elif st in (4,7):
            d.curve(a,[a[0]+38,a[1]+104],[q[0]-25,q[1]-11],q,11,0,j+1,.7)
            d.curve(q,[q[0]+25,q[1]-11],[b[0]-38,b[1]+104],b,11,0,j+2,.7)
        else:d.path([a,q,b],12,0,j+1,.82)
        d.node(q,6.4,'orb',1,j+1)
        # A secondary crest sprig fills the valley without erasing the teeth.
        stem=d.path([q,[q[0],q[1]-38]],5.4,0,j+1,.48,True,3.4)
        for hand in (-1,1):
            e=[q[0]+hand*18,q[1]-20]
            d.path([q,e],4,2,j+1,.45,True,2.7)
        # A substantial joined S-vine fills each inter-point bay with genuine
        # branching ornament rather than a stack of collars on isolated tines.
        base=top[2*j+2]
        vine=d.curve(base,[base[0]+(-28 if j%2 else 28),base[1]-91],
                     [q[0]+(24 if j%2 else -24),q[1]+79],q,8.1,0,j+1,.65)
        for tier,ix in enumerate((3,7,10)):
            origin=vine[ix]
            axis=[vine[ix+1][k]-vine[ix-1][k] for k in (0,1)]
            length=math.hypot(*axis);axis=[x/length for x in axis]
            span=min(55,band_width/n*.62)*(1-.12*tier)
            for hand in (-1,1):
                d.scroll(origin,axis,span,hand,j+1,0 if tier%2 else 2,branching=tier!=2)

    # Subtype-specific large architecture, not just small repeated ornaments.
    if st==5:
        # Paired crossed vaults turn the open coronet into a closed imperial crown.
        l,r=top[0],top[-1];p=[0,-399*rise]
        d.path([peaks[n//2],p],18,0,31,.8)
        domeleft=d.curve(l,[-389,-180],[-202,-399*rise],p,25,0,31,.8)
        domeright=d.curve(p,[202,-399*rise],[389,-180],r,25,0,32,.8)
        # A closed imperial crown has a substantial velvet/enamel cap, rather
        # than an empty wire hemisphere. Keep it behind the front point panels.
        d.g['facets'].insert(0,dict(points=domeleft+domeright[1:]+list(reversed(top)),
                                  color=1,group=31,material='enamel'))
        d.curve(top[3],[-209,-148],[-83,-364*rise],p,15,0,33,.8)
        d.curve(p,[83,-364*rise],[209,-148],top[-4],15,0,34,.8)
        for arch in [domeleft,domeright]:
            for ix in (3,6,9):
                d.node(arch[ix],6.5,'orb',2,31)
                tangent=[arch[ix+1][a]-arch[ix-1][a] for a in (0,1)]
                length=math.hypot(*tangent);axis=[x/length for x in tangent]
                for hand in (-1,1):d.scroll(arch[ix],axis,49,hand,31,0,branching=False)
        d.node(p,17,'orb',2,31)
    elif st==8:
        # Three substantial connected front medallions establish triple regalia.
        for ix in (n//2-2,n//2,n//2+2):
            ix=max(0,min(n-1,ix));q=shafts[ix][len(shafts[ix])//2]
            d.node(q,36 if ix==n//2 else 29,'junction',0,ix+1)
            d.gem(q,17,28,1,ix+1)
    elif st==7:
        # Sculpted wing scrolls stay attached to the band corners.
        for hand,root in [(-1,top[0]),(1,top[-1])]:
            outer=[hand*430,top0-107]
            wing=d.curve(root,[hand*437,top0+3],[hand*442,top0-72],outer,15,0,35,.5,True,4)
            for ix in (3,6,9):
                q=wing[ix];e=[q[0]-hand*36,q[1]-27]
                d.curve(q,[q[0]-hand*17,q[1]-3],[e[0],e[1]+11],e,6,2,35,.5,True,3)
    elif st==9:
        for j,shaft in enumerate(shafts):
            q=shaft[len(shaft)//2]
            d.gem(q,31,61,1,j+1)

    # Large central band gem and royal cross-shaped crest. The true hub remains
    # in the band, so the fixed-core depth animation has an intentional anchor.
    d.node(core,37,'hub',0,0)
    centerpeak=p if st==5 else peaks[n//2]
    q=[centerpeak[0],centerpeak[1]-27]
    d.path([centerpeak,q],10,0,n//2+1,.75)
    d.path([[q[0]-14,q[1]+8],[q[0],q[1]+8],[q[0]+14,q[1]+8]],6.2,2,n//2+1,.9)
    d.path([q,[q[0],q[1]+8]],6.2,2,n//2+1,.9)
    d.node(q,6.4,'orb',2,n//2+1)
    d.g['main_assemblies']=n
    d.g['variant_composition']=f'{n}-point {SUBTYPES["Crown"][st]} / '+('upright','broad layered','high ornate','deep-layered')[band]
    return d.finish()


def _selftest():
    hashes=set();maxpaths=0
    for st in range(10):
        for v in range(10):
            g=build('Crown',st,v,760000+st*100+v)
            maxpaths=max(maxpaths,len(g['paths']))
            assert len(g['paths'])>=80,(st,v,'underdesigned',len(g['paths']))
            adj=defaultdict(set)
            for rec in g['paths']:
                for a,b in zip(rec['points'],rec['points'][1:]):
                    assert all(math.isfinite(x) for x in a+b)
                    assert math.dist(a,b)>1e-7
                    aa,bb=tuple(round(x,5) for x in a),tuple(round(x,5) for x in b)
                    adj[aa].add(bb);adj[bb].add(aa)
            remaining=set(adj);hubs=[n for n in g['nodes'] if n['style']=='hub']
            while remaining:
                seen={next(iter(remaining))};queue=list(seen)
                while queue:
                    for q in adj[queue.pop()]:
                        if q not in seen:seen.add(q);queue.append(q)
                assert any(math.dist(p,n['pos'])<=n['radius']+1 for p in seen for n in hubs),(st,v,'disconnected')
                remaining-=seen
            for obj in g['tips']+g['nodes']:
                assert min(math.dist(obj['pos'],p) for p in adj)<1e-4,(st,v,'detached node',obj)
                assert max(map(abs,obj['pos']))+obj['radius']<=460,(st,v,'bounds')
            for p in g['paths']:
                assert max(max(map(abs,q)) for q in p['points'])+p['width']*.65<=460
            h=hashlib.sha256(json.dumps({k:g[k] for k in ['paths','tips','nodes','rings','facets']},sort_keys=True).encode()).hexdigest()
            assert h not in hashes;hashes.add(h)
    print('Crown selftest passed',len(hashes),'unique crowns; max paths',maxpaths)


if __name__=='__main__':
    _selftest()
