from pathlib import Path
import json,sys
from build_collection import FAMILIES,modules,palette,inset,fingerprint,sculpture_fit
ROOT=Path(__file__).resolve().parents[1]
lookup=modules();items=[];out=ROOT/'internal/pilot_geometry';out.mkdir(parents=True,exist_ok=True)
for family in sys.argv[1:]:
 ident=FAMILIES.index(family)*100+10;seed=27002601+ident*7919;g=inset(sculpture_fit(lookup[family].build(family,0,9,seed)),.94)
 path=f'internal/pilot_geometry/{ident:04d}.json';(ROOT/path).write_text(json.dumps(g)+'\n')
 prefix=f'ForgePass_V3_{ident:04d}_{family}_Volumetric'
 items.append({'id':ident,'family':family,'name':f'Forge Pass #{ident:04d}','tier':'Volumetric','subtype_index':0,'subtype_name':g['subtype_name'],'variant':9,'seed':seed,'palette':palette(family,0,9),'geometry_file':path,'geometry_sha256':fingerprint(g),'png':f'Volumetric/{prefix}.png','gif':f'Volumetric/{prefix}.gif'})
(ROOT/'internal/Pilot_Collection.json').write_text(json.dumps({'items':items},indent=2)+'\n');print('Prepared pilots',sys.argv[1:])
