"""Resumable PNG/GIF production with export validation and bounded frame caches."""
from pathlib import Path
import os,json,time,hashlib,subprocess,shutil,traceback,concurrent.futures,argparse
os.environ['OMP_NUM_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np
from PIL import Image
from render_art import Renderer,canonical,COUNT
ROOT=Path(__file__).resolve().parents[1]
PIPELINE=hashlib.sha256((Path(__file__).parent/'render_art.py').read_bytes()+(Path(__file__).parent/'style.py').read_bytes()).hexdigest()
def sha(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def save(path,data):
 path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_suffix('.tmp');temp.write_text(json.dumps(data,indent=2)+'\n');temp.replace(path)
def previous(item,kind):
 path=ROOT/'artwork'/item[kind];report=ROOT/'internal/reports'/f"{item['id']:04d}_{kind}.json"
 if report.exists() and path.exists():
  data=json.loads(report.read_text())
  if data.get('geometry_sha256')==item['geometry_sha256'] and data.get('pipeline_sha256')==PIPELINE and data['sha256']==sha(path):return data
 return None

def still(item):
 old=previous(item,'png')
 if old:return old
 started=time.time();g=json.loads((ROOT/item['geometry_file']).read_text());r=Renderer(g,item)
 im=r.render(60,2048,2);path=ROOT/'artwork'/item['png'];path.parent.mkdir(parents=True,exist_ok=True)
 temp=path.with_suffix('.working.png');im.save(temp,compress_level=5)
 with Image.open(temp) as check:check.load();assert check.size==(2048,2048) and check.mode=='RGB'
 temp.replace(path);im.thumbnail((320,320),Image.Resampling.LANCZOS)
 im.save(ROOT/'internal/thumbnails'/f"{item['id']:04d}.jpg",quality=93)
 data={'id':item['id'],'file':item['png'],'geometry_sha256':item['geometry_sha256'],'pipeline_sha256':PIPELINE,'bytes':path.stat().st_size,'sha256':sha(path),'size':[2048,2048],'mode':'RGB','seconds':round(time.time()-started,2)}
 save(ROOT/'internal/reports'/f"{item['id']:04d}_png.json",data);return data

def call(command):
 result=subprocess.run(command,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
 if result.returncode:raise RuntimeError(result.stderr.decode(errors='replace')[-1800:])
def animate(item):
 old=previous(item,'gif')
 if old:return old
 started=time.time();g=json.loads((ROOT/item['geometry_file']).read_text());r=Renderer(g,item)
 work=ROOT/'internal/frames'/f"{item['id']:04d}";work.mkdir(parents=True,exist_ok=True)
 cache={'geometry_sha256':item['geometry_sha256'],'pipeline_sha256':PIPELINE}
 cachefile=work/'Cache.json'
 if cachefile.exists() and json.loads(cachefile.read_text())!=cache:
  shutil.rmtree(work);work.mkdir()
 save(cachefile,cache)
 # Sinusoidal open/close movement has 121 distinct poses over 240 timeline frames.
 # Sharing identical poses saves render time without changing the 20 fps timeline.
 for c in range(-60,61):
  p=work/f'u_{c+60:03d}.png'
  if not p.exists():r.render(c).save(p,compress_level=1)
 for f in range(COUNT):
  p=work/f'{f:04d}.png';source=work/f'u_{canonical(f)+60:03d}.png'
  if not p.exists():os.link(source,p)
 rendered=time.time();palette=work/'palette.png';output=work/'output.gif'
 base=['ffmpeg','-hide_banner','-loglevel','error','-y','-threads','1','-filter_threads','1']
 for colours in [256,192,128,96,64]:
  call(base+['-framerate','20','-i',str(work/'%04d.png'),'-vf',f'palettegen=max_colors={colours}:reserve_transparent=0:stats_mode=full','-frames:v','1','-update','1',str(palette)])
  call(base+['-framerate','20','-i',str(work/'%04d.png'),'-i',str(palette),'-filter_complex_threads','1','-filter_complex','[0:v][1:v]paletteuse=dither=none:diff_mode=rectangle','-loop','0','-final_delay','5',str(output)])
  if output.stat().st_size<50_000_000:break
 assert output.stat().st_size<50_000_000,'Oversized GIF'
 encoded=time.time();poses={};hub_reference=None;elapsed=0;targets=[0,1,60,120,180,239]
 crops=[]
 for hub in r.hubs:
  x=round((hub['pos'][0]+512)*1000/1024);y=round((hub['pos'][1]+512)*1000/1024);half=max(1,min(6,round(hub['radius']*.13)))
  crops.append((x-half,y-half,x+half,y+half))
 with Image.open(output) as im:
  assert im.size==(1000,1000) and im.info.get('loop')==0
  encoded_count=im.n_frames
  for f in range(encoded_count):
   im.seek(f);im.load();duration=im.info.get('duration',0);assert duration>=50 and duration%50==0
   rgb=im.convert('RGB');cores=[np.array(rgb.crop(box)) for box in crops]
   if hub_reference is None:hub_reference=cores
   else:assert all(np.array_equal(a,b) for a,b in zip(cores,hub_reference)),'Fixed hub core changes'
   for target in targets:
    if elapsed<=target*50<elapsed+duration:poses[target]=np.array(rgb,dtype=np.int16)
   elapsed+=duration
 assert elapsed==12000,(encoded_count,elapsed)
 assert np.array_equal(np.array(r.render(0)),np.array(r.render(COUNT))),'Native endpoint mismatch'
 delta=lambda a,b:float(np.abs(poses[a]-poses[b]).mean())
 seam=delta(239,0);step=delta(0,1);visible=delta(60,180)
 changed=int((np.abs(poses[60]-poses[180]).max(axis=2)>15).sum())
 assert seam<max(.5,step*1.85),(seam,step)
 assert visible>.45 and changed>2000,('Insufficient visible movement',visible,changed)
 path=ROOT/'artwork'/item['gif'];path.parent.mkdir(parents=True,exist_ok=True);output.replace(path)
 data={'id':item['id'],'file':item['gif'],'geometry_sha256':item['geometry_sha256'],'pipeline_sha256':PIPELINE,'bytes':path.stat().st_size,'sha256':sha(path),'size':[1000,1000],'source_frames':240,'distinct_rendered_poses':121,'encoded_frames':encoded_count,'duration_ms':elapsed,'fps':20,'loop':0,'palette_colours':colours,'native_loop_endpoints_identical':True,'fixed_hub_interiors_checked':len(crops),'fixed_hub_interiors_stable':True,'loop_seam_delta':seam,'ordinary_step_delta':step,'open_vs_merged_delta':visible,'open_vs_merged_changed_pixels':changed,'motion_profile':r.mode,'render_seconds':round(rendered-started,2),'encode_seconds':round(encoded-rendered,2),'total_seconds':round(time.time()-started,2)}
 save(ROOT/'internal/reports'/f"{item['id']:04d}_gif.json",data);shutil.rmtree(work);return data

def main():
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['stills','animations']);p.add_argument('--workers',type=int,default=4);p.add_argument('--ids',default='');p.add_argument('--exclude-families',default='');p.add_argument('--manifest',type=Path,default=ROOT/'Collection.json');args=p.parse_args()
 for folder in ['internal/thumbnails','internal/reports','internal/frames','artwork/Preview','artwork/Volumetric']:
  (ROOT/folder).mkdir(parents=True,exist_ok=True)
 items=json.loads(args.manifest.read_text())['items']
 if args.exclude_families:
  excluded=set(args.exclude_families.split(','));items=[i for i in items if i['family'] not in excluded]
 if args.ids:
  ids=set(map(int,args.ids.split(',')));items=[i for i in items if i['id'] in ids]
 if args.mode=='animations':items=[i for i in items if i['tier']=='Volumetric']
 errors=[];done=0
 with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
  futures={pool.submit(still if args.mode=='stills' else animate,i):i for i in items}
  for f in concurrent.futures.as_completed(futures):
   item=futures[f]
   try:
    data=f.result();done+=1
    print(json.dumps({'done':item['id'],'family':item['family'],'subtype':item['subtype_name'],'mode':args.mode,'completed':done,'of':len(items),'bytes':data['bytes'],'seconds':data.get('total_seconds',data.get('seconds'))}),flush=True)
   except Exception:
    detail=traceback.format_exc();errors.append({'id':item['id'],'error':detail});print(detail,flush=True)
 if errors:save(ROOT/'internal'/f'{args.mode}_errors.json',errors);raise RuntimeError(f'{len(errors)} artworks failed')
 print('COMPLETE',args.mode,len(items),flush=True)
if __name__=='__main__':main()
