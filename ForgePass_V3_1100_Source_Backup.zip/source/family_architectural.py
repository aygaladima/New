"""Dense architectural Forge Pass compositions: Circuit, Lattice and Trident.

New edition geometry, deliberately rebuilt around substantial filled silhouettes.
Every ornamental fork originates on an emitted parent vertex. Standard library only.
"""
from __future__ import annotations
import math,random,json,hashlib,collections,copy
FAMILIES=('Circuit','Lattice','Trident')
SUBTYPES={
'Circuit':('Reactor Motherboard','Circuit Cathedral','Twin Processors','Hexagonal Switchyard','Square Citadel','Circuit Canopy','Spiral Busworks','Diamond Relays','Orbital Processors','Circuit Metropolis'),
'Lattice':('Diamond Citadel','Woven Matrix','Hexagonal Truss','Hourglass Weave','Twin Frame Bridge','Lattice Tower','Offset Crystal Mesh','Triangular Scaffold','Crosswing Tessellation','Nested Cages'),
'Trident':('Sovereign Tine','Opposed Forks','Triune Engine','Cruciform Tridents','Stacked Scepters','Crown of Tines','Twin-Pylon Bridge','Triangular Citadel','Nested Harpoons','Diagonal Spearworks')}

def pt(p):return [round(float(p[0]),6),round(float(p[1]),6)]
def polar(r,a):a=math.radians(a);return [r*math.cos(a),r*math.sin(a)]
def local(root,a,u,v):
 a=math.radians(a);co,si=math.cos(a),math.sin(a)
 return pt([root[0]+u*co-v*si,root[1]+u*si+v*co])
def lerp(a,b,t):return pt([a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t])
class D:
 def __init__(self,f,s,v,seed):
  self.f=f;self.v=v;self.rng=random.Random(seed)
  self.g={'name':f,'subtype_name':SUBTYPES[f][s],'description':'Dense sculptural architecture with attached ornamental branching and articulated metal rails.','layout':'','main_assemblies':0,'paths':[],'tips':[],'rings':[],'nodes':[],'facets':[],'anchor_points':{}}
 def path(self,points,w=10,col=0,group=0,taper=.7,tip=False,r=3.8):
  q=[]
  for p in points:
   p=pt(p)
   if not q or math.dist(p,q[-1])>1e-6:q.append(p)
  if len(q)<2:raise ValueError('degenerate rail')
  self.g['paths'].append(dict(points=q,width=float(w),taper=float(taper),color=int(col),group=int(group)))
  self.g['anchor_points'].setdefault(str(group),q[0])
  if tip:self.g['tips'].append(dict(pos=q[-1],radius=float(r),color=2,group=group))
  return q
 def node(self,p,r=12,style='junction',col=0,group=0):
  self.g['nodes'].append(dict(pos=pt(p),radius=float(r),style=style,color=col,group=group))
 def facet(self,points,col=0,group=0):self.g['facets'].append(dict(points=[pt(p) for p in points],color=col,group=group))
 def ring(self,r,w=3.5,segments=6,gap=12,start=-90,col=1,center=(0,0)):
  self.g['rings'].append(dict(center=pt(center),radius=float(r),width=float(w),segments=segments,gap=float(gap),start=float(start),color=col))
 def core(self,p=(0,0),r=43,group=0,col=0):self.node(p,r,'hub',col,group)
 def finish(self,layout,assemblies):
  self.g['layout']=layout;self.g['main_assemblies']=assemblies
  ext=0
  for q in self.g['paths']:ext=max(ext,*(max(abs(x),abs(y))+q['width']*.6+9 for x,y in q['points']))
  for q in self.g['nodes']+self.g['tips']:ext=max(ext,max(map(abs,q['pos']))+q['radius']+8)
  for q in self.g['rings']:ext=max(ext,max(map(abs,q['center']))+q['radius']+q['width']+7)
  for q in self.g['facets']:ext=max(ext,*(max(map(abs,p))+4 for p in q['points']))
  factor=448/max(1,ext)
  # Deterministic coherent fitting preserves all exact shared vertices.
  for q in self.g['paths']+self.g['facets']:
   q['points']=[pt([x*factor,y*factor]) for x,y in q['points']]
   if 'width' in q:q['width']*=factor
  for q in self.g['nodes']+self.g['tips']:q['pos']=pt([x*factor for x in q['pos']]);q['radius']*=factor
  for q in self.g['rings']:q['center']=pt([x*factor for x in q['center']]);q['radius']*=factor;q['width']*=factor
  self.g['anchor_points']={k:pt([x*factor for x in p]) for k,p in self.g['anchor_points'].items()}
  return self.g

def chip(d,c,r,group,col=0):
 # Rectilinear chip packages and four connected port tabs.
 p=[pt([c[0]-r,c[1]-r]),pt([c[0]+r,c[1]-r]),pt([c[0]+r,c[1]+r]),pt([c[0]-r,c[1]+r])]
 d.facet(p,col,group);d.path(p+[p[0]],max(2.5,r*.24),col,group,taper=1)
 # The interior cross attaches the package to its actual bus vertex.
 d.path([p[0],c,p[2]],max(2.2,r*.15),1,group,taper=.9)
 d.node(c,r*.40,'orb',2,group)

def circuit_panel(d,root,a,length,spread,group,v,width=22):
 levels=(3,4,5)[v%3];style=v//3
 fractions=[0]+[.19+i*.61/(levels-1) for i in range(levels)]+[1]
 spine=[local(root,a,length*t,0) for t in fractions]
 # Machined board body gives the routing a real substrate, not an airy wire ladder.
 board=[local(root,a,length*.13,-spread*.68),local(root,a,length*.81,-spread*.68),local(root,a,length*.98,-spread*.31),local(root,a,length*.98,spread*.31),local(root,a,length*.81,spread*.68),local(root,a,length*.13,spread*.68)]
 d.facet(board,1,group)
 d.facet([spine[0],board[0],board[-1]],0,group)
 d.path(spine,width,0,group,taper=.73)
 for i,q in enumerate(spine[1:-1]):
  u=length*fractions[i+1]
  reach=spread*(.9-.13*i/max(1,levels-1))
  for sign in (-1,1):
   skew=(1 if (i+style)%2 else -1)*length*.055
   side=reach*(1.08 if (i+v+sign)%3==0 else .92)
   elbow=local(root,a,u,sign*side*.47)
   corner=local(root,a,u+length*.15+skew,sign*side*.47)
   end=local(root,a,u+length*.15+skew,sign*side)
   branch=d.path([q,elbow,corner,end],max(5.8,width*.44),1 if (i+sign)%3 else 0,group,taper=.69,tip=True,r=3.8)
   # Two distinct daughter tracks attach at the actual right-angle junctions.
   for k,start in enumerate(branch[1:2] if spread<105 and length<375 else branch[1:3]):
    bump=(.13+.035*((i+v+k)%3))*length
    side2=side*(.76 if k else .25)
    end2=local(root,a,u+length*.15+skew+bump,sign*side2)
    turn=pt([end2[0],start[1]]) if abs(math.sin(math.radians(a)))<.01 else local(root,a,u+length*.15+skew+bump,sign*side*(.47 if k else .47))
    # Work in the panel's local axes even for rotated circuit arms.
    start_u=u if k==0 else u+length*.15+skew
    trace=d.path([start,local(root,a,start_u+bump,sign*side*.47),end2],max(2.4,width*.18),2 if (k+i+v)%3==0 else 0,group,taper=.62,tip=True,r=2.8)
    if (i+k+v)%4==0:chip(d,trace[-1],max(5.5,width*.29),group,1)
   if i%2==style%2:d.node(q,max(6,width*.33),'junction',1,group)
 d.node(spine[-1],max(10,width*.59),'junction',0,group)
 return spine

def circuit(st,v,seed):
 d=D('Circuit',st,v,seed);mode=v%3;band=v//3
 if st in (0,3):
  arms=((4,6,8)[mode] if st==0 else (6,8,10)[mode]);phase=(-90,-67.5,-90)[min(2,band)]
  for i in range(arms):circuit_panel(d,(0,0),phase+i*360/arms,330+(i%2)*18,185 if arms<=4 else (130 if arms<=6 else 95),i+1,v,23)
  chip(d,(0,0),58,0);d.core(r=43);d.ring(448,5,arms,12,col=0)
  if band==1:d.ring(404,2.3,arms*2,10,col=2)
  return d.finish('radial connected motherboard' if st==0 else 'radial hexagonal switchyard',arms)
 if st==1:
  q=circuit_panel(d,(0,350),-90,720,175,1,v,30)
  for side in (-1,1):
   for j,ix in enumerate((2,len(q)-3)):
    circuit_panel(d,q[ix],0 if side==1 else 180,230-j*25,94,2+j*2+(side==1),v+int(side==1) if v<8 else v,17)
  chip(d,(0,350),45,0);d.core((0,350),36)
  d.ring(447,3.5,4,36,col=1)
  return d.finish('upright circuit cathedral',5)
 if st==2:
  roots=[[-190,260],[190,260]]
  d.path([roots[0],[0,320],roots[1]],26,0,0)
  for i,q in enumerate(roots):circuit_panel(d,q,-90,625,151,i+1,v,28);chip(d,q,40,i+1);d.core(q,31,i+1)
  for j in range(2+mode):
   y=220-j*135
   p=[-190,y];q=[190,y]
   # Bridges anchor to the actual roots, so no independent decorative islands.
   d.path([roots[0],[-190,y],q,roots[1]],5.8,1,0,taper=1)
  d.ring(446,3,4,39,col=2)
  return d.finish('twin upright processor bridge',2)
 if st in (4,7):
  rotate=45 if st==7 else 0
  vertices=[local((0,0),rotate,*p) for p in [(-290,-290),(0,-290),(290,-290),(290,0),(290,290),(0,290),(-290,290),(-290,0)]]
  d.path(vertices+[vertices[0]],24,0,0,taper=1)
  for i,ix in enumerate((1,3,5,7)):
   q=vertices[ix];d.path([(0,0),q],22,0,i+1)
   # Outward and inward branch banks fill the framed board.
   circuit_panel(d,q,rotate+(-90+i*90),125,95,i+1,v,15)
   circuit_panel(d,(0,0),rotate+(-90+i*90),210,90,i+5,v,19)
   chip(d,q,28,i+1)
  for k in range(4):circuit_panel(d,(0,0),rotate-45+k*90,274,79,12+k,v,16)
  chip(d,(0,0),57,0);d.core(r=39)
  if mode:d.ring(447,3.1,8,20,col=2)
  return d.finish('diamond relay citadel' if st==7 else 'square board citadel',8)
 if st==5:
  levels=(3,4,5)[mode];ys=[300-i*560/(levels-1) for i in range(levels)]
  d.path([[0,390]]+[[0,y] for y in ys]+[[0,-390]],29,0,0)
  for i,y in enumerate(ys):
   for side in (-1,1):circuit_panel(d,(0,y),0 if side==1 else 180,320-i*24,75,1+i*2+(side==1),v,19)
  chip(d,(0,390),39,0);d.core((0,390),31);d.ring(448,3,6,28,col=1)
  return d.finish('branching circuit canopy',levels*2)
 if st==6:
  # A genuinely rectangular spiral bus carrying attached circuit growth.
  points=[(0,0),(115,0),(115,-115),(-115,-115),(-115,150),(180,150),(180,-215),(-250,-215),(-250,285),(315,285),(315,-345),(-365,-345)]
  spine=d.path(points,25,0,0,taper=.8)
  for a,b in zip(spine,spine[1:]):
   length=math.dist(a,b)
   if length>180:
    normal=[-(b[1]-a[1])/length*29,(b[0]-a[0])/length*29]
    d.facet([[a[0]+normal[0],a[1]+normal[1]],[b[0]+normal[0],b[1]+normal[1]],[b[0]-normal[0],b[1]-normal[1]],[a[0]-normal[0],a[1]-normal[1]]],1,0)
    middle=lerp(a,b,.5);d.path([a,middle,b],7,1,0,taper=1);chip(d,middle,18,0,0)
  for i,q in enumerate(spine[2:-1]):
   angle=[-90,180,90,0][i%4]
   circuit_panel(d,q,angle,125+(i%2)*40,65,1+i,v,13)
  chip(d,(0,0),51,0);d.core(r=36);d.ring(450,3.5,8,20,col=2)
  return d.finish('spiral bus network',9)
 if st==8:
  count=(6,8,10)[mode];centers=[polar(292,-90+i*360/count) for i in range(count)]
  for i,c in enumerate(centers):
   d.path([(0,0),lerp((0,0),c,.53),c,centers[(i+1)%count]],18,0,i+1)
   circuit_panel(d,c,-90+i*360/count,110,81,i+1,v,15)
   chip(d,c,29,i+1,1)
  for i,c in enumerate(centers):
   mid=lerp((0,0),c,.53)
   for sign in (-1,1):
    end=local(mid,-90+i*360/count,48,sign*54)
    d.path([mid,local(mid,-90+i*360/count,48,0),end],5.8,1,count+i+1,tip=True,r=3)
   chip(d,mid,15,count+i+1,1)
  d.core(r=45);d.ring(444,5,12,12,col=0)
  return d.finish('orbital processors with connected inner bus',count)
 cores=[[-210,185],[205,185],[0,-185]]
 d.path([cores[0],cores[1],cores[2],cores[0]],22,1,0,taper=1)
 for i,c in enumerate(cores):
  for j,a in enumerate((-90,30,150)):
   circuit_panel(d,c,a+i*20,205,85,i*3+j+1,v,18)
  chip(d,c,44,i+1);d.core(c,31,i+1)
 d.ring(449,3.2,6,24,col=2)
 return d.finish('offset circuit metropolis',9)

def mesh(d,center,width,height,n,group,v,angle=0,warp=None,core=True):
 # Dense square/diamond tessellation; all braces share exact emitted vertices.
 points={}
 for iy in range(n):
  for ix in range(n):
   x=-width/2+ix*width/(n-1);y=-height/2+iy*height/(n-1)
   if warp is not None:x,y=warp(x,y)
   points[ix,iy]=local(center,angle,x,y)
 for iy in range(n):d.path([points[ix,iy] for ix in range(n)],8.8 if iy in (0,n-1) else 5.4,iy%2,group,taper=1)
 for ix in range(n):d.path([points[ix,iy] for iy in range(n)],8.8 if ix in (0,n-1) else 5.4,ix%2,group,taper=1)
 for iy in range(n-1):
  for ix in range(n-1):
   a,b=(points[ix,iy],points[ix+1,iy+1]) if (ix+iy+v)%2 else (points[ix+1,iy],points[ix,iy+1])
   d.path([a,b],4.2,1 if (ix+v)%2 else 0,group,taper=1)
   if (ix+iy+v)%3==0:d.facet([points[ix,iy],points[ix+1,iy],points[ix+1,iy+1]],2 if ix%3==0 else 1,group)
 for iy in range(n):
  for ix in range(n):
   if (ix+iy)%3==0:d.node(points[ix,iy],7.2,'junction',2,group)
 hub=points[n//2,n//2]
 if core:d.core(hub,28,group)
 return points,hub

def triangle_mesh(d,corners,n,group,v,core=False):
 a,b,c=corners;ps={}
 for row in range(n+1):
  for col in range(row+1):ps[row,col]=pt([(1-row/n)*a[k]+(row-col)/n*b[k]+col/n*c[k] for k in (0,1)])
 for row in range(n+1):
  if row:d.path([ps[row,j] for j in range(row+1)],9 if row==n else 5.3,row%2,group,taper=1)
  if row<n:
   for j in range(row+1):
    for offset in (0,1):d.path([ps[row,j],ps[row+1,j+offset]],5.2 if j not in (0,row) else 8.5,(j+row)%2,group,taper=1)
    if (j+row+v)%3==0:d.facet([ps[row,j],ps[row+1,j],ps[row+1,j+1]],1,group)
 for (row,col),p in ps.items():
  if row%2==0 and col%2==0:d.node(p,6.7,'junction',2,group)
 if core:
  point=min(ps.values(),key=lambda p:math.hypot(*p));d.core(point,34,group)
 return ps

def polygon_mesh(d,c,r,count,layers,group,v):
 rings=[]
 for layer in range(1,layers+1):
  rad=r*layer/layers;current=[local(c,-90+i*360/count,rad,0) for i in range(count)];rings.append(current)
  d.path(current+[current[0]],10 if layer==layers else 6.7,layer%2,group,taper=1)
  for i,q in enumerate(current):
   p=c if layer==1 else rings[-2][i]
   d.path([p,q],7.2,0,group,taper=1)
   if layer>1:
    other=rings[-2][(i+1 if (i+v)%2 else i-1)%count]
    d.path([other,q],4.3,1,group,taper=1)
    if (i+layer)%3==0:d.facet([p,q,other],1,group)
   if layer==layers or (i+layer)%4==0:d.node(q,8 if layer==layers else 6,'junction',2,group)
 d.core(c,36,group)
 return rings

def lattice(st,v,seed):
 d=D('Lattice',st,v,seed);mode=v%3;band=v//3;n=(7,9,11)[mode]
 if st in (0,1,3,6):
  angle=45 if st in (0,6) else 0
  width,height=(565,565) if st==0 else ((730,730) if st==1 else ((730,760) if st==3 else (650,535)))
  if band==1:width*=.85;height*=1.09
  if band==2:width*=1.10;height*=.88
  warp=(lambda x,y:(x*(.27+.73*abs(y)/(height/2)),y)) if st==3 else ((lambda x,y:(x+y*.24,y)) if st==6 else None)
  ps,c=mesh(d,(0,0),width,height,n,1,v,angle,warp)
  # Strong external corner branches keep the boundary sculptural, not a flat diagram.
  for ix,iy,a in [(0,0,-135),(n-1,0,-45),(n-1,n-1,45),(0,n-1,135)]:
   root=ps[ix,iy];tip=local(root,a,61,0)
   d.path([root,tip],12,0,1,tip=True,r=5)
   for side in (-1,1):d.path([root,local(root,a,29,side*39),tip],4.5,1,1)
  d.ring(451,3.2,8,24,col=2)
  return d.finish(('diamond woven citadel','square woven matrix','hourglass woven span','offset diagrid crystal')[{0:0,1:1,3:2,6:3}[st]],1)
 if st==2:
  count=(12,18,24)[mode];layers=3+min(2,band)
  polygon_mesh(d,(0,0),406,count,layers,1,v)
  # Larger hexagonal exoskeleton makes the triangulated family silhouette explicit.
  frame=[polar(420,-90+i*60) for i in range(6)]
  d.path(frame+[frame[0]],17,0,1,taper=1)
  # Attach exoskeleton vertices to the centre through real braces.
  for q in frame:d.path([(0,0),q],11,1,1)
  return d.finish('hexagonal tessellated truss',1)
 if st in (4,9):
  centers=[[-207,0],[207,0]] if st==4 else [[0,-205],[0,205]]
  roots=[]
  for i,c in enumerate(centers):
   if st==4:
    warp=(lambda x,y:(x*(.67+.33*abs(y)/282.5),y)) if band==1 else ((lambda x,y:(x+y*y/565*.18,y)) if band>=2 else None)
    ps,h=mesh(d,c,335,565,(5,7,9)[mode],i+1,v,0,warp)
   else:polygon_mesh(d,c,217,(8,12,16)[mode],3+min(2,band),i+1,v);h=c
   roots.append(h)
  d.path(roots,22,0,0,taper=1)
  # Crossed connecting braces across the two substantial cages.
  for k in (-1,1):
   a=pt([centers[0][0]+(0 if st==4 else k*120),centers[0][1]+(k*180 if st==4 else 0)])
   b=pt([centers[1][0]+(0 if st==4 else -k*120),centers[1][1]+(-k*180 if st==4 else 0)])
   d.path([roots[0],a,b,roots[1]],5,1,0,taper=1)
  d.ring(450,3.3,4,39,col=2)
  return d.finish('twin frame woven bridge' if st==4 else 'vertical stacked lattice cages',2)
 if st==5:
  levels=6+mode*2+band*3;ys=[340-i*690/(levels-1) for i in range(levels)];rows=[]
  for i,y in enumerate(ys):
   half=190-75*i/(levels-1);rows.append([[-half,y],[0,y],[half,y]])
   d.path(rows[-1],17 if i in(0,levels-1) else 9,i%2,1,taper=1)
   if i:
    for j in range(3):d.path([rows[i-1][j],rows[i][j]],10,0,1)
    for j in range(2):d.path([rows[i-1][j],rows[i][j+1]],5.2,1,1);d.path([rows[i-1][j+1],rows[i][j]],5.2,1,1)
   for q in (rows[-1][0],rows[-1][-1]):
    side=-1 if q[0]<0 else 1;tip=[q[0]+side*(130-i*5),y-43]
    d.path([q,[tip[0],y],tip],8.1,1,1,tip=True,r=4)
    d.path([q,[tip[0]*.8,y-18],tip],3.8,2,1)
  d.core(rows[0][1],43,1)
  d.ring(448,3.2,4,35,col=2)
  return d.finish('upright woven lattice tower',levels)
 if st==7:
  triangle_mesh(d,[[(-70,0,70,35)[band],-410],[-398,331],[398,331]],(7,9,11)[mode],1,v,True)
  d.ring(448,3.4,3,39,col=2)
  return d.finish('dense triangular scaffold',1)
 # Four dense triangular fan wings share their root vertex exactly.
 for k in range(4):
  corners=[(0,0),local((0,0),-90+k*90,402,-(126+band*22)),local((0,0),-90+k*90,402,126+band*22)]
  triangle_mesh(d,corners,(4,5,6)[mode],k+1,v)
 d.core(r=45);d.ring(447,3.8,8,19,col=2)
 return d.finish('four tessellated crosswing fans',4)

def trident_head(d,root,a,length,spread,group,v,width=24,shaft=True):
 """Exactly three articulated main prongs, each carrying attached barb systems."""
 mode=v%3;levels=(3,4,5)[mode];band=v//3
 P=lambda u,z:local(root,a,u,z)
 # Local forward axis leads from the lower handle toward the three spear tips.
 fractions=[0]+[.14+i*.48/(2+min(band,3)) for i in range(3+min(band,3))]
 spine=[P(length*t,0) for t in fractions]
 if shaft:d.path(spine,width,0,group,taper=.87)
 else:d.path(spine,max(14,width*.85),0,group,taper=.88)
 shoulder=spine[-1]
 for side in (-1,0,1):
  if side:
   bends=[shoulder,P(length*.68,side*spread*.66),P(length*.85,side*spread),P(length,side*spread*.92)]
  else:bends=[shoulder,P(length*.76,0),P(length*.91,0),P(length*1.08,0)]
  prong=d.path(bends,width*1.18,0 if side==0 else 1,group,taper=.36,tip=True,r=4.5)
  if side:
   # Broad forged shoulder cheek and an attached open-work head panel.
   cheek=[P(length*.59,side*spread*.10),P(length*.66,side*spread*.77),P(length*.81,side*spread*1.09),P(length*.91,side*spread*.99),P(length*.78,side*spread*.76),P(length*.68,side*spread*.29)]
   d.facet(cheek,1,group)
   d.path([shoulder,cheek[1],cheek[2],prong[2]],width*.23,2,group,taper=.7)
   d.path([shoulder,P(length*.73,side*spread*.23),P(length*.83,side*spread*.44),prong[1]],width*.26,2,group,taper=.68)
   d.path([prong[1],P(length*.83,side*spread*.57),P(length*.94,side*spread*.68),prong[2]],width*.22,0,group,taper=.63)
   d.facet([shoulder,P(length*.73,side*spread*.23),prong[1]],0,group)
  else:
   d.facet([shoulder,P(length*.83,-width*.76),prong[-1],P(length*.83,width*.76)],0,group)
   for hand in (-1,1):d.path([shoulder,P(length*.81,hand*width*.53),prong[-1]],width*.13,2,group,taper=.45)
  # Bladed tine facets retain an unmistakably forged three-prong silhouette.
  tip=prong[-1];before=prong[-2];dx,dy=tip[0]-before[0],tip[1]-before[1];norm=math.hypot(dx,dy);nx,ny=-dy/norm,dx/norm
  bladebase=lerp(before,tip,.15)
  d.facet([tip,pt([bladebase[0]+nx*width*.6,bladebase[1]+ny*width*.6]),before,pt([bladebase[0]-nx*width*.6,bladebase[1]-ny*width*.6])],2,group)
  # Existing articulation vertices receive three-way ornament rather than random new islands.
  for j,q in enumerate(prong[1:-1]):
   for hand in (-1,1):
    spread2=spread*(.20+.035*((mode+j)%3));forward=length*(.09+.018*((v+j)%3))
    end=P((.68 if j==0 else .85)*length+forward,side*spread*(.66 if j==0 else 1)+hand*spread2) if side else P((.76 if j==0 else .91)*length+forward,hand*spread2)
    knee=lerp(q,end,.55);knee=pt([knee[0]+nx*hand*9,knee[1]+ny*hand*9])
    branch=d.path([q,knee,end],max(4.2,width*.25),1 if hand<0 else 2,group,taper=.46,tip=True,r=3.1)
    if (j+v+side)%2==0:
     e=local(branch[1],a,length*.055,hand*spread*.16)
     d.path([branch[1],e],max(2.7,width*.13),0,group,taper=.45,tip=True,r=2.4)
  d.node(prong[1],max(6,width*.34),'junction',2,group)
 # Handle and shoulder are equally designed: paired ribs, engraved collars, root wings.
 for i,q in enumerate(spine[1:-1]):
  u=length*fractions[i+1]
  for hand in (-1,1):
   end=P(u+length*.055,hand*spread*(.42+.035*mode))
   wing=d.path([q,P(u,hand*spread*.23),end],width*.37,1,group,taper=.49,tip=True,r=3.5)
   d.path([wing[1],P(u-length*.055,hand*spread*.34)],width*.17,2,group,taper=.55,tip=True,r=2.5)
  d.node(q,max(7,width*.39),'junction',2,group)
 d.node(shoulder,max(9,width*.5),'junction',1,group)
 # Flanking engraved rails attach directly to handle vertices at both ends.
 for hand in (-1,1):
  d.path([spine[0],P(length*.10,hand*width*.72),P(length*.48,hand*width*.72),spine[-1]],max(3.2,width*.15),1,group,taper=.75)
 return spine

def trident(st,v,seed):
 d=D('Trident',st,v,seed);mode=v%3;band=v//3
 if st in (0,8,9):
  root=[0,355];a=-90 if st!=9 else -52;length=690 if st!=9 else 650;spread=(228,264,294)[mode]
  spine=trident_head(d,root,a,length,spread,1,v,31)
  d.core(root,47,1)
  if st in (0,9):
   # Broad engraved guard fins occupy the previously bare middle shaft.
   # Each branch starts on the real shaft vertex; blade facets give the
   # ornament mid-scale body rather than a scatter of tiny base forks.
   q=spine[2]
   for hand in (-1,1):
    stem=[q,local(q,a,length*.055,hand*spread*.36),
          local(q,a,length*.18,hand*spread*.64),
          local(q,a,length*.27,hand*spread*.73)]
    fin=d.path(stem,14,1,10+(hand==1),taper=.48,tip=True,r=4.3)
    inside=local(q,a,length*.19,hand*spread*.28)
    d.facet([q,fin[1],fin[2],inside],0,10+(hand==1))
    d.path([q,inside,fin[2]],5.6,2,10+(hand==1),taper=.7)
    for j,at in enumerate(fin[1:3]):
     end=local(at,a,length*(.075+.024*j),hand*spread*(.19+.035*mode))
     branch=d.path([at,local(at,a,length*.034,hand*spread*.11),end],
                   6.6-j*.8,2 if j else 0,10+(hand==1),taper=.43,tip=True,r=3.1)
     d.path([branch[1],local(branch[1],a,length*.07,-hand*spread*.12)],
            3.2,1,10+(hand==1),taper=.45,tip=True,r=2.5)
  if st==8:
   # Nested visible harpoons with their own exact attached starting point.
   q=spine[2]
   for side in (-1,1):trident_head(d,q,a+side*17,length*.54,spread*.65,2+(side==1),v,17,False)
  else:
   # Two subsidiary tridents grow from the lower shaft into the lower quadrants.
   for side in (-1,1):trident_head(d,spine[1],a+side*75,length*.39,spread*.39,2+(side==1),v,17,False)
  d.ring(445,4.2,3,36,col=1)
  if band==1:d.ring(401,2.8,6,23,col=2)
  return d.finish('diagonal ornamental trident' if st==9 else ('nested forged harpoons' if st==8 else 'sovereign three-prong sceptre'),3)
 if st==1:
  root=[0,0]
  # Two genuinely opposed heads create a double-ended ceremonial weapon.
  # The former vertical secondary heads made this a second four-way cross.
  axis=-27+band*5
  for i,a in enumerate((axis,axis+180)):
   trident_head(d,root,a,405,(211,236,257)[mode],i+1,v,28)
  # A broad six-sided guard and its engraved ribs carry the centre mass.
  guard=[local(root,axis,u,z) for u,z in [(-122,0),(-70,-106),(70,-106),
                                       (122,0),(70,106),(-70,106)]]
  d.facet(guard,0,0);d.path(guard+[guard[0]],9.5,1,0,taper=1)
  for j,q in enumerate(guard):
   d.path([root,q],5.4,2 if j%2 else 1,0,taper=.68)
   d.node(q,8.5,'junction',2,0)
  d.core(r=48);d.ring(444,3.6,4,37,col=1)
  return d.finish('two opposed diagonal forged tridents with an engraved centre guard',2)
 if st in (2,3):
  count=3 if st==2 else 4
  for i in range(count):trident_head(d,(0,0),-90+i*360/count,365,(130,156,182)[mode],i+1,v,23)
  d.core(r=51);d.ring(445,4.5,count*2,18,col=1)
  return d.finish('triune engine' if st==2 else 'cruciform three-prong assemblies',count)
 if st==4:
  roots=[[0,350],[0,95],[0,-155]]
  d.path(roots,28,0,0)
  for i,q in enumerate(roots):
   trident_head(d,q,-90,265 if i<2 else 235,285-i*52,i+1,v,24-i*2)
   d.node(q,26,'junction',2,i+1)
  d.core(roots[0],43,0);d.ring(447,4,6,25,col=1)
  return d.finish('stacked richly ornamented trident sceptres',3)
 if st==5:
  root=[0,310]
  trident_head(d,root,-90,650,150,1,v,29)
  for i,a in enumerate((-145,-35)):
   trident_head(d,root,a,580,131,i+2,v,22)
  d.core(root,48);d.ring(447,3.5,3,44,col=2)
  return d.finish('fan of three unmistakable three-prong spears',3)
 if st==6:
  roots=[[-205,320],[205,320]]
  d.path([roots[0],[0,370],roots[1]],28,0,0)
  for i,q in enumerate(roots):trident_head(d,q,-90,660,158,i+1,v,26);d.core(q,39,i+1)
  for level in range(2+mode):
   a=[-205,242-level*95];b=[205,242-level*95]
   d.path([roots[0],a,b,roots[1]],5.6,1,0,taper=1)
  d.ring(447,3.5,4,34,col=2)
  return d.finish('twin ornamented trident pylon bridge',2)
 # Three fully articulated trident heads at a triangular connected citadel.
 cores=[polar(150,-90+i*120) for i in range(3)]
 d.path(cores+[cores[0]],24,0,0,taper=1)
 for c in cores:d.path([(0,0),c],11,1,0)
 d.node((0,0),23,'junction',2,0)
 for i,c in enumerate(cores):
  trident_head(d,c,-90+i*120,265,141,i+1,v,22)
  d.core(c,35,i+1)
 d.ring(448,4,6,22,col=1)
 return d.finish('triangular forged trident citadel',3)

PREVIEW_PROFILES=(
 'singular balanced sculpture','tall articulated sculpture','broad articulated sculpture',
 'linked horizontal twin sculptures','linked vertical twin sculptures',
 'linked three-sculpture triptych','linked triangular triad',
 'linked four-corner sculpture court','linked four-cardinal sculpture cross')

def preview_architecture(g,family,subtype,variant):
 """Nine readable construction profiles; never called for Volumetric geometry.

 A Preview variant must change the composition at ordinary viewing size. Earlier
 trace-count changes left several same-layout pairs effectively identical. Each
 subtype now keeps its characteristic panel/mesh/three-prong construction while
 changing its substantial body proportions or number and arrangement of bodies.
 Every replicated body retains a real hub and is connected through emitted hub
 vertices. Large framing halos are added once, not cloned as a mass of rings.
 """
 if variant==0:return g
 d=D(family,subtype,variant,0)
 d.g['description']=g['description']+' Preview construction: '+PREVIEW_PROFILES[variant]+'.'
 if variant in (1,2):
  # Real aspect changes affect all shared body vertices coherently. The original
  # level/arm counts still vary between these two profiles as well.
  sx,sy=(.63,1.16) if variant==1 else (1.16,.63)
  placements=[((0,0),sx,sy)]
 elif variant==3:placements=[((-225,0),.53,.53),((225,0),.53,.53)]
 elif variant==4:placements=[((0,-225),.53,.53),((0,225),.53,.53)]
 elif variant==5:placements=[((-296,0),.36,.49),((0,0),.36,.49),((296,0),.36,.49)]
 elif variant==6:placements=[((0,-245),.46,.46),((-245,210),.46,.46),((245,210),.46,.46)]
 elif variant==7:placements=[((-223,-223),.44,.44),((223,-223),.44,.44),((223,223),.44,.44),((-223,223),.44,.44)]
 else:placements=[((0,-285),.38,.38),((285,0),.38,.38),((0,285),.38,.38),((-285,0),.38,.38)]
 hubs=[]
 for index,(offset,sx,sy) in enumerate(placements):
  def move(p):return pt([p[0]*sx+offset[0],p[1]*sy+offset[1]])
  scale=min(sx,sy);group_offset=(index+1)*1000
  for key in ('paths','facets'):
   for original in g[key]:
    rec=copy.deepcopy(original);rec['points']=[move(p) for p in rec['points']]
    rec['group']=rec.get('group',0)+group_offset
    if key=='paths':rec['width']*=scale
    d.g[key].append(rec)
  for key in ('nodes','tips'):
   for original in g[key]:
    rec=copy.deepcopy(original);rec['pos']=move(rec['pos']);rec['radius']*=scale;rec['group']=rec.get('group',0)+group_offset
    d.g[key].append(rec)
  for original in g['rings']:
   if original['radius']>=180:continue
   rec=copy.deepcopy(original);rec['center']=move(rec['center']);rec['radius']*=scale;rec['width']*=scale;d.g['rings'].append(rec)
  for key,p in g.get('anchor_points',{}).items():d.g['anchor_points'][str(int(key)+group_offset)]=move(p)
  local_hubs=[n for n in g['nodes'] if n['style']=='hub']
  center=min(local_hubs,key=lambda n:math.hypot(*n['pos']))['pos']
  hubs.append(move(center))
 if len(hubs)>1:
  # Main connecting rails are part of the family construction, not loose marks.
  edges=[(k,k+1) for k in range(len(hubs)-1)]
  if variant in (6,7):edges.append((len(hubs)-1,0))
  if variant==8:
   d.core((0,0),35,0)
   edges=[]
   for h in hubs:
    d.path([(0,0),h],18,0,0,taper=.94)
  for ia,ib in edges:
   a,b=hubs[ia],hubs[ib]
   if family=='Circuit':
    middle=[(a[0]+b[0])/2,a[1]];endturn=[middle[0],b[1]]
    rail=[a,middle,lerp(a,b,.5),endturn,b]
    # The substrate under an orthogonal trunk remains visibly machined.
    d.path(rail,25,1,0,taper=1);d.path(rail,11,0,0,taper=1)
   else:
    d.path([a,lerp(a,b,.5),b],17 if family=='Trident' else 13,0,0,taper=1)
   if family=='Lattice':
    # Large linked mesh structures carry an actual open truss between hubs.
    mid=lerp(a,b,.5);dx,dy=b[0]-a[0],b[1]-a[1];length=max(1,math.hypot(dx,dy));normal=[-dy/length*29,dx/length*29]
    top=pt([mid[k]+normal[k] for k in range(2)]);bottom=pt([mid[k]-normal[k] for k in range(2)])
    d.path([a,top,b,bottom,a],5.5,1,0,taper=1)
   else:
    chip(d,lerp(a,b,.5),15,0,1) if family=='Circuit' else d.node(lerp(a,b,.5),12,'junction',2,0)
 # The nine Preview profiles also have different framing counts, but the body
 # composition above is sufficient to distinguish them without these halos.
 for original in g['rings']:
  if original['radius']<180:continue
  rec=copy.deepcopy(original)
  if len(placements)==1:
   # Circular frames stay circular around the transformed solid body.
   rec['radius']=max(rec['radius'],444)
  else:rec['radius']=448;rec['segments']=(4,6,3,3,4,8)[variant-3]
  d.g['rings'].append(rec)
  break
 return d.finish(g['layout']+' / '+PREVIEW_PROFILES[variant],g['main_assemblies']*len(placements))

def build(family,subtype,variant,seed):
 if family not in FAMILIES or subtype not in range(10) or variant not in range(10):raise ValueError((family,subtype,variant))
 g={'Circuit':circuit,'Lattice':lattice,'Trident':trident}[family](subtype,variant,int(seed))
 return g if variant==9 else preview_architecture(g,family,subtype,variant)

def visual_hash(g):return hashlib.sha256(json.dumps({k:g[k] for k in ['paths','tips','nodes','rings','facets']},sort_keys=True,separators=(',',':')).encode()).hexdigest()
def validate(g):
 assert g['paths'];adj=collections.defaultdict(set)
 for rec in g['paths']:
  assert rec['width']>0 and 0<rec['taper']<=1
  for p in rec['points']:assert all(math.isfinite(x) for x in p) and max(map(abs,p))+rec['width']*.5<461
  for a,b in zip(rec['points'],rec['points'][1:]):
   a,b=tuple(a),tuple(b);assert math.dist(a,b)>1e-6;adj[a].add(b);adj[b].add(a)
 hubs=[n for n in g['nodes'] if n['style']=='hub'];assert hubs
 remaining=set(adj)
 while remaining:
  start=next(iter(remaining));seen={start};queue=[start]
  while queue:
   for q in adj[queue.pop()]:
    if q not in seen:seen.add(q);queue.append(q)
  assert any(math.dist(v,h['pos'])<h['radius']+1 for v in seen for h in hubs),'unanchored component'
  remaining-=seen
 for rec in g['tips']:
  assert tuple(rec['pos']) in adj,'unattached tip'
 for rec in g['nodes']:
  assert tuple(rec['pos']) in adj or any(math.dist(rec['pos'],q)<rec['radius'] for q in adj),'unattached node'
 for rec in g['rings']:assert max(map(abs,rec['center']))+rec['radius']+rec['width']<461
 return True

def selftest():
 hashes=set();counts=[]
 for fi,f in enumerate(FAMILIES):
  for st in range(10):
   for v in range(10):
    g=build(f,st,v,930000+fi*10000+st*100+v);validate(g);h=visual_hash(g);assert h not in hashes,(f,st,v,'duplicate');hashes.add(h);counts.append(len(g['paths']))
 print('VALID',len(hashes),'path range',min(counts),max(counts))
if __name__=='__main__':selftest()
