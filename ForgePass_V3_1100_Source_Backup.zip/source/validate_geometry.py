"""Validate exact production geometry and measure sculpture footprint without halos."""
from pathlib import Path
import json,hashlib,math,collections
from PIL import Image,ImageDraw
from build_collection import fingerprint
ROOT=Path(__file__).resolve().parents[1]
def main():
 manifest=ROOT/'Collection.json';items=json.loads(manifest.read_text())['items'];records=[]
 assert len(items)==1100
 for i in items:
  g=json.loads((ROOT/i['geometry_file']).read_text());assert fingerprint(g)==i['geometry_sha256']
  adj=collections.defaultdict(set);points=[]
  for p in g['paths']:
   assert p['width']>0 and 0<p['taper']<=2
   for q in p['points']:
    assert all(math.isfinite(v) for v in q)
    assert max(map(abs,q))+p['width']/2<481,(i['id'],'rail outside safe frame')
   a=[tuple(round(v,5) for v in q) for q in p['points']]
   for x,y in zip(a,a[1:]):
    assert math.dist(x,y)>1e-7,(i['id'],'zero segment');adj[x].add(y);adj[y].add(x)
   points.extend(p['points'])
  vertices=set(adj)
  for n in g['tips']:
   assert tuple(round(v,5) for v in n['pos']) in vertices,(i['id'],'detached terminal')
  for n in g['nodes']+g['tips']:
   assert max(map(abs,n['pos']))+n['radius']<486,(i['id'],'node outside safe frame')
  for ring in g['rings']:
   assert max(map(abs,ring['center']))+ring['radius']+ring['width']<499,(i['id'],'ring outside safe frame')
  cores=[n for n in g['nodes'] if n['style']=='hub'];remaining=set(adj);components=0
  while remaining:
   start=next(iter(remaining));seen={start};q=[start]
   while q:
    for v in adj[q.pop()]:
     if v not in seen:seen.add(v);q.append(v)
   remaining-=seen;components+=1
   if cores:assert any(math.dist(v,n['pos'])<=n['radius']+1.5 for v in seen for n in cores),(i['id'],'unanchored component')
  if not cores:assert components==1,(i['id'],'disconnected coreless network')
  mask=Image.new('L',(256,256));draw=ImageDraw.Draw(mask);xy=lambda p:((p[0]+512)/4,(p[1]+512)/4)
  for p in g['paths']:draw.line([xy(q) for q in p['points']],fill=255,width=max(1,round(p['width']/4)),joint='curve')
  for f in g.get('facets',[]):
   assert all(all(math.isfinite(x) for x in q) for q in f['points'])
   draw.polygon([xy(q) for q in f['points']],fill=255)
  for n in g['nodes']+g['tips']:
   x,y=xy(n['pos']);r=n['radius']/4;draw.ellipse((x-r,y-r,x+r,y+r),fill=255)
  bbox=mask.getbbox();coverage=sum(mask.histogram()[1:])/65536
  records.append({'id':i['id'],'family':i['family'],'paths':len(g['paths']),'facets':len(g.get('facets',[])),'components':components,'body_width_px_at1024':(bbox[2]-bbox[0])*4,'body_height_px_at1024':(bbox[3]-bbox[1])*4,'body_area_fraction_excluding_halos':round(coverage,4),'geometry_sha256':i['geometry_sha256']})
 summary={'complete':True,'artwork_count':1100,'collection_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'all_exact_production_geometries_valid':True,'all_terminals_attached':True,'all_components_anchored':True,'footprint_metrics_are_advisory_not_substitutes_for_visual_review':True,'records':records}
 (ROOT/'internal/Geometry_Validation.json').write_text(json.dumps(summary,indent=2)+'\n')
 print('Validated',len(records),'production geometries')
 for family in dict.fromkeys(i['family'] for i in items):
  a=[v for v in records if v['family']==family];print(family,'paths',min(v['paths'] for v in a),max(v['paths'] for v in a),'minbodyW/H',min(v['body_width_px_at1024'] for v in a),min(v['body_height_px_at1024'] for v in a),'minarea',min(v['body_area_fraction_excluding_halos'] for v in a),flush=True)
if __name__=='__main__':main()
