#!/usr/bin/env python3
"""Plan, publish, or verify the Forge Pass 1,100 downloadable collection.

Default --mode plan is local and read-only. --mode publish operates only on the
explicit authorized collection branch, adds immutable delivery files in batches
of at most 400 MB, and verifies public downloads. It never force-pushes, replaces
an unknown file, changes artwork, or performs NFT/wallet actions. --mode verify
downloads and validates files without committing or pushing.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import errno
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from urllib.parse import quote
import zipfile

from package_collection import (ARTWORK_COUNT, BASE_URL, BRANCH, GIF_COUNT, MEDIA_COUNT,
                                PNG_COUNT, TIER_COUNTS, ZIP_LIMIT, check_art_archive,
                                require, safe_relative, sha256)

INITIAL_BASE = "cf61b6325f246aa70038413360b7926789534b1e"
MAX_BATCH_BYTES = 400_000_000
SAFE_NAME = re.compile(r"[A-Za-z0-9_.-]+\Z")
ALLOWED_ORIGINS = {
    "https://github.com/abbas719/new.git", "https://github.com/abbas719/new",
    "git@github.com:abbas719/new.git", "https://github.com/aygaladima/new.git",
    "https://github.com/aygaladima/new", "git@github.com:aygaladima/new.git",
}


def timestamp():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(prefix=".forge-state-", dir=path.parent, mode="w", encoding="utf-8", delete=False) as stream:
        temporary = Path(stream.name)
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
    try:
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def git(repo, *arguments, allow_failure=False):
    env = dict(os.environ, GIT_TERMINAL_PROMPT="0")
    options = ["-c", "pack.window=0", "-c", "pack.threads=2"] if arguments and arguments[0] == "push" else []
    result = subprocess.run(["git", *options, *arguments], cwd=repo, env=env,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode and not allow_failure:
        # Credential-helper error text is deliberately not copied into reports.
        raise RuntimeError(f"Git {arguments[0]} failed (exit {result.returncode}); inspect authentication or network "
                           "access locally. No force-push attempted.")
    return result


def git_text(repo, *arguments):
    return git(repo, *arguments).stdout.decode("utf-8").strip()


def remote_head(repo, missing_ok=False):
    response = git_text(repo, "ls-remote", "origin", f"refs/heads/{BRANCH}")
    if not response and missing_ok:
        return None
    fields = response.split()
    require(len(fields) == 2 and re.fullmatch(r"[0-9a-f]{40,64}", fields[0])
            and fields[1] == f"refs/heads/{BRANCH}", "Collection remote branch is missing or ambiguous")
    return fields[0]


def check_repo(repo):
    require(git_text(repo, "branch", "--show-current") == BRANCH,
            f"Worktree must already be on authorized branch {BRANCH}")
    origin = git_text(repo, "config", "--get", "remote.origin.url")
    require(origin.lower() in ALLOWED_ORIGINS, "Unexpected repository origin; refusing delivery")
    require(not git_text(repo, "diff", "--name-only"), "Tracked working-tree edits exist; review them first")
    require(not git_text(repo, "diff", "--cached", "--name-only"), "Staged changes exist; review them first")
    return git_text(repo, "rev-parse", "HEAD")


def blob_hash(repo, revision, filename):
    name = f"{revision}:{filename}"
    if git(repo, "cat-file", "-e", name, allow_failure=True).returncode:
        return None
    process = subprocess.Popen(["git", "cat-file", "blob", name], cwd=repo,
                               stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    try:
        result = sha256(process.stdout)
        require(process.wait() == 0, f"Could not read tracked delivery blob: {filename}")
        return result
    finally:
        process.stdout.close()
        if process.poll() is None:
            process.terminate()
            process.wait()


def check_zip(path, item):
    if "artworks" in item:
        check_art_archive(path, item["artworks"])
    else:
        with zipfile.ZipFile(path) as archive:
            require(archive.testzip() is None, f"ZIP CRC failure: {path.name}")
            require(all(not safe_relative(info.filename).is_absolute() for info in archive.infolist()),
                    f"Unsafe backup member: {path.name}")


def load_delivery_files(root, verify_local_hashes=True):
    packages = root / "packages"
    manifest = json.loads((packages / "Package_Manifest.json").read_text(encoding="utf-8"))
    require(manifest.get("schema") == "forge-pass-v3-package-manifest-v1"
            and str(manifest.get("art_direction_version", "")).startswith("V3"),
            "Only the V3 sculptural redesign may be delivered by this helper")
    require(manifest.get("artwork_count") == ARTWORK_COUNT and manifest.get("edition_size") == ARTWORK_COUNT
            and manifest.get("media_count") == MEDIA_COUNT and manifest.get("png_count") == PNG_COUNT
            and manifest.get("gif_count") == GIF_COUNT and manifest.get("tier_counts") == TIER_COUNTS
            and manifest.get("family_count") == 11 and manifest.get("validation_complete") is True
            and manifest.get("coverage_exactly_once") is True and manifest.get("animated_formats_kept_together") is True,
            "Package manifest does not describe the complete approved collection")
    require(manifest.get("publication_branch") == BRANCH and manifest.get("base_url") == BASE_URL,
            "Package manifest has unexpected publication destination")
    archives = manifest["archives"]
    require(archives, "No artwork archives")
    members = [member for archive in archives for member in archive["artworks"]]
    require(len(members) == MEDIA_COUNT and len({member["artifact"] for member in members}) == MEDIA_COUNT
            and len({member["sha256"] for member in members}) == MEDIA_COUNT,
            "Duplicate or missing packaged media")
    require(Counter(member["format"] for member in members) == Counter({"png": PNG_COUNT, "gif": GIF_COUNT})
            and Counter(member["tier"] for member in members) == Counter({"Preview": 990, "Volumetric": 220}),
            "Incorrect packaged formats or tier media counts")
    by_id, id_archives = defaultdict(list), defaultdict(set)
    for archive in archives:
        ids = sorted({member["id"] for member in archive["artworks"]})
        require(ids == archive["artwork_ids"] and len(ids) == archive["artwork_count"]
                and len(archive["artworks"]) == archive["media_count"], "Archive inventory metadata disagrees")
        require({member["family"] for member in archive["artworks"]} == {archive["family"]}, "Mixed-family archive")
        for member in archive["artworks"]:
            by_id[member["id"]].append(member)
            id_archives[member["id"]].add(archive["filename"])
            relative = safe_relative(member["artifact"])
            require(relative.parts[0] == member["tier"] and relative.suffix == "." + member["format"],
                    "Invalid packaged media path")
    require(set(by_id) == set(range(1, ARTWORK_COUNT + 1)) and all(len(names) == 1 for names in id_archives.values()),
            "Artworks are missing or their media formats were split across archives")
    families, subtypes, tiers = Counter(), defaultdict(Counter), Counter()
    for ident, records in by_id.items():
        require(len({(record["family"], record["tier"], record["subtype_index"], record["subtype_name"])
                     for record in records}) == 1, f"Artwork {ident} has inconsistent file associations")
        first = records[0]
        require(Counter(record["format"] for record in records)
                == Counter({"png": 1, **({"gif": 1} if first["tier"] == "Volumetric" else {})}),
                f"Artwork {ident} is missing a required format")
        require(first["tier"] in TIER_COUNTS and first["subtype_index"] in range(10), "Unknown tier or subtype")
        require(all(record["format"] != "gif" or record["bytes"] < 50_000_000 for record in records),
                "GIF exceeds the 50 MB limit")
        families[first["family"]] += 1
        tiers[first["tier"]] += 1
        subtypes[(first["family"], first["subtype_index"])][first["tier"]] += 1
    require(len(families) == 11 and set(families.values()) == {100} and tiers == Counter(TIER_COUNTS)
            and len(subtypes) == 110 and all(counts == Counter({"Preview": 9, "Volumetric": 1})
                                           for counts in subtypes.values()), "Family/subtype allocation differs")
    files = [dict(archive, kind="artwork_archive") for archive in archives]
    source = manifest.get("source_backup")
    require(source and source["bytes"] < 80_000_000, "Missing or oversized optional source backup")
    files.append(dict(source, kind="source_archive"))
    # Supporting files and the human index are always published after the media.
    files.extend(dict(review, kind="index") for review in manifest.get("review_files", []))
    names = manifest.get("index_files")
    require(names == ["Package_Manifest.json", "ForgePass_V3_1100_README.md", "ForgePass_V3_1100_Downloads.md"],
            "Unexpected index filename list")
    for name in names:
        path = packages / name
        files.append({"filename": name, "kind": "index", "bytes": path.stat().st_size,
                      "sha256": sha256(path), "url": BASE_URL + quote(name)})
    require(len({item["filename"] for item in files}) == len(files), "Duplicate delivery filenames")
    for item in files:
        name = item["filename"]
        require(SAFE_NAME.fullmatch(name) and item.get("url") == BASE_URL + quote(name),
                f"Unsafe filename or unexpected download URL: {name}")
        path = packages / name
        require(path.is_file() and not path.is_symlink() and 0 < path.stat().st_size == item["bytes"] < ZIP_LIMIT,
                f"Missing, changed, or oversized delivery file: {name}")
        if verify_local_hashes:
            require(sha256(path) == item["sha256"], f"Local delivery SHA256 differs: {name}")
    return manifest, files


def batch_files(files, byte_limit):
    require(ZIP_LIMIT <= byte_limit <= MAX_BATCH_BYTES, "Push batches must be between 95 and 400 MB")
    batches, current, size = [], [], 0
    for item in files:
        require(item["bytes"] <= byte_limit, "An individual file exceeds the push batch limit")
        if current and (size + item["bytes"] > byte_limit or item["kind"] != current[-1]["kind"]):
            batches.append(current)
            current, size = [], 0
        current.append(item)
        size += item["bytes"]
    if current:
        batches.append(current)
    return batches


def pending_commits(repo, remote, local, by_name, byte_limit):
    base = remote or INITIAL_BASE
    require(git(repo, "cat-file", "-e", f"{base}^{{commit}}", allow_failure=True).returncode == 0,
            "Remote branch has an unknown commit; fetch and review it before retrying")
    require(git(repo, "merge-base", "--is-ancestor", base, local, allow_failure=True).returncode == 0,
            "Collection branch diverged or is behind its remote; review before delivery")
    commits = git_text(repo, "rev-list", "--reverse", f"{base}..{local}").splitlines()
    for commit in commits:
        require(len(git_text(repo, "rev-list", "--parents", "-n", "1", commit).split()) == 2,
                "Unpushed merge/root commit requires review")
        changed = []
        for line in git_text(repo, "diff-tree", "--no-commit-id", "--name-status", "-r", commit).splitlines():
            fields = line.split("\t")
            require(len(fields) == 2 and fields[0] == "A" and fields[1] in by_name,
                    "Unpushed commit contains edits outside the immutable delivery")
            item = by_name[fields[1]]
            require(blob_hash(repo, commit, item["filename"]) == item["sha256"], "Unpushed delivery blob differs")
            changed.append(item)
        require(changed and sum(item["bytes"] for item in changed) <= byte_limit,
                "Unpushed commit is empty or exceeds the bounded upload size")
    return commits


def inspect_delivery(repo, files, byte_limit, check_remote=True):
    local = check_repo(repo)
    remote = remote_head(repo, missing_ok=True) if check_remote else None
    pending = pending_commits(repo, remote, local, {item["filename"]: item for item in files}, byte_limit)
    remaining = []
    for item in files:
        destination = repo / item["filename"]
        head_hash = blob_hash(repo, "HEAD", item["filename"])
        if head_hash is not None:
            require(head_hash == item["sha256"], f"Existing tracked file differs; preserving it: {item['filename']}")
        else:
            if destination.exists() or destination.is_symlink():
                require(destination.is_file() and not destination.is_symlink() and sha256(destination) == item["sha256"],
                        f"Existing untracked file differs; preserving it: {item['filename']}")
            remaining.append(item)
    return local, remote, pending, batch_files(remaining, byte_limit)


def push_commit(repo, commit, expected_remote):
    require(remote_head(repo, missing_ok=True) == expected_remote, "Remote changed; stopping without force-push")
    git(repo, "push", "origin", f"{commit}:refs/heads/{BRANCH}")
    require(remote_head(repo) == commit, "Remote HEAD did not match the uploaded commit")
    print(f"PUSHED {commit[:12]}", flush=True)
    return commit


def link_verified(source, destination, expected_sha):
    """Hardlink same-filesystem packages; copy only when cross-filesystem."""
    require(sha256(source) == expected_sha, f"Package changed before staging: {source.name}")
    if not destination.exists() and not destination.is_symlink():
        try:
            os.link(source, destination)
        except FileExistsError:
            pass
        except OSError as error:
            if error.errno != errno.EXDEV:
                raise
            with tempfile.NamedTemporaryFile(prefix=".forge-delivery-", dir=destination.parent, delete=False) as stream:
                temporary = Path(stream.name)
            try:
                shutil.copyfile(source, temporary)
                require(sha256(temporary) == expected_sha, "Cross-filesystem copy checksum differs")
                try:
                    os.link(temporary, destination)
                except FileExistsError:
                    pass
            finally:
                temporary.unlink(missing_ok=True)
    require(destination.is_file() and not destination.is_symlink() and sha256(destination) == expected_sha,
            f"Existing destination differs; preserving it: {destination.name}")


def publish(root, repo, files, byte_limit=MAX_BATCH_BYTES, state_dir=None):
    state_dir = state_dir or root / "internal" / "delivery"
    local, remote, pending, batches = inspect_delivery(repo, files, byte_limit)
    save_json(state_dir / "Publish_Plan.json", {
        "created_at": timestamp(), "branch": BRANCH, "starting_local_commit": local,
        "starting_remote_commit": remote, "pending_delivery_commits": pending, "batch_limit": byte_limit,
        "batches": [{"bytes": sum(item["bytes"] for item in batch),
                     "files": [item["filename"] for item in batch]} for batch in batches],
    })
    if remote is None:
        remote = push_commit(repo, INITIAL_BASE, None)
    for commit in pending:
        remote = push_commit(repo, commit, remote)
    for index, batch in enumerate(batches, 1):
        require(not git_text(repo, "diff", "--name-only") and not git_text(repo, "diff", "--cached", "--name-only"),
                "Worktree changed during delivery; review before continuing")
        require(git_text(repo, "rev-parse", "HEAD") == remote, "Local HEAD changed during delivery")
        for item in batch:
            link_verified(root / "packages" / item["filename"], repo / item["filename"], item["sha256"])
        filenames = [item["filename"] for item in batch]
        git(repo, "add", "--", *filenames)
        require(set(git_text(repo, "diff", "--cached", "--name-only").splitlines()) == set(filenames),
                "Unexpected staged files; stopping before commit")
        git(repo, "commit", "-m", f"Add Forge Pass V3 1100 delivery batch {index}/{len(batches)}")
        commit = git_text(repo, "rev-parse", "HEAD")
        remote = push_commit(repo, commit, remote)
        save_json(state_dir / "Publish_Progress.json", {"checked_at": timestamp(), "remote_commit": remote,
                                                        "last_batch": filenames})
    require(git_text(repo, "rev-parse", "HEAD") == remote_head(repo), "Local and remote HEAD differ after delivery")
    return remote


def download_one(item, remote_commit, directory):
    target = directory / item["filename"]
    command = ["curl", "--fail", "--location", "--silent", "--show-error", "--max-time", "300",
               "--connect-timeout", "30", "--retry", "2", "--retry-delay", "2",
               "--proto", "=https", "--proto-redir", "=https", "--output", str(target),
               "--write-out", "%{http_code}", item["url"]]
    try:
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        require(result.returncode == 0 and result.stdout.decode().strip() == "200",
                f"Public download failed for {item['filename']} (curl {result.returncode})")
        require(target.is_file() and target.stat().st_size == item["bytes"], f"Downloaded byte count differs: {item['filename']}")
        require(sha256(target) == item["sha256"], f"Downloaded SHA256 differs: {item['filename']}")
        is_zip = item["filename"].endswith(".zip")
        if is_zip:
            check_zip(target, item)
        return {"status": "verified", "filename": item["filename"], "bytes": item["bytes"],
                "sha256": item["sha256"], "url": item["url"], "remote_commit": remote_commit,
                "checked_at": timestamp(), "http_status": 200, "zip_crc_verified": is_zip,
                "artwork_member_hashes_verified": "artworks" in item}
    finally:
        # The target lives inside a uniquely owned TemporaryDirectory only.
        target.unlink(missing_ok=True)


def verify(repo, files, state_dir, jobs=2, force=False):
    require(jobs in (1, 2), "Remote verification is bounded to one or two concurrent downloads")
    check_repo(repo)
    commit = remote_head(repo)
    cache_path = state_dir / "Remote_Verification.json"
    try:
        old = json.loads(cache_path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        old = {}
    cached = old.get("files", {})
    records = {item["filename"]: cached[item["filename"]] for item in files
               if not force and cached.get(item["filename"], {}).get("status") == "verified"
               and all(cached[item["filename"]].get(key) == value for key, value in
                       (("remote_commit", commit), ("sha256", item["sha256"]),
                        ("bytes", item["bytes"]), ("url", item["url"])))}
    pending = [item for item in files if item["filename"] not in records]
    state = {"branch": BRANCH, "remote_commit": commit, "complete": False, "expected_files": len(files),
             "checked_at": timestamp(), "files": records}
    save_json(cache_path, state)
    print(f"VERIFY {len(pending)} downloads, {len(records)} cached, {jobs} concurrent", flush=True)
    errors = []
    with tempfile.TemporaryDirectory(prefix="forge-downloads-", dir=state_dir) as temporary:
        with ThreadPoolExecutor(max_workers=jobs) as pool:
            futures = {pool.submit(download_one, item, commit, Path(temporary)): item for item in pending}
            for future in as_completed(futures):
                item = futures[future]
                try:
                    records[item["filename"]] = future.result()
                    print(f"VERIFIED {item['filename']} {item['bytes']:,} bytes", flush=True)
                except Exception as error:
                    errors.append(f"{item['filename']}: {error}")
                    print(f"VERIFY FAILED {item['filename']}: {error}", flush=True)
                state["checked_at"] = timestamp()
                save_json(cache_path, state)
    require(remote_head(repo) == commit, "Remote branch changed during verification; rerun to refresh evidence")
    state.update(complete=not errors and len(records) == len(files), errors=errors, verified_files=len(records),
                 verified_bytes=sum(record["bytes"] for record in records.values()), checked_at=timestamp())
    save_json(cache_path, state)
    require(state["complete"], f"{len(errors)} public verification failures; successful checks are cached")
    return state


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--repo", type=Path, default=Path(__file__).resolve().parents[1] / "publish")
    parser.add_argument("--mode", choices=("plan", "publish", "verify"), default="plan")
    parser.add_argument("--batch-bytes", type=int, default=MAX_BATCH_BYTES)
    parser.add_argument("--jobs", type=int, choices=(1, 2), default=2)
    parser.add_argument("--check-remote", action="store_true", help="Contact origin during the otherwise-local plan")
    parser.add_argument("--force-verify", action="store_true", help="Download again instead of using a matching verification cache")
    args = parser.parse_args()
    require(ZIP_LIMIT <= args.batch_bytes <= MAX_BATCH_BYTES, "Upload batches must stay between 95 and 400 MB")
    require(shutil.which("git"), "git must be installed")
    root, repo = args.root.resolve(), args.repo.resolve()
    _, files = load_delivery_files(root)
    state_dir = root / "internal" / "delivery"
    if args.mode == "plan":
        local, remote, pending, batches = inspect_delivery(repo, files, args.batch_bytes, args.check_remote)
        print(json.dumps({"mode": "plan", "mutations": False, "network_used": args.check_remote, "branch": BRANCH,
                          "local_commit": local, "remote_commit": remote, "remote_checked": args.check_remote,
                          "pending_delivery_commits": pending, "delivery_files": len(files),
                          "delivery_bytes": sum(item["bytes"] for item in files), "batch_limit": args.batch_bytes,
                          "batches": [{"bytes": sum(item["bytes"] for item in batch),
                                       "files": [item["filename"] for item in batch]} for batch in batches]}, indent=2))
        return 0
    require(shutil.which("curl"), "curl must be installed for remote verification")
    if args.mode == "publish":
        publish(root, repo, files, args.batch_bytes, state_dir)
    result = verify(repo, files, state_dir, args.jobs, args.force_verify)
    print(json.dumps({key: result[key] for key in ("complete", "remote_commit", "verified_files", "verified_bytes")}, indent=2))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError, RuntimeError, zipfile.BadZipFile) as error:
        print(f"Delivery stopped: {error}", file=sys.stderr)
        sys.exit(1)
