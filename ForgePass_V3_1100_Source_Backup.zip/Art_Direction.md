# Forge Pass V3 — art direction and visual acceptance

The current revision responds to the user's rejection of empty compositions and weak family recognition. The previous edition is an archive, not the visual acceptance standard for V3.

## The central change

Build an object with a strong identity and rich internal construction. Do not enlarge a sparse wire drawing with circles and call the frame full. More thin forks alone will create noise without improving the sculpture.

Every piece needs three readable scales:

1. **Silhouette:** the family is recognizable at 160–240 pixels and in grayscale.
2. **Construction:** major trunks, crown bands, crystal spines, trusses, or flowing ribbons support the object at 500 pixels.
3. **Finish:** bevels, facets, jewelry, branchlets, and inlays reward inspection at the delivered resolution.

Primary structures should retain their visual weight when the image is reduced. Fine detail is a supplement, never the entire subject.

## Composition and density

- Judge the sculpture separately from its enclosing halos. Halo-only bounds do not measure subject presence.
- Aim for the sculpture itself to span roughly 75–88% of the usable frame in at least one major dimension, and to have purposeful mass throughout the other. An intentionally horizontal design can be broad without forcing it into a square.
- A recognizable central object may have open channels. The goal is distributed structure rather than continuous bright pixels.
- Place secondary assemblies into large empty wedges and support them with real parent branches. Do not scatter detached beads, rings, or random ornaments to fill blank space.
- Dense regions should alternate with readable channels. Preserve separation between adjacent secondary branches and between layers in the animated artwork.
- Use a strong focal form, two or three supporting masses, and tertiary detail. Avoid uniform thickness and uniform importance across all strokes.
- Increase stem thickness and add panels, facets, jewelry, foliage clusters, or architectural infill where appropriate. A skeleton with 200 thin strokes is still a skeleton.
- Large outer rings are optional framing. They should not become the dominant identity shared by all eleven families.

## Family signatures that must survive color removal

| Family | Primary recognition cue | Supporting construction | Reject when |
|---|---|---|---|
| Circuit | Orthogonal routed circuitry with chips/buses | Layered 90-degree forks, connector arrays, node housings and panel insets | It resembles a generic radial tree with cyan coloring |
| Lightning | A forceful jagged discharge and branching storm mass | Alternating angular breaks, thick main bolts, smaller energetic forks | It becomes regular straight spokes or a neat snowflake |
| Coral | A broad underwater colony of rounded branching growth | Tapered curved stems, clustered corallites, branching fan/reef lobes | It is only three thin plant stems or a crown-shaped fan |
| Frost | Faceted sixfold/crystalline construction | Repeated needle pairs, planar shard facets, rigid cold geometry | Curves make it look like Coral or it is only a sparse star |
| Roots | A visibly exposed, spreading and interwoven root mass | Heavy woody trunk, knotted root forks, grounded lower structure | It looks like antlers, a bonsai canopy, or a free-floating V |
| Trident | A commanding three-pronged head or clearly articulated trident assembly | Central shaft, shoulder/neck construction, subordinate prong branches and metal ornaments | Its three-prong grammar disappears into a generic cross or spear cluster |
| Crown | An unmistakable broad crown band supporting pointed/arched regalia | Large crest, gems, layered band, branching filigree and symmetrical or purposeful asymmetric points | It reads as a plant fan, a candle stand, a narrow staff, or a floating arc |
| Lattice | A field of repeated connected cells or woven trusses | Cross-bracing, interlocking struts, large structural nodes and nested bays | It is only an empty diamond, triangle, or hourglass frame |
| Cascade | Several readable descending flows and waterfall terraces | Thick ribbons, attached tributaries, ledges/splash forks, a lower fan or pool gesture | It looks like hanging wires or static leafless branches |
| Bonsai | A woody tree with deliberately layered, substantial canopy masses | Curved trunk, tapering boughs, jade foliage fans/pads, a grounded planting/root gesture | It is a bare fork, a few green tips, or an underground root network |
| Starburst | A substantial celestial core with a rich radiant corona | Alternating ray tiers, smaller sparks, warm faceted solar forms | It becomes an icy snowflake, a plain eight-spoke wheel, or empty concentric circles |

## Crown: mandatory correction

The old Crown family fails the recognition test. Its gold fan and narrow branching spire do not read as crowns.

Every Crown subtype must retain:

- A broad, clearly visible base band with enough height to read as an object.
- An upward pointed or arched silhouette.
- A central crest/jewel or other clear royal focal feature.
- Multiple meaningful points or arches, supported by a real band/shoulder structure.
- Jewel and filigree detail distributed across the object rather than concentrated in one tiny central hub.

Variation can change point count, arch construction, band tiers, crest geometry and side panels. It must not remove the crown band and leave a staff.

## Material and lighting

- Preserve the dark, clean background and family palettes, but establish light and shadow within the object.
- Thick rails need an illuminated face, a darker side, and a narrow highlight; an identical bright outline on every side flattens the object.
- Facets should look like panels, crystal faces, leaves or jewels. Give neighboring faces different values. Do not fill every facet with the same dark flat color.
- Metallic bodies, luminous accents and inlaid stones should have different brightness roles. Everything glowing at the same intensity removes hierarchy.
- Hubs and ornaments must relate to the scale of the object. Too many identical circular medallions make distinct families feel like the same interface diagram.
- Retain highlight detail after GIF palette quantization. Broad soft gradients should be used carefully; clean bevels and deliberate value bands compress better.

## Preview and Volumetric tier treatment

Preview must look like a complete, richly resolved sculpture. It should not feel like a reduced or unfinished version of Volumetric.

Volumetric should add a readable depth construction to that same family identity:

- Show a substantial front body, an exposed rear structure and coherent connectors.
- Separate layers far enough to notice, but not so far that the main silhouette breaks or loses its identity.
- Keep the subject large and well composed in both merged and open poses. Avoid a large apparent shrink during the loop.
- Maintain fixed hub integrity where applicable, but do not overuse a circular fixed hub if it weakens a real crown band, tree trunk or waterfall source.
- Use a slow continuous loop with clear open and merged phases. The distinction must remain obvious at marketplace size.
- A still thumbnail can suggest depth through exposed rear elements and occlusion. The GIF supplies definitive motion; do not promise a viewer can determine animation from a frozen frame alone.

## Variation without diluting identity

Keep all eleven families visually coherent while making the ten subtypes and nine Preview compositions materially different.

Change major architecture first: support distribution, silhouette, number of principal masses, tiered arrangements, cell construction, and branch grammar. Change ornaments and palette roles second.

Avoid a universal menu of tall/wide/rotated/twin copies applied to every family. Copying a complete mini sculpture two or three times can create an arrangement difference, but it should not be the principal method for a whole edition.

Sparse variants are no longer an acceptable way to create variation. A piece can be broad, asymmetric or restrained while remaining sufficiently resolved.

## Review gates before full production

### Gate A — one strong hero per family

- Inspect color and grayscale boards without family labels.
- Every family should have a different dominant silhouette and construction grammar.
- Crown, Bonsai, Roots, Coral and Cascade must pass their literal recognition cues.
- Compare new heroes to the old sample board to confirm increased subject mass rather than only additional framing.

### Gate B — all ten subtypes in each family

- Each subtype remains identifiable as its family.
- No subtype is permitted to regress to a sparse staff, thin frame or small cluster.
- Main differences remain apparent at 200 pixels.

### Gate C — all nine Preview variants per subtype

- Inspect complete contact sheets, not only a few rich hero examples.
- Closest-looking pairs need a specific explanation of their visible structural differences.
- Geometry/hash uniqueness does not establish visual distinction.

### Gate D — actual encoded animation

- Compare open, merged and intermediate poses at 1000 pixels and thumbnail size.
- Verify silhouette stability, connected layers, image boundaries and a visibly smooth loop.
- Decode the delivered GIF; assessing only the high-resolution PNG poster is insufficient.

### Gate E — full export inventory

- Retain 990 Preview and 110 Volumetric artworks across eleven families.
- Each animated artwork keeps one PNG backup with the same artwork identity.
- Validate file dimensions, duration, looping, size limits, and checksums.
- Distinguish art review, encoded animation review and actual OpenSea presentation testing in reports.

## Critical sign-off language

Record pass, concern and fail explicitly. Do not approve an image solely because it has more paths, fills a measured bounding box, or uses bright colors. The user's new request is the acceptance standard.

The aim is a cohesive family of crafted objects with generous detail and unmistakable identities, not a busier version of the previous wire diagrams.
