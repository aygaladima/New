# Forge Pass V3 — sculptural redesign

Forge Pass V3 contains **990 Preview artworks and 110 Volumetric artworks**. Its eleven families each contain ten structural subtypes; each subtype contains nine Preview compositions and one Volumetric composition.

The complete export contains **1,100 PNGs and 110 animated GIFs: 1,210 media files**. A Volumetric artwork's PNG is its still backup, not another artwork or another Preview edition.

V3 responds to the request for fuller branch design and unmistakable family identity. It rebuilds the subjects with stronger silhouettes, substantial primary structures, distributed secondary branches, sculptural panels/canopies/filigree, and richer finish. Outer rings are framing, not a substitute for a resolved subject. See `Art_Direction.md` for the review criteria. The earlier `forge-pass-1100-collection` delivery remains a separate archive.

## Download and view

Use the [V3 family download index](https://github.com/aygaladima/New/blob/forge-pass-1100-v3-collection/ForgePass_V3_1100_Downloads.md) or [complete V3 outer ZIP](https://github.com/aygaladima/New/archive/refs/heads/forge-pass-1100-v3-collection.zip) after publication.

1. Extract the complete outer ZIP.
2. Extract its individual artwork ZIPs into one common destination. Their Preview and Volumetric folders combine into the collection.
3. Open PNGs in an image viewer. Open GIFs in a browser or viewer that supports animation.

Each family ZIP also works as an independent download below 95 MB. These are ordinary ZIPs, not split-volume archives. An animated artwork's PNG and GIF stay together. `Package_Manifest.json` records exact artwork coverage, file sizes, and SHA-256 checksums.

The finished artwork can be used directly. The optional source backup supports inspection and reproduction; no Blender installation or code execution is required to view the media.

## Collection map

| Family | Artwork IDs | Preview | Volumetric |
|---|---|---:|---:|
| Circuit | 0001–0100 | 90 | 10 |
| Lightning | 0101–0200 | 90 | 10 |
| Coral | 0201–0300 | 90 | 10 |
| Frost | 0301–0400 | 90 | 10 |
| Roots | 0401–0500 | 90 | 10 |
| Trident | 0501–0600 | 90 | 10 |
| Crown | 0601–0700 | 90 | 10 |
| Lattice | 0701–0800 | 90 | 10 |
| Cascade | 0801–0900 | 90 | 10 |
| Bonsai | 0901–1000 | 90 | 10 |
| Starburst | 1001–1100 | 90 | 10 |

Each family occupies 100 consecutive artwork IDs. Each subtype occupies ten: its first nine IDs are Preview and its final ID is Volumetric. For example, IDs 0001–0009 and 0010 form Circuit's first subtype. `Families_Subtypes.csv` lists all 110 current subtype names and exact allocations; its `subtype_index` is the source's zero-based 0–9 index.

`Collection.json` is the per-artwork production inventory, including family, subtype, variant, tier, palette, seed, geometry fingerprint and media association. Artwork IDs are not assigned on-chain token IDs. A later minting workflow must map them explicitly.

## Export specifications

- Preview: finished static 2048 × 2048 RGB PNG.
- Volumetric: 1000 × 1000 GIF, 20 fps, a 240-frame source timeline, 12-second infinite loop, below 50,000,000 bytes.
- Each Volumetric artwork also has a 2048 × 2048 RGB PNG backup at maximum separation.
- The encoder uses an adaptive global palette when necessary to stay within the size limit. Actual palette sizes, encoded-frame counts and timing are recorded in the validation data. Adjacent identical poses may coalesce into longer encoded GIF frame durations while preserving the 12-second timeline.

Volumetric foreground/rear structures separate and merge slowly through coordinated scale, angle and offset changes. The sculpture keeps substantial frame coverage throughout the cycle. Where a core hub is present, its interior stays fixed while connected assemblies move.

The production method is procedural Python **2.5D** shading and depth-layer animation. It is not a Blender/Cycles render or a physically simulated participating-volume effect. Beveled rails, shaded facets, inlays and material highlights create the sculptural appearance.

## Source and reproducibility

The backup contains source, project documents, compressed geometry, final validation and review evidence within its 80 MB budget. Media are delivered separately in the artwork ZIPs. Temporary frame caches, vendor binaries and credentials are excluded.

Recorded production environment:

- Python 3.12.14.
- NumPy 2.3.5.
- Pillow 12.3.0.
- ffmpeg version 7.1.5-0+deb13u1 as an external executable on PATH.

In a separate extracted source-backup copy:

```bash
python -m pip install -r requirements.txt
python Restore_Geometry.py
python source/produce.py stills --workers 4
python source/produce.py animations --workers 4
python source/review_collection.py
python source/validate_collection.py
python source/generate_docs.py
```

Install FFmpeg separately through the operating system. Run `Restore_Geometry.py` only for the extracted backup. An existing production workspace already has uncompressed geometry. To regenerate geometry from the builders instead, run `python source/build_collection.py` before production.

Reduce worker count to fit available CPU and memory. `--ids 3,10` selects individual artwork IDs. The PNG and GIF jobs reuse exports only when recorded geometry and pipeline fingerprints and actual media checksums match. Active frame caches are removed after successful GIF export checks.

The five family builders are `family_architectural.py` (Circuit/Lattice/Trident), `family_energy.py` (Lightning/Frost/Starburst), `family_organic.py` (Coral/Roots/Bonsai), `family_crown.py` and `family_cascade.py`. They preserve a deterministic source definition for every artwork.

## Validation and packaging

Per-export reports check PNG dimensions/mode and fully decode GIFs to inspect timing, looping, fixed hubs, endpoint continuity and visible movement. Final validation checks complete allocation, geometry and media hashes, graph attachment and exact file coverage. Review sheets support visual inspection of family/subtype/variant identity and fullness; numerical density scores alone do not establish visual quality.

After final media validation, visual review and documentation:

```bash
python source/package_collection.py --plan
python source/package_collection.py
python source/deliver_collection.py --mode plan
```

Packages are immutable once created. If the art or documentation changes afterward, use a new delivery directory/version rather than overwriting a package with different contents under the same filename.

The delivery plan is local and read-only by default. Publishing requires an explicitly prepared repository on `forge-pass-1100-v3-collection` with the initial repository commit available and an authorized publish invocation. The helper uses bounded uploads, preserves unknown files, avoids force-pushes and checks public downloads afterward. Git and curl are needed only for optional delivery, not artwork viewing.

## NFT launch scope

This delivery creates art and production records. It does not deploy a contract, mint NFTs, freeze token metadata, publish items to OpenSea or list anything for sale. No Motion or Signature Forge tier is part of this edition.

The user's target remains $0 out-of-pocket. Mainnet costs, hosting allowance and retention, and marketplace presentation must be verified when a launch method is chosen. GitHub download backups do not by themselves establish permanent NFT media hosting or current OpenSea autoplay behavior.
