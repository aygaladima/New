FORGE PASS — 11 FAMILY SAMPLES

22 original artworks: one Preview PNG and one Volumetric GIF from each of the 11 families.
These are unchanged masters from the completed 1,100-artwork collection, not new editions.

Preview PNGs: 2048 x 2048 RGB.
Volumetric GIFs: 1000 x 1000, 20 fps, 240 frames, 12-second infinite loops.
The selected PNG and GIF are different artworks in the same family.

Extract this ZIP, open Family_Samples_Overview.jpg to compare the families,
then open the .gif files in an animation-capable browser or viewer.
The overview shows static poses; animation is contained in the GIF files.

FAMILY / PREVIEW ID / VOLUMETRIC ID
Circuit / 0003 / 0060
Lightning / 0163 / 0130
Coral / 0203 / 0280
Frost / 0303 / 0370
Roots / 0413 / 0460
Trident / 0533 / 0520
Crown / 0603 / 0650
Lattice / 0723 / 0740
Cascade / 0803 / 0830
Bonsai / 0943 / 0930
Starburst / 1023 / 1070

Exact filenames, original artwork IDs, and SHA-256 values are in Sample_Inventory.json.
Full collection: https://github.com/aygaladima/New/blob/forge-pass-1100-collection/ForgePass_1100_Downloads.md
