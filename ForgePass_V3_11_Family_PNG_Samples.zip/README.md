# Forge Pass V3 — eleven family PNG samples

This is a STATIC PNG selection only: eleven original 2048 × 2048 RGB PNG posters, one from each family. The PNG files are copied byte for byte from the full collection.

These are still posters of existing Volumetric artworks, not additional artwork identities or additional Preview editions. The complete collection remains 990 Preview + 110 Volumetric artworks.

The 110 animated GIFs are in the full artwork ZIPs, alongside their matching PNGs. No GIFs are included in this small sample ZIP; no animation quality was reduced to make it.

| Artwork ID | Family | Structural subtype |
|---:|---|---|
| 0050 | Circuit | Square Citadel |
| 0110 | Lightning | Tempest Wheel |
| 0210 | Coral | Gorgonian Cathedral |
| 0310 | Frost | Imperial Snowflake |
| 0440 | Roots | Braided Root Throne |
| 0570 | Trident | Twin-Pylon Bridge |
| 0660 | Crown | Palatine Vault |
| 0730 | Lattice | Hexagonal Truss |
| 0890 | Cascade | Rain Dome |
| 0980 | Bonsai | Three Tree Forest |
| 1050 | Starburst | Astral Mandala |
