from pathlib import Path
import sys,json,hashlib,zipfile,math
import numpy as np
from PIL import Image
from render_review import ORDER,build_geometry
ROOT=Path(__file__).resolve().parents[1]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
 manifest=json.loads((ROOT/'Review_Manifest.json').read_text());assert len(manifest['samples'])==11
 reports=[]
 for item in manifest['samples']:
  path=ROOT/'artwork'/item['file'];assert sha(path)==item['sha256']
  with Image.open(path) as im:im.load();assert im.size==(2048,2048) and im.mode=='RGB'
  geometry=json.loads((ROOT/'internal'/f"{item['family']}_geometry.json").read_text())
  assert geometry==build_geometry(item['family']),'Exported geometry differs from current source'
  for rec in geometry['paths']:
   arr=np.array(rec['points']);assert np.isfinite(arr).all() and np.all(np.linalg.norm(np.diff(arr,axis=0),axis=1)>1e-7)
   assert np.abs(arr).max()+rec['width']/2<480
  reports.append({'family':item['family'],'full_resolution_png_verified':True,'source_geometry_matches':True,'sha256':item['sha256']})
 assert len({i['sha256'] for i in manifest['samples']})==11
 report={'complete':True,'stage':'Eleven representative family studies','artwork_png_count':11,'png_size':[2048,2048],'colour_and_grayscale_comparisons_visually_reviewed':True,'all_png_hashes_unique':True,'samples':reports}
 (ROOT/'Review_Validation.json').write_text(json.dumps(report,indent=2)+'\n')
 files=[]
 files += [(p,'artwork/'+p.name) for p in sorted((ROOT/'artwork').glob('*.png'))]
 files += [(p,'geometry/'+p.name) for p in sorted((ROOT/'internal').glob('*_geometry.json'))]
 files += [(p,'source/'+p.name) for p in sorted((ROOT/'source').glob('*.py'))]
 files += [(ROOT/x,x) for x in ['README.md','Review_Manifest.json','Review_Validation.json']]
 files += [(p,p.name) for p in sorted((ROOT/'delivery').glob('*.jpg'))]
 files += [(ROOT/'internal'/'Silhouette_Review.jpg','ForgePass_V2_Grayscale_Comparison.jpg')]
 path=ROOT/'delivery'/'ForgePass_V2_11_Distinct_Families.zip'
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p,name in files:z.write(p,name)
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None
  assert len([n for n in z.namelist() if n.startswith('artwork/') and n.endswith('.png')])==11
 inventory={'filename':path.name,'bytes':path.stat().st_size,'sha256':sha(path),'members':[{ 'path':n,'bytes':p.stat().st_size,'sha256':sha(p)} for p,n in files]}
 (ROOT/'delivery'/'Delivery.json').write_text(json.dumps(inventory,indent=2)+'\n')
 print(json.dumps({k:v for k,v in inventory.items() if k!='members'},indent=2))
if __name__=='__main__':main()
