"""Five deliberately distinct geometric directions for the Forge Pass review.

Coordinates are logical image coordinates, centred on the origin.  Geometry is
plain JSON-compatible data and does not depend on a renderer or graphics library.
The main rails and their children share vertices exactly after transformation.
"""

from __future__ import annotations

import math
import random


FAMILIES = ("Circuit", "Lightning", "Frost", "Trident", "Starburst")


def _point(p, angle=0.0):
    theta = math.radians(angle)
    x, y = p
    return [round(x * math.cos(theta) - y * math.sin(theta), 5),
            round(x * math.sin(theta) + y * math.cos(theta), 5)]


def _scene(name, description):
    return {"name": name, "description": description, "paths": [],
            "tips": [], "rings": [], "nodes": [], "facets": []}


def _path(scene, points, width, color=0, group=0, angle=0, taper=0.64):
    scene["paths"].append({"points": [_point(p, angle) for p in points],
                           "width": width, "taper": taper,
                           "color": color, "group": group})


def _tip(scene, point, radius=4.0, color=2, angle=0):
    scene["tips"].append({"pos": _point(point, angle), "radius": radius,
                          "color": color})


def _node(scene, point, radius, style="junction", color=0, angle=0):
    scene["nodes"].append({"pos": _point(point, angle), "radius": radius,
                           "style": style, "color": color})


def _ring(scene, radius, width, segments, gap, start, color, center=(0, 0)):
    scene["rings"].append({"center": list(center), "radius": radius,
                           "width": width, "segments": segments,
                           "gap": gap, "start": start, "color": color})


def _facet(scene, points, color, angle=0):
    scene["facets"].append({"points": [_point(p, angle) for p in points],
                            "color": color})


def _circuit(rng, variant):
    scene = _scene("Circuit", "Six stepped circuit assemblies with square elbows, "
                   "paired right-angle branches and two segmented enclosing rings.")
    rotation = variant * 5.0
    for arm in range(6):
        angle = -90 + 60 * arm + rotation
        hand = 1 if arm % 2 == 0 else -1
        # The short alternating dogleg makes each assembly read as fabricated PCB.
        elbow = 139 + rng.randint(-6, 6)
        elbow2 = 236 + rng.randint(-7, 7)
        terminal = 350 + rng.randint(-7, 7)
        bend = hand * (33 + rng.randint(0, 8))
        final_bend = hand * (10 + rng.randint(0, 8))
        trunk = [(48, 0), (elbow, 0), (elbow, bend),
                 (elbow2, bend), (elbow2, final_bend), (terminal, final_bend)]
        _path(scene, trunk, 19.0, 0, arm, angle, 0.78)
        _tip(scene, trunk[-1], 5.1, 2, angle)

        lower = [(elbow, 0), (elbow, -hand * 77), (elbow2 - 12, -hand * 77),
                 (elbow2 - 12, -hand * 108), (303, -hand * 108)]
        upper = [(elbow2, bend), (elbow2, hand * 94), (304, hand * 94),
                 (304, hand * 121), (340, hand * 121)]
        _path(scene, lower, 8.0, 1, arm, angle, 0.72)
        _path(scene, upper, 7.5, 0, arm, angle, 0.68)
        _tip(scene, lower[-1], 4.3, 2, angle)
        _tip(scene, upper[-1], 4.0, 1, angle)

        # Deliberate fine traces attach to existing elbow vertices.
        trace_a = [(elbow2 - 12, -hand * 77), (elbow2 - 12, -hand * 43),
                   (307, -hand * 43)]
        trace_b = [(304, hand * 94), (338, hand * 94), (338, hand * 59),
                   (374, hand * 59)]
        _path(scene, trace_a, 2.9, 2, arm, angle, 0.8)
        _path(scene, trace_b, 3.1, 1, arm, angle, 0.8)
        _tip(scene, trace_a[-1], 3.2, 1, angle)
        _tip(scene, trace_b[-1], 3.5, 2, angle)
        _node(scene, (elbow, 0), 5.4, "junction", 2, angle)
        _node(scene, (elbow2, bend), 4.7, "junction", 1, angle)

    _ring(scene, 405, 5.8, 12, 9, -87 + rotation, 1)
    _ring(scene, 445, 9.5, 6, 16, -84 - rotation, 0)
    _node(scene, (0, 0), 58, "hub", 0)
    return scene


def _lightning(rng, variant):
    scene = _scene("Lightning", "Three broad, asymmetric lightning bolts, "
                   "abrupt angular forks, white-hot tips and a sparse broken halo.")
    rotation = variant * 8.0
    for arm in range(3):
        angle = (-92, 31, 151)[arm] + rotation
        hand = -1 if arm == 1 else 1
        reach = (396, 374, 410)[arm] + rng.randint(-4, 4)
        # Unequal zigzags prevent the primary silhouette reading as a regular tree.
        trunk = [(43, 0), (119, -hand * 17), (173, hand * 24),
                 (218, -hand * 22), (279, hand * 36),
                 (331, hand * 3), (reach, hand * 43)]
        _path(scene, trunk, 23.5, 0, arm, angle, 0.46)
        _tip(scene, trunk[-1], 4.8, 2, angle)

        fork_a = [trunk[2], (207, -hand * 65), (265, -hand * 48),
                  (309, -hand * 104), (365, -hand * 86)]
        fork_b = [trunk[4], (305, hand * 101), (345, hand * 76),
                  (363, hand * 135)]
        _path(scene, fork_a, 13.8, 1, arm, angle, 0.46)
        _path(scene, fork_b, 12.4, 0, arm, angle, 0.48)
        _tip(scene, fork_a[-1], 4.4, 2, angle)
        _tip(scene, fork_b[-1], 4.2, 2, angle)

        # Leave from the inner trunk so this pale branch never crosses fork_a.
        fine_a = [trunk[1], (161, -hand * 87), (188, -hand * 127)]
        fine_b = [fork_a[2], (284, -hand * 13), (311, -hand * 24)]
        fine_c = [fork_b[1], (280, hand * 133), (295, hand * 170)]
        for points, color in ((fine_a, 2), (fine_b, 0), (fine_c, 1)):
            _path(scene, points, 4.4, color, arm, angle, 0.48)
            _tip(scene, points[-1], 3.2, color, angle)

    _ring(scene, 443, 5.1, 3, 31, -82 - rotation, 1)
    _node(scene, (0, 0), 48, "hub", 0)
    return scene


def _frost(rng, variant):
    scene = _scene("Frost", "Eight crystalline spears with regular needle forks, "
                   "translucent-looking terminal facets and one fine enclosing circle.")
    rotation = variant * 4.0
    for arm in range(8):
        angle = -90 + arm * 45 + rotation
        # A small alternating reach establishes hierarchy without weakening symmetry.
        reach = 423 if arm % 2 == 0 else 407
        reach += rng.randint(-2, 2)
        trunk = [(44, 0), (144, 0), (227, 0), (307, 0), (reach, 0)]
        _path(scene, trunk, 10.5 if arm % 2 == 0 else 8.4, 0, arm, angle, 0.45)
        _tip(scene, trunk[-1], 3.1, 2, angle)
        for level, (root, knee, end) in enumerate((
            (144, (196, 47), (257, 70)),
            (227, (276, 45), (328, 62)),
            (307, (349, 33), (385, 43)),
        )):
            for hand in (-1, 1):
                branch = [(root, 0), (knee[0], hand * knee[1]),
                          (end[0], hand * end[1])]
                color = 1 if level == 1 else 0
                _path(scene, branch, 5.8 - level * 0.75, color, arm, angle, 0.45)
                _tip(scene, branch[-1], 3.0, 2 if level != 1 else 1, angle)
        # The small spearhead is part of the crystal, not a large round terminal.
        _facet(scene, [(reach - 18, 0), (reach - 11, -5.3),
                       (reach + 4, 0), (reach - 11, 5.3)], 2, angle)

    _ring(scene, 448, 2.1, 1, 0, 0, 1)
    _node(scene, (0, 0), 45, "hub", 1)
    return scene


def _trident(rng, variant):
    scene = _scene("Trident", "Three substantial mechanical stems, each dividing "
                   "into exactly three long prongs around a circular junction.")
    rotation = variant * 7.5
    for arm in range(3):
        angle = -90 + 120 * arm + rotation
        junction = 224 + rng.randint(-5, 5)
        primary = [(47, 0), (128, 0), (181, 0), (junction, 0)]
        _path(scene, primary, 24.0, 0, arm, angle, 0.8)
        middle = [(junction, 0), (309, 0), (414, 0)]
        _path(scene, middle, 16.0, 0, arm, angle, 0.53)
        _tip(scene, middle[-1], 5.4, 2, angle)
        for hand in (-1, 1):
            side = [(junction, 0), (278, hand * 70),
                    (366, hand * 100), (393, hand * 100)]
            _path(scene, side, 17.0, 0 if hand == -1 else 1, arm, angle, 0.57)
            _tip(scene, side[-1], 5.1, 2, angle)
        # Collars stay small enough that the three-prong silhouette remains clear.
        _node(scene, (junction, 0), 25, "junction", 2, angle)
        _node(scene, (128, 0), 7.0, "junction", 1, angle)

    _node(scene, (0, 0), 62, "hub", 0)
    # A broad, three-facet centre reinforces the triangular construction language.
    for arm in range(3):
        _facet(scene, [(0, 0), (31, -17.9), (31, 17.9)],
               2 if arm == 0 else (0 if arm == 1 else 1), -90 + arm * 120 + rotation)
    return scene


def _starburst(rng, variant):
    scene = _scene("Starburst", "Twelve slender alternating long and short rays, "
                   "sparse offshoots and three concentric segmented rings.")
    rotation = variant * 3.5
    for arm in range(12):
        angle = -90 + 30 * arm + rotation
        long_ray = arm % 2 == 0
        reach = (420 if long_ray else 300) + rng.randint(-5, 5)
        root = 251 if long_ray else 207
        trunk = [(43, 0), (139, 0), (root, 0), (reach, 0)]
        color = 0 if long_ray else 1
        _path(scene, trunk, 9.2 if long_ray else 6.2, color, arm, angle, 0.54)
        _tip(scene, trunk[-1], 3.8 if long_ray else 3.3, 2, angle)
        if long_ray:
            hand = 1 if (arm // 2) % 2 == 0 else -1
            branch = [(root, 0), (290, hand * 32), (344, hand * 47)]
            _path(scene, branch, 3.9, 1, arm, angle, 0.53)
            _tip(scene, branch[-1], 3.0, 2, angle)
        elif arm in (1, 5, 9):
            branch = [(139, 0), (183, -29), (223, -39)]
            _path(scene, branch, 2.8, 0, arm, angle, 0.55)
            _tip(scene, branch[-1], 3.0, 0, angle)

    _ring(scene, 158, 2.3, 12, 12, -83 + rotation, 2)
    _ring(scene, 345, 3.4, 6, 25, -79 - rotation, 1)
    _ring(scene, 447, 6.0, 12, 10, -87 + rotation, 0)
    _node(scene, (0, 0), 44, "hub", 2)
    return scene


_BUILDERS = {"circuit": _circuit, "lightning": _lightning,
             "frost": _frost, "trident": _trident,
             "starburst": _starburst}


def _check(scene):
    for path in scene["paths"]:
        assert len(path["points"]) >= 2
        assert 2 <= path["width"] <= 24
        assert 0.45 <= path["taper"] <= 0.8
        for x, y in path["points"]:
            assert max(abs(x), abs(y)) + path["width"] / 2 < 470
    for key in ("tips", "nodes"):
        for node in scene[key]:
            assert max(map(abs, node["pos"])) + node["radius"] < 470
    for ring in scene["rings"]:
        assert max(map(abs, ring["center"])) + ring["radius"] + ring["width"] / 2 < 470
    return scene


def build(family, seed=20261018, variant=0):
    """Return the requested review-family geometry as independent plain data.

    The seed changes elbow positions and proportions while variant adds a modest
    composition rotation.  Future full-collection variants should further vary
    architecture, node layout and ring arrangements before bulk production.
    """
    key = str(family).strip().lower()
    if key not in _BUILDERS:
        raise ValueError(f"Unknown geometric family {family!r}; choose {FAMILIES}")
    family_index = tuple(_BUILDERS).index(key)
    rng = random.Random(int(seed) + 1009 * family_index + 7919 * int(variant))
    return _check(_BUILDERS[key](rng, int(variant)))

