"""Six deliberately different Forge Pass design families for the V2 review.

Geometry is expressed in centred logical units. Curved forks begin at an actual
sampled point on their parent, so there are no nearly attached branch joints.
Only standard-library modules are required.
"""

from __future__ import annotations

import hashlib
import math
import random


def _add(a, b):
    return [a[0] + b[0], a[1] + b[1]]


def _mul(a, s):
    return [a[0] * s, a[1] * s]


def _polar(r, degrees):
    t = math.radians(degrees)
    return [r * math.cos(t), r * math.sin(t)]


def _bezier(a, b, c, d, samples=29):
    points = []
    for i in range(samples):
        t = i / (samples - 1)
        u = 1 - t
        points.append([
            u**3 * a[0] + 3 * u*u*t * b[0] + 3 * u*t*t * c[0] + t**3 * d[0],
            u**3 * a[1] + 3 * u*u*t * b[1] + 3 * u*t*t * c[1] + t**3 * d[1],
        ])
    points[0] = list(a)
    points[-1] = list(d)
    return points


class _Design:
    def __init__(self, name, description):
        self.data = dict(name=name, description=description,
                         paths=[], tips=[], rings=[], nodes=[], facets=[])

    def path(self, points, width, color=0, group=0, taper=.60, tip=False, radius=3.5):
        points = [[float(x), float(y)] for x, y in points]
        self.data['paths'].append(dict(points=points, width=float(width),
                                       taper=float(taper), color=int(color), group=int(group)))
        if tip:
            self.tip(points[-1], radius, color)
        return points

    def curve(self, a, b, c, d, width, color=0, group=0, taper=.60,
              tip=False, radius=3.5, samples=29):
        return self.path(_bezier(a, b, c, d, samples), width, color, group,
                         taper, tip, radius)

    def tip(self, pos, radius=3.5, color=0):
        self.data['tips'].append(dict(pos=list(pos), radius=float(radius), color=int(color)))

    def ring(self, center, radius, width=2.0, segments=1, gap=0.0, start=0.0, color=1):
        self.data['rings'].append(dict(center=list(center), radius=float(radius),
                                      width=float(width), segments=int(segments),
                                      gap=float(gap), start=float(start), color=int(color)))

    def node(self, pos, radius, style='orb', color=0):
        self.data['nodes'].append(dict(pos=list(pos), radius=float(radius),
                                      style=style, color=int(color)))

    def finish(self):
        return self.data


def _coral(rng, variant):
    d = _Design('Coral', 'Four sweeping coral lobes, rounded forks, and three concentric fine halos.')
    angles = [-135, -45, 45, 135]
    breadth = 1.0 + .07 * (variant % 3 - 1) if variant else 1.0
    for arm, angle in enumerate(angles):
        # Each quadrant has a clear curved trunk and a fan of soft lateral forks.
        axis, side = _polar(1, angle), _polar(1, angle + 90)

        reach = rng.uniform(.955, 1.025)
        arm_breadth = breadth * rng.uniform(.92, 1.08)

        def xy(x, y):
            return _add(_mul(axis, x * reach), _mul(side, y * arm_breadth))

        sw = (-1 if arm % 2 else 1)
        spine = d.curve(xy(0, 0), xy(130, -35*sw), xy(290, 80*sw), xy(365, 9*sw),
                        19, 0, arm, .49, True, 4.9, samples=37)
        levels = (12, 19, 26) if variant % 3 != 2 else (13, 24)
        for level, idx in enumerate(levels):
            root = spine[idx]
            radial = (175, 252, 322)[level]
            for sign in (-1, 1):
                end = xy(radial + 42 - level * 5, sign * (120 - 17*level))
                fork = d.curve(root, xy(radial, sign*38),
                               xy(radial+2, sign*(96 - 10*level)), end,
                               10.0-level*.8, 1 if sign == sw else 0, arm,
                               .48, True, 4.3, samples=25)
                shoot_root = fork[14]
                shoot_end = xy(radial+69, sign*(109 - 12*level))
                d.curve(shoot_root, _add(shoot_root, _mul(axis, 22)),
                        xy(radial+52, sign*(130 - 14*level)), shoot_end,
                        4.6, 2, arm, .55, True, 3.3, samples=19)
    d.ring([0, 0], 389, 1.7, color=1)
    d.ring([0, 0], 420, 2.5, color=0)
    d.ring([0, 0], 449, 1.3, color=2)
    d.node([0, 0], 51, 'hub', 0)
    return d.finish()


def _roots(rng, variant):
    d = _Design('Roots', 'Asymmetric spreading roots: six sinuous trunks, tapered side roots, and an offset halo.')
    core = [-48, -62]
    controls = [
        ([15, 5], [199, 46], [393, 207]),
        ([-45, 47], [102, 231], [183, 395]),
        ([-132, 55], [-70, 231], [-169, 393]),
        ([-177, -8], [-244, 154], [-390, 197]),
        ([20, -141], [165, -97], [325, -262]),
        ([-138, -105], [-189, -230], [-294, -299]),
    ]
    for arm, (c1, c2, end) in enumerate(controls):
        spread = 1 + .025 * (variant % 4)
        end = [end[0]*spread + rng.uniform(-10, 10), end[1] + rng.uniform(-8, 8)]
        c1 = [c1[0]+rng.uniform(-12, 12), c1[1]+rng.uniform(-12, 12)]
        c2 = [c2[0]+rng.uniform(-16, 16), c2[1]+rng.uniform(-16, 16)]
        spine = d.curve(core, c1, c2, end, 24 if arm < 4 else 18,
                        0, arm, .45, True, 4.5, samples=37)
        levels = (13, 22, 29) if variant % 3 != 2 else (15, 27)
        for k, index in enumerate(levels):
            root = spine[index]
            prev, nxt = spine[index-1], spine[index+1]
            vx, vy = nxt[0]-prev[0], nxt[1]-prev[1]
            length = math.hypot(vx, vy)
            tangent = [vx/length, vy/length]
            normal = [-tangent[1], tangent[0]]
            sign = -1 if (arm+k) % 2 else 1
            reach = (112, 91, 60)[k]
            end2 = _add(_add(root, _mul(tangent, reach*.37)), _mul(normal, sign*reach))
            # The growing direction bends gradually, rather than forming radial spokes.
            fork = d.curve(root, _add(root, _mul(tangent, reach*.54)),
                           _add(end2, _mul(normal, -sign*reach*.21)), end2,
                           10.5-k*1.4, 1, arm, .45, True, 3.8, samples=25)
            if k < 2:
                q = fork[15]
                fine_end = _add(q, _add(_mul(tangent, 42), _mul(normal, -sign*28)))
                d.curve(q, _add(q, _mul(tangent, 20)),
                        _add(fine_end, _mul(tangent, -10)), fine_end,
                        3.4, 2, arm, .5, True, 3.0, samples=17)
    d.ring([0, 11], 429, 2.4, color=1)
    d.node(core, 39, 'hub', 0)
    return d.finish()


def _crown(rng, variant):
    d = _Design('Crown', 'An upright seven-point branching fan rises from a low golden core, framed by one open halo.')
    core = [0, 238]
    ends = [[-353, -153], [-272, -282], [-146, -382], [0, -422],
            [154, -378], [277, -277], [357, -144]]
    for arm, end in enumerate(ends):
        # Lower stems share a root; the broad spreading tips make a crown silhouette.
        end = [end[0]+rng.uniform(-8, 8), end[1]+rng.uniform(-8, 8)]
        lean = end[0]
        spine = d.curve(core, [lean*.11, 92], [lean*.84, end[1]+130], end,
                        17.5 if arm in (2, 3, 4) else 14.5,
                        0, arm, .57, True, 4.9, samples=37)
        for k, index in enumerate((20, 27)):
            root = spine[index]
            sign = -1 if arm < 3 else 1
            if arm == 3:
                sign = -1 if k == 0 else 1
            spread = 47 if k == 0 else 31
            tip = [root[0]+sign*spread, root[1] - (104 if k == 0 else 76)]
            d.curve(root, [root[0]+sign*8, root[1]-48],
                    [tip[0], tip[1]+29], tip, 7.3-k*.7,
                    1 if k == 0 else 2, arm, .55, True, 3.8, samples=25)
    d.ring([0, -14], 418, 4.1, segments=1, gap=108, start=144, color=2)
    d.node(core, 53, 'hub', 0)
    # Small jewel sockets emphasize the lower crown base without adding a ring.
    for pos in ([-76, 238], [76, 238]):
        d.path([core, list(pos)], 6.0, 1, 0, .8)
        d.node(pos, 10, 'junction', 1)
    return d.finish()


def _lattice(rng, variant):
    d = _Design('Lattice', 'Four heavy diagonal spars with four circular junctions and a square cross-braced open lattice; no outer ring.')
    signs = [(-1, -1), (1, -1), (1, 1), (-1, 1)]
    levels = (112+rng.uniform(-7, 7), 230+rng.uniform(-9, 9), 321+rng.uniform(-7, 7))
    corners = {}
    for arm, (sx, sy) in enumerate(signs):
        pts = [[0, 0]] + [[sx*r, sy*r] for r in levels]
        spine = d.path(pts, 20.8, 0, arm, .61, True, 5.1)
        for j, r in enumerate(levels):
            corners[arm, j] = spine[j+1]
        d.node(corners[arm, 1], 27, 'junction', 1)
        # Forked tips extend the diagonal silhouette outside the square lattice.
        for branch in (0, 1):
            root = corners[arm, 1]
            end = [sx*(366 if branch == 0 else 248), sy*(248 if branch == 0 else 366)]
            knee = [sx*(291 if branch == 0 else 230), sy*(230 if branch == 0 else 291)]
            d.path([root, knee, end], 7.4, 2, arm, .55, True, 3.7)
    # Three nested square frames and X braces produce a readable engineered grid.
    for level in range(3):
        for arm in range(4):
            nxt = (arm+1) % 4
            d.path([corners[arm, level], corners[nxt, level]],
                   (4.4, 7.0, 5.4)[level], 1 if level != 1 else 0,
                   arm, .8)
    for arm in range(4):
        nxt = (arm+1) % 4
        d.path([corners[arm, 0], corners[nxt, 1]], 3.1, 2, arm, .8)
        d.path([corners[nxt, 0], corners[arm, 1]], 3.1, 1, arm, .8)
        d.path([corners[arm, 1], corners[nxt, 2]], 2.6, 1, arm, .8)
        d.path([corners[nxt, 1], corners[arm, 2]], 2.6, 2, arm, .8)
    # The four junction circles are the only round structures in this family.
    return d.finish()


def _cascade(rng, variant):
    d = _Design('Cascade', 'A high suspended core carries a curved canopy of long, downward hanging branches inside two offset halos.')
    core = [0, -262]
    left = d.curve(core, [-70, -265], [-233, -202], [-356, -99],
                   21, 0, 0, .58, True, 4.7, samples=37)
    right = d.curve(core, [98, -270], [233, -212], [347, -129],
                    21, 0, 1, .58, True, 4.7, samples=37)
    center = d.curve(core, [57, -88], [-93, 167], [-19, 408],
                     20, 0, 2, .48, True, 4.5, samples=41)
    for side, trunk in ((-1, left), (1, right)):
        levels = (10, 18, 27, 34) if variant % 3 != 2 else (11, 24, 34)
        for k, index in enumerate(levels):
            root = trunk[index]
            tip = [root[0] + side*(19+9*k), (369, 351, 280, 181)[k]+rng.uniform(-12, 12)]
            # Nearly vertical but visibly curved strands form a waterfall silhouette.
            strand = d.curve(root, [root[0]+side*24, root[1]+91],
                             [tip[0]-side*47, tip[1]-128], tip,
                             11.8-k*.9, 1 if k % 2 else 0, k+3,
                             .46, True, 4.3, samples=33)
            for j, at in enumerate((15, 24)):
                start = strand[at]
                sign = -side if j == 0 else side
                end = [start[0] + sign*(49-6*k), start[1]+67-4*k]
                d.curve(start, [start[0]+sign*6, start[1]+35],
                        [end[0]-sign*9, end[1]-19], end,
                        4.2, 2, k+3, .48, True, 3.2, samples=21)
    for index, side in ((15, -1), (25, 1), (32, -1)):
        root = center[index]
        end = [root[0]+side*76, root[1]+85]
        d.curve(root, [root[0]+side*8, root[1]+45],
                [end[0]-side*20, end[1]-36], end,
                6.7, 1, 2, .5, True, 3.7, samples=25)
    d.ring([-21, -12], 421, 2.2, segments=1, gap=54, start=117, color=1)
    d.ring([37, 56], 354, 3.5, segments=1, gap=92, start=134, color=2)
    d.node(core, 43, 'hub', 0)
    return d.finish()


def _bonsai(rng, variant):
    d = _Design('Bonsai', 'One sculptural copper trunk supports a broad asymmetric jade canopy with seven luminous golden fruit orbs.')
    core = [-38, 328]
    # S-curve trunk deliberately leaves the lower half sparse and sculptural.
    lower = d.curve(core, [-169, 196], [68, 90], [-20, -67],
                    24, 0, 0, .8, samples=41)
    upper = d.curve(lower[-1], [-77, -114], [-39, -221], [-7, -350],
                    17, 0, 0, .49, True, 4.8, samples=33)
    branch_specs = [
        (lower, 26, [-136, -18], [-287, -100], [-364, -125], 18.0),
        (lower, 35, [95, -11], [254, -86], [353, -171], 19.0),
        (upper, 10, [-141, -180], [-203, -288], [-286, -295], 15.0),
        (upper, 16, [71, -231], [171, -297], [250, -321], 14.0),
        (upper, 25, [-86, -312], [-138, -362], [-160, -376], 10.0),
    ]
    fruit = []
    for arm, (parent, index, c1, c2, end, width) in enumerate(branch_specs, 1):
        c1 = [c1[0]+rng.uniform(-12, 12), c1[1]+rng.uniform(-8, 8)]
        c2 = [c2[0]+rng.uniform(-10, 10), c2[1]+rng.uniform(-8, 8)]
        end = [end[0]+rng.uniform(-8, 8), end[1]+rng.uniform(-7, 7)]
        spine = d.curve(parent[index], c1, c2, end, width, 0, arm,
                        .49, True, 4.2, samples=33)
        # Upward forks grow at staggered heights and vary in scale across the canopy.
        for k, at in enumerate((13, 22, 28)):
            root = spine[at]
            side = -1 if end[0] < 0 else 1
            tip = [root[0]+side*(29+8*k), root[1]-(55+13*(arm % 2)-7*k)]
            if math.hypot(*tip) > 419:
                tip = _mul(tip, 419/math.hypot(*tip))
            fork = d.curve(root, [root[0]+side*5, root[1]-29],
                           [tip[0]-side*10, tip[1]+18], tip,
                           7.2-k*1.0, 1, arm, .5, True, 3.7, samples=25)
            if k == 1 or (arm in (1, 3) and k == 2):
                # Fruit sits exactly on a branch endpoint, not floating near a twig.
                fruit.append((fork[-1], 10.5 + (arm % 3)*2.4))
            if k == 0:
                twig_root = fork[14]
                twig_end = [twig_root[0]-side*27, twig_root[1]-35]
                d.curve(twig_root, [twig_root[0]-side*4, twig_root[1]-20],
                        [twig_end[0]+side*11, twig_end[1]+3], twig_end,
                        3.6, 2, arm, .49, True, 3.1, samples=19)
    d.ring([0, 0], 443, 3.4, color=1)
    d.node(core, 38, 'hub', 0)
    for pos, radius in fruit:
        d.node(pos, radius, 'orb', 2)
    return d.finish()


_BUILDERS = {
    'coral': _coral,
    'roots': _roots,
    'crown': _crown,
    'lattice': _lattice,
    'cascade': _cascade,
    'bonsai': _bonsai,
}


def build(family, seed=20261018, variant=0):
    """Return one review design; names are case insensitive and seed is stable."""
    key = family.lower().strip()
    if key not in _BUILDERS:
        raise ValueError(f'Unsupported organic family {family!r}; choose {list(_BUILDERS)}')
    digest = int.from_bytes(hashlib.sha256(key.encode()).digest()[:8], 'big')
    rng = random.Random(int(seed) ^ digest ^ (int(variant) * 104729))
    result = _BUILDERS[key](rng, int(variant))
    result['seed'] = int(seed)
    result['variant'] = int(variant)
    return result


if __name__ == '__main__':
    import json
    for name in _BUILDERS:
        g = build(name)
        pts = [p for path in g['paths'] for p in path['points']]
        print(json.dumps(dict(name=g['name'], paths=len(g['paths']), tips=len(g['tips']),
                              rings=len(g['rings']), nodes=len(g['nodes']),
                              path_bbox=[min(p[0] for p in pts), min(p[1] for p in pts),
                                         max(p[0] for p in pts), max(p[1] for p in pts)])))
